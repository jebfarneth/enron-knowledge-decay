import sys, importlib.util, json
from pathlib import Path
R=Path('/Users/jebfarneth/projects/enron-knowledge-decay')
O=Path('/tmp/enron-audit-20260925.Xj3qoO')
sys.path.insert(0,str(R/'src'))
def load(name):
    spec=importlib.util.spec_from_file_location(name,R/'tests'/f'{name}.py')
    m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
out={}
m=load('test_evaluate')
m.bootstrap_interval=lambda *a,**k:(0.0,1.0)
m.test_bootstrap_is_reproducible_and_brackets_the_estimate()
out['bootstrap_test_accepts_constant_0_1']=True
m=load('test_identity')
original=m.build_identities
def first_only(messages,domain):
    return original(messages.drop_duplicates('sender',keep='first'),domain)
m.build_identities=first_only
m.test_alias_addresses_merge_into_one_person()
out['identity_build_test_accepts_ignoring_modal_name']=True
(O/'test_mutations.json').write_text(json.dumps(out,indent=2))
print(json.dumps(out,indent=2))
