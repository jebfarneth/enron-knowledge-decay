# Independent adversarial audit — Enron data and network baselines

Date: September 25, 2026. Repository: `/Users/jebfarneth/projects/enron-knowledge-decay`, branch `main`, audited commit `8c595e7e6cc842260843d49547f20b796994db6a`. Scope: `src/enron_importance/`, tests, configuration, raw/intermediate/processed data, current results/figures and relevant non-legacy history. `legacy/` is out of scope.

Evidence root: `/tmp/enron-audit-20260925.Xj3qoO`. Commands below assume the repository as working directory unless stated otherwise. Code references such as`identity.py:67–78` mean`src/enron_importance/identity.py`; line ranges refer to the audited commit. Scratch scripts contain the executable probes and preserve selected records/labels; they are not repository changes. Manual email judgments are explicitly distinguished from deterministic counts and independently calculated numerical checks.

## 1. Executive verdict

**No—not yet as a frozen, person-level data foundation for Phase 3.** All claimed funnel counts reproduce, but reproducible counts do not establish valid people, authored language, replies or organizational rank. The audit finds mixed-author identity merges, unresolved recipient/list nodes, contradictory title labels, discarded recipient evidence, timestamp-shifted probable copies, human operational work removed as automation/routine, and low direct-parent validity in inspected reply links. Those errors directly affect the proposed speech-act/topic-ownership research. Independent edge, PageRank, betweenness and bootstrap-oracle checks pass, while floating out-strength ties cause a small, real reproducibility failure. Simple custodian/mailbox-volume predictors do **not** explain away degree's observed title-ordering result. Freeze inferential text-model claims until identity/entity typing, label provenance, text/filter validation and reply-link validation are repaired and baselines rerun. Current evidence supports an exploratory association between a partially resolved communication graph and a noisy title proxy—not measurement of functional importance or post-departure validation.

## 2. Methods derived from implementation

The following descriptions were derived from source, then checked against actual data and independent probes. Plain-language and technical versions are both supplied. A paper must report the hard-coded choices as well as `config.yaml`; the statement that **every** parameter is in configuration is false.
