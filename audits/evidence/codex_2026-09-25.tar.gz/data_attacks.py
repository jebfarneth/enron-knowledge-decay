import sys,json,re,hashlib,unicodedata,html
from pathlib import Path
import pandas as pd
import numpy as np
R=Path('/Users/jebfarneth/projects/enron-knowledge-decay')
O=Path('/tmp/enron-audit-20260925.Xj3qoO')
sys.path.insert(0,str(R/'src'))
from enron_importance.dedupe import restrict_window,content_keys,normalize_body,normalize_subject,folder_rank,deduplicate
from enron_importance.senders import template_of,sender_profiles,routine_messages
from enron_importance.ingest import parse_message

raw=pd.read_parquet(R/'data/interim/messages_raw.parquet')
raw,drop=restrict_window(raw,'1998-01-01','2002-12-31')
print('Read raw',len(raw),flush=True)
raw['key']=content_keys(raw)
raw['recipients']=[tuple(sorted(set(to)|set(cc))) for to,cc in zip(raw.to,raw.cc)]
raw['internal_recipients']=raw.recipients.map(lambda xs:tuple(x for x in xs if x.endswith('@enron.com')))
raw['folder_rank']=raw.folder.map(folder_rank)
raw['body_norm']=raw.body.map(normalize_body)
raw['subject_norm']=raw.subject.map(normalize_subject)
raw=raw.sort_values(['folder_rank','path'])
sizes=raw.groupby('key').size()
dups=raw[raw.key.isin(sizes[sizes>1].index)]
rec_counts=dups.groupby('key').recipients.nunique()
conflict_keys=rec_counts[rec_counts>1].index
conflict=dups[dups.key.isin(conflict_keys)]
lost=0;lostinternal=0;affectedinternal=0;whollydisjoint=0
conflict_examples=[]
for key,g in conflict.groupby('key',sort=False):
    surviving=set(g.iloc[0].recipients); union=set().union(*g.recipients.map(set))
    delta=union-surviving
    lost+=len(delta)
    d_internal={x for x in delta if x.endswith('@enron.com')}
    lostinternal+=len(d_internal); affectedinternal+=bool(d_internal)
    disjoint=any(not(surviving&set(x)) and len(x)>0 and len(surviving)>0 for x in g.recipients.iloc[1:])
    whollydisjoint+=disjoint
    if len(conflict_examples)<35 or (disjoint and len(conflict_examples)<65):
        conflict_examples.append({'key':key,'n':len(g),'disjoint':disjoint,'rows':g[['path','sender','date','subject','recipients','x_from','body']].head(5).to_dict('records')})
summary={'in_window':len(raw),'drop':drop,'groups_with_copies':int((sizes>1).sum()),'recipient_conflict_groups':len(conflict_keys),'recipient_assignments_lost':lost,'internal_recipient_assignments_lost':lostinternal,'groups_with_internal_recipient_loss':affectedinternal,'disjoint_recipient_groups':whollydisjoint,'null_senders':int(raw.sender.isna().sum()),'body_replacement_chars':int(raw.body.fillna('').str.contains('\ufffd',regex=False).sum())}
(O/'dedupe_recipient_examples.json').write_text(json.dumps(conflict_examples,default=str,indent=2))
sample_keys=pd.Series(sizes[sizes>1].index).sample(40,random_state=20260925)
records=[]
for key in sample_keys:
    g=dups[dups.key==key]
    records.append({'key':key,'n':len(g),'rows':g[['path','sender','date','subject','recipients','body']].head(5).to_dict('records')})
(O/'dedupe_sample40.json').write_text(json.dumps(records,default=str,indent=2))
# Find repeated content surviving solely due to timestamp differences.
unique=raw.drop_duplicates('key').copy()
unique['timeless']=[hashlib.sha1('\x1f'.join([s or '',su,b]).encode()).hexdigest() for s,su,b in zip(unique.sender.fillna(''),unique.subject_norm,unique.body_norm)]
same=unique[unique.duplicated('timeless',keep=False)].sort_values(['timeless','date'])
timezone=[]; delta_counts={}; candidate_keys=set()
for key,g in same.groupby('timeless',sort=False):
    if len(g)>1500: continue
    g=g.sort_values('date')
    for a,b in zip(g.itertuples(),list(g.itertuples())[1:]):
        delta=int((b.date-a.date).total_seconds())
        if delta in [3600,7200,10800,14400,18000,21600,25200,28800] and len(a.body_norm)>100:
            delta_counts[str(delta)]=delta_counts.get(str(delta),0)+1
            candidate_keys.update([a.key,b.key])
            if len(timezone)<70: timezone.append({'delta_seconds':delta,'rows':[{'path':x.path,'sender':x.sender,'date':str(x.date),'subject':x.subject,'recipients':x.recipients,'body':str(x.body)[:1500]} for x in [a,b]]})
summary['timeless_repeated_messages']=len(same)
summary['hour_offset_adjacent_pairs_long_bodies']=delta_counts
summary['hour_offset_candidate_messages']=len(candidate_keys)
(O/'timezone_candidates.json').write_text(json.dumps(timezone,indent=2))
# Same date/sender/subject after unicode and common MIME-softbreak normalization, but different original body keys.
def relaxed(t):
    t=unicodedata.normalize('NFKC',html.unescape(t or '')).replace('=\n','').replace('\ufffd','').replace('=20',' ').replace('=09',' ')
    return re.sub(r'\s+',' ',t).strip().lower()
unique['relaxed']=unique.body.fillna('').map(relaxed)
rg=unique.groupby(['sender','date','subject_norm','relaxed'],dropna=False).agg(n=('key','size'))
summary['relaxed_normalization_extra_copies']=int((rg.n-1).clip(lower=0).sum())
summary['recipient_invariant_example']=parse_message(b'Date: Mon, 14 May 2001 16:39:00 -0700\nFrom: a@enron.com\n\nbody','maildir/a/sent/1')['date'].isoformat()==parse_message(b'Date: Mon, 14 May 2001 23:39:00 +0000\nFrom: a@enron.com\n\nbody','maildir/a/sent/2')['date'].isoformat()
(O/'data_attack_summary.json').write_text(json.dumps(summary,indent=2))
print(json.dumps(summary,indent=2),flush=True)
del raw,dups,conflict,unique,same

m=pd.read_parquet(R/'data/processed/messages.parquet')
s=pd.read_parquet(R/'data/processed/senders.parquet')
m['template']=m.authored.map(template_of)
flagged=s[s.automated]
print('flagged',len(flagged),'internal',flagged.internal.sum(),flush=True)
(O/'all_flagged_senders.csv').write_text(flagged.to_csv(index=False))
flagged_examples=[]
for a in flagged.sender:
    g=m[m.sender==a]
    templates=g.template.value_counts().head(4).index
    ex=g[g.template.isin(templates)].drop_duplicates('template')[['path','sender','subject','authored','template']].to_dict('records')
    extra=g[~g.template.isin(templates)].head(2)[['path','sender','subject','authored','template']].to_dict('records')
    flagged_examples.append({'profile':flagged[flagged.sender==a].iloc[0].to_dict(),'examples':ex,'other':extra})
(O/'flagged_senders_examples.json').write_text(json.dumps(flagged_examples,default=str,indent=2))
unflagged=[]
for a in s[~s.automated].head(40).sender:
    g=m[m.sender==a]
    top=g.template.value_counts().head(5)
    unflagged.append({'sender':a,'n':len(g),'n_routine':int(g.routine.sum()),'top_templates':top.to_dict(),'examples':g.drop_duplicates('template')[['path','subject','authored']].head(3).to_dict('records')})
(O/'unflagged_top40.json').write_text(json.dumps(unflagged,indent=2))
routine=m[m.routine]
routine_stats={'routine_messages':len(routine),'routine_senders':routine.sender.nunique(),'routine_internal':int(routine.sender_internal.sum()),'routine_short_le40':int((routine.authored.fillna('').str.len()<=40).sum()),'top_templates':routine.template.value_counts().head(50).to_dict()}
rs=routine.groupby('sender').size().sort_values(ascending=False).head(25)
routine_stats['top_senders']={a:{'routine':int(n),'all':int((m.sender==a).sum()),'examples':routine[routine.sender==a][['path','subject','authored']].head(2).to_dict('records')} for a,n in rs.items()}
(O/'routine_summary.json').write_text(json.dumps(routine_stats,indent=2))
print(json.dumps({k:v for k,v in routine_stats.items() if k!='top_senders'},indent=2),flush=True)
