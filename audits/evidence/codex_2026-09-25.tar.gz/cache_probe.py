import sys,json,runpy
from pathlib import Path
R=Path('/Users/jebfarneth/projects/enron-knowledge-decay')
O=Path('/tmp/enron-audit-20260925.Xj3qoO')
sys.path.insert(0,str(R/'src'))
from enron_importance.prepare import prepare
from enron_importance.download import ensure_corpus
d=O/'cache_probe'
d.mkdir(exist_ok=True)
fixture=runpy.run_path(str(R/'tests/test_prepare.py'))
cfg=fixture['build'](d)
first=prepare(cfg)
archive=cfg['paths']['raw']/cfg['corpus']['filename']
archive.write_bytes(b'invalid changed source')
try:
    ensure_corpus(cfg)
    validation='unexpected pass'
except SystemExit as e:
    validation=str(e)
second=prepare(cfg)
out={'direct_verification':validation,'prepare_reused_cache_and_succeeded':first==second,'unchanged_claimed_corpus_sha':second['corpus_sha256'],'archive_actual_bytes':archive.stat().st_size}
(O/'cache_probe.json').write_text(json.dumps(out,indent=2))
print(json.dumps(out,indent=2))
