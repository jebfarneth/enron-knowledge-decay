from pathlib import Path
from collections import Counter
import re
import numpy as np
import pandas as pd
from enron_importance.identity import normalize_name, NICKNAMES, build_identities
from enron_importance.evaluate import pairwise_accuracy
ROOT=Path('/Users/jebfarneth/projects/enron-knowledge-decay')
OUT=Path('/tmp/enron-audit-20260925.Xj3qoO/identity_rank')
i=pd.read_parquet(ROOT/'data/processed/identities.parquet')
m=pd.read_parquet(ROOT/'data/processed/messages.parquet',columns=['path','sender','to','cc','x_from','date','authored','sender_automated','sender_internal','routine'])
m['person_key']=m.sender.map(dict(zip(i.address,i.person_key)))
print('PLACEHOLDER IDENTITY')
for addr in ['no.address@enron.com','no_address@enron.com']:
 s=m[m.sender.eq(addr)]
 print(addr,'messages',len(s),'assigned',i[i.address.eq(addr)].to_dict('records'),'namecounts',s.x_from.map(normalize_name).value_counts().to_dict(),'automated',s.sender_automated.value_counts().to_dict())
 print(s[['path','sender','x_from','date']].head(12).to_dict('records'))
 print('SOURCES_TO_PLACEHOLDER',sum(addr in set(t)|set(c) for t,c in zip(m.to,m.cc)))

for key in ['legal temp','christopher smith','office chairman','enron chairman','edward bland','mary gray','jo hill']:
 s=m[m.person_key.eq(key)]
 print('\nKEY',key,'messages',len(s),'addresses',s.sender.value_counts().to_dict(),'display',s.x_from.value_counts().to_dict())
 for addr,g in s.groupby('sender'):
  print('EXAMPLES',g[['path','sender','x_from','date']].head(2).to_dict('records'))
  for row in g.head(3).itertuples():print('BODY',row.path,repr(str(row.authored)[:350]))

# Show material name disagreements across addresses and clear usable-name keys split by X-From.
for term in ['scott','kenneth lay','paul thomas','sally beck','james derrick','harry arora','harpreet','donald','don ']:
 print('IDENTITY SEARCH',term,i[i.person_key.str.contains(term,regex=False)].to_dict('records')[:80])

print('LABEL_SENSITIVITY')
r=pd.read_parquet(ROOT/'data/processed/formal_rank.parquet').dropna(subset=['person_key','level'])
ev=r.groupby('person_key',as_index=False)['level'].max().merge(pd.read_parquet(ROOT/'data/processed/centrality.parquet'),on='person_key',how='left').fillna(0)
for name,change in [('max_title',False),('swierzbin_schwieger_traders',True),('exclude_conflicted',None)]:
 x=ev.copy()
 if change:x.loc[x.person_key.isin(['michael swerzbin','james schwieger']),'level']=0
 if change is None:x=x[~x.person_key.isin(['michael swerzbin','james schwieger'])]
 print(name,len(x),'pairs',int(np.triu(x.level.to_numpy()[:,None]!=x.level.to_numpy()[None,:],1).sum()),{v:pairwise_accuracy(x.level.to_numpy(),x[v].to_numpy()) for v in ['degree','pagerank','in_strength','out_strength','betweenness']})

print('TITLE_IN_CORPUS_EVIDENCE')
pat=re.compile(r'\b(?:sally beck|james derrick|rick buy|vince kaminski|harpreet arora|harry arora)\b',re.I)
title=re.compile(r'\b(?:chief|president|director|officer|counsel|harpreet|harry arora)\b',re.I)
for key in ['sally beck','james derrick','richard buy','vincent kaminski','harry arora']:
 s=m[m.person_key.eq(key)]
 print('SENDER_KEY',key,'messages',len(s))
 n=0
 for row in s.itertuples():
  lines=str(row.authored).splitlines()
  hits=[z for z,line in enumerate(lines) if title.search(line)]
  if hits:
   print(row.path,row.date,repr('\n'.join(lines[max(0,hits[0]-1):hits[0]+2])[:420]));n+=1
  if n>=5:break

# Find title/name adjacency independent of who sent the message.
print('TITLE_ADJACENCY')
for row in m.itertuples():
 body=str(row.authored)
 match=pat.search(body)
 if not match:continue
 excerpt=body[max(0,match.start()-80):match.end()+110]
 if title.search(excerpt) and (re.search('sally beck|james derrick|harpreet',excerpt,re.I)):
  print(row.path,repr(excerpt[:220]))

# Original names connected by the nickname mapping; counts and no-nickname counterfactual.
def without_nick(display):
 old=NICKNAMES.copy();NICKNAMES.clear()
 try:return normalize_name(display)
 finally:NICKNAMES.update(old)
base=i[['address','person_key']].copy()
orig=NICKNAMES.copy();NICKNAMES.clear()
plain=build_identities(m,'enron.com');NICKNAMES.update(orig)
cmp=base.merge(plain[['address','person_key']],on='address',suffixes=('_nick','_plain'))
groups=cmp.groupby('person_key_nick').person_key_plain.nunique()
print('NICKNAME_EFFECT',i.person_key.nunique(),plain.person_key.nunique(),'merge_groups',groups.gt(1).sum())
print(cmp[cmp.person_key_nick.isin(groups[groups.gt(1)].index)].sort_values(['person_key_nick','person_key_plain']).to_string(index=False))
