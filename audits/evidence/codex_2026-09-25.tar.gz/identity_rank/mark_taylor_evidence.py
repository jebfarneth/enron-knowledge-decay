import json
import pandas as pd
from pathlib import Path

R=Path('/Users/jebfarneth/projects/enron-knowledge-decay')
O=Path('/tmp/enron-audit-20260925.Xj3qoO/identity_rank')
i=pd.read_parquet(R/'data/processed/identities.parquet')
addresses=i.loc[i.person_key.eq('mark taylor'),'address'].tolist()
m=pd.read_parquet(R/'data/processed/messages.parquet',columns=['path','sender','x_from','authored'],filters=[('sender','in',addresses)])
print('IDENTITIES\n',i[i.person_key.eq('mark taylor')].to_string(index=False))
print('SENDER COUNTS\n',m.groupby('sender').size().to_string())
print('XFROM COUNTS\n',m.groupby(['sender','x_from']).size().to_string())
print('AUTHOR DISAMBIGUATION\n',m[m.path.eq('maildir/taylor-m/sent_items/336.')].to_string(index=False,max_colwidth=200))
print('MARK A EXAMPLES\n',m[m.sender.eq('a.taylor@enron.com')][['path','sender','x_from']].head(5).to_string(index=False))
e={'identities':i[i.person_key.eq('mark taylor')].to_dict('records'),'counts':m.groupby('sender').size().to_dict(),'xfrom':m.groupby(['sender','x_from']).size().rename('n').reset_index().to_dict('records'),'disambiguation':m[m.path.eq('maildir/taylor-m/sent_items/336.')].to_dict('records')}
(O/'mark_taylor_evidence.json').write_text(json.dumps(e,indent=2))
