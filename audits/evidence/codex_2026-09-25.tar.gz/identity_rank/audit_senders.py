from collections import Counter, defaultdict
from pathlib import Path
import json
import pandas as pd
import pyarrow.parquet as pq
from enron_importance.senders import template_of, name_rule

out=Path('/tmp/enron-audit-20260925.Xj3qoO/identity_rank')
p=pd.read_parquet('data/processed/senders.parquet').set_index('sender')
flag=set(p.index[p.automated]); high=list(p.loc[~p.automated].head(40).index)
selected=flag | set(high)
counts=defaultdict(Counter); nt=Counter(); n=Counter(); routine_n=Counter()
examples=defaultdict(lambda:defaultdict(list)); rout=defaultdict(Counter); rout_examples=defaultdict(list)
for batch in pq.ParquetFile('data/processed/messages.parquet').iter_batches(batch_size=2048,columns=['sender','authored','path','subject','routine','sender_automated']):
 for m in batch.to_pylist():
  s=m['sender'];t=template_of(m['authored']);n[s]+=1
  if t: counts[s][t]+=1;nt[s]+=1
  if s in selected and len(examples[s][t])<2: examples[s][t].append({k:m[k] for k in ['path','subject','authored']})
  if m['routine']:
   routine_n[s]+=1;rout[s][t]+=1
   if len(rout_examples[(s,t)])<2:rout_examples[(s,t)].append({k:m[k] for k in ['path','subject','authored']})
computed={s:bool(name_rule(s) or (nt[s]>=50 and sum(c for _,c in counts[s].most_common(3))/nt[s]>=.9)) for s in n if s}
print('profiles',len(p),'flagged',len(flag),'internal_flagged',int((p.automated&p.internal).sum()),'name_only',int((p.system_name&~p.feed).sum()),'feed_only',int((~p.system_name&p.feed).sum()),'both',int((p.system_name&p.feed).sum()))
print('independent_flag_matches',set(s for s,v in computed.items() if v)==flag,'routine_total',sum(routine_n.values()),'routine_senders',len(routine_n))
print('independently_recomputed_routine',sum(c for s,ct in counts.items() if not computed.get(s,False) for t,c in ct.items() if t and c>=10))
records=[]
for s in list(p.index[p.automated])+high:
 top=counts[s].most_common(3); tops={t for t,c in top}
 nonmodal=[t for t,c in counts[s].most_common() if t not in tops][:3]
 records.append({'sender':s,**p.loc[s].to_dict(),'top_templates':[{'template':t,'count':c,'examples':examples[s][t]} for t,c in top],'nonmodal':[{'template':t,'count':counts[s][t],'examples':examples[s][t]} for t in nonmodal],'routine_messages':routine_n[s]})
(out/'sender_profiles_audit.json').write_text(json.dumps(records,indent=2))
lines=[]
for i,r in enumerate(records):
 lines.append(f"{i:03d} {r['sender']} n={r['n_messages']} text={r['n_with_text']} name={r['system_name']} feed={r['feed']} internal={r['internal']} share={r['template_share']:.3f}")
 for t in r['top_templates']:lines.append(f"  {t['count']:5d} {t['template']}")
 for t in r['nonmodal']:lines.append(f"  OTHER {t['count']:5d} {t['template']}")
(out/'sender_profiles_audit.txt').write_text('\n'.join(lines)+'\n')
rr=[]
for s in routine_n:
 for t,c in rout[s].items(): rr.append({'sender':s,'template':t,'count':c,'sender_total':n[s],'examples':rout_examples[(s,t)]})
rr.sort(key=lambda r:r['count'],reverse=True)
(out/'routine_profiles_audit.json').write_text(json.dumps(rr,indent=2))
print('routine_top',[(r['sender'],r['template'],r['count']) for r in rr[:30]])
print('routine_short_count',sum(r['count'] for r in rr if len(r['template'])<=25),'shortgroups',sum(len(r['template'])<=25 for r in rr))
print('routine_thanks_exact',sum(r['count'] for r in rr if r['template'] in ['thanks','thank you','thanks.','thank you.']))
