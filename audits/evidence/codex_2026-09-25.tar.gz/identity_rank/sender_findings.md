# Sender and routine-message sub-audit

## Scope and reproduction

Read `src/enron_importance/senders.py`, `prepare.py:48–67`, `config.yaml:27–40`, and all `tests/test_senders.py`. Independently counted templates from processed authored text by streaming parquet, reproduced the entire sender-flag set, and inspected **all 312 flagged profiles** plus the **40 highest-volume unflagged profiles**. For each profile I read volume, flags, first three modal templates and next three templates where available. I then inspected complete messages for suspicious human/mixed accounts, all 15 non-`Start Date:` Pete Davis messages, all 12 HotTap messages, and selected missed-feed and routine examples. This is not a message-level human gold set and does not establish global automation precision/recall.

Commands (repo cwd, no bytecode/repo writes):

```sh
PYTHONDONTWRITEBYTECODE=1 .venv/bin/python -u /tmp/enron-audit-20260925.Xj3qoO/identity_rank/audit_senders.py > /tmp/enron-audit-20260925.Xj3qoO/identity_rank/audit_senders.txt
PYTHONDONTWRITEBYTECODE=1 .venv/bin/python -u /tmp/enron-audit-20260925.Xj3qoO/identity_rank/sender_target_checks.py > /tmp/enron-audit-20260925.Xj3qoO/identity_rank/sender_target_checks.txt
```

Evidence: `sender_profiles_audit.json/.txt`, `routine_profiles_audit.json`, `sender_target_examples.json`, the two scripts and their stdout in the same scratch folder. Full profile text was inspected sequentially with `sed -n '1,355p'`, `'356,710p'`, `'711,1060p'`, and `'1061,1250p'`.

The **20,293 profiles/312 flags** reproduce. Of the 312: **287 name-rule only, 21 feed-rule only, four both**; **21** are internal addresses. The stored routine mask sums to **11,799 messages from 286 sender addresses**, of which **6,269 messages are internal**. A separate Counter recomputation independently obtains **11,799**, matching the stored mask; see `audit_senders.txt`. The total includes external senders: “routine messages from people” means “not flagged by this heuristic,” not verified human authors.

## Methods derived from code

### Plain language

The pipeline identifies automation in two ways: a mailbox address contains a system-like word, or almost all of its nonempty authored messages start in one of three repeated ways. To find repetition it lowercases text, replaces every number with a marker, collapses spaces, and keeps only the first 80 characters. At least 50 text-bearing messages are required for the behavior rule, and the three most common starts must cover at least 90%. Either rule excludes *all* messages from that address, including non-template human replies. For remaining addresses, any start repeated ten times is marked routine and excluded from text analysis, but its messages remain in the communication network. The thresholds are hand-set; the code does not fit or validate an automation classifier.

### Technical Methods

`template_of` (`senders.py:34–37`) maps non-string authored values to empty strings; applies lowercase, regex `\d+ → #`, regex `\s+ → single space`, strips ends, and truncates to 80 Unicode characters. The prefix length is hard-coded, despite config's broad claim that every parameter lives there. `name_rule` (`:24–29,40–42`) tests only the address local part, case-insensitively, for bounded tokens `no.reply/noreply/do.not.reply/mailer.daemon/postmaster/announce/announcements/administrator/admin/bounce/bounces/newsletter/listserv/majordomo/helpdesk/help.desk/system/notification(s)/alert(s)/mailbox`; separators are beginning/end or `.`, `_`, `-` with token-specific optional separators. It imposes no volume requirement. `sender_profiles` (`:53–65`) drops null senders, counts all messages per sender and nonempty-template messages separately, sums the top three normalized template frequencies among the latter, and sets feed iff `n_with_text >= 50` and share `>=0.9`. `internal` is exact suffix `@enron.com`; automation is name OR feed irrespective of internal status. `routine_messages` (`:69–74`) joins raw sender (missing→empty) and template by unit separator, counts occurrences globally, and labels nonempty templates with at least ten occurrences. `prepare.py:57` intersects with nonautomated sender; `:64–65` removes routine messages from the internal/nonautomated/nonempty text-analysis set. No nickname/person aggregation precedes this decision. The behavior rule and routine rule are therefore address-specific, and can treat aliases differently.

Paper disclosures needed: hand-selected thresholds and prefix rule; sender-level versus message-level exclusion; external/internal distinction; no validated “human” label; retention of routine messages in network but not NLP data; sensitivity/error audit, especially for the planned speech-act task.

## Major S1 — Account-level feed exclusion deletes verified human technical work

`senders.py:64–65` classifies the sender, and `prepare.py:51–52,64` excludes every message from that address. **Pete Davis has 3,933 messages**, top-three coverage **0.980422**, and all are excluded. A full check of the **15** messages whose authored text does not begin `Start Date:` finds **six visibly human replies/notes**, not just more scheduler notices:

- `maildir/guzman-m/notes_inbox/1236.` describes reproducing a production bug, identifying Schedule Crawler as the cause, removing erroneous finals, and asks colleagues to monitor the next import.
- `maildir/guzman-m/notes_inbox/1255.` asks which process causes the false finals in order to isolate and fix the bug.
- `maildir/causholli-m/deleted_items/104.` confirms removal from a mailing list and asks what group the recipient is now in.
- `maildir/platter-p/inbox/54.` is a personal conversation about remaining at UBS.
- `maildir/salisbury-h/read/294.` says `Done` in response to schedule crawler.
- `maildir/williams-w3/schedule_crawler/1431.` apologizes for omitting a recipient from the original distribution.

These are exactly the sorts of expertise/problem-solving/coordination signals Phase 3 proposes to study. The large majority of Pete's account traffic is genuinely templated; that does not make every message automated. Also `ipayit@enron.com` excludes all **112** messages but contains Sally McAdams' individual troubleshooting replies (`campbell-l/inbox/1057.`, `sturm-f/deleted_items/84.`). `helpdesk.hottap@enron.com` excludes all **12** messages by name despite concrete human work signed Deborah/Kim Perez, including checking allocation data and customer identifiers (`blair-l/deleted_items/296.`, `/300.`, `blair-l/reports___scheduled_quantity_report/1.`). These are shared human-operated mailboxes, not individual identities; the appropriate fix is not silently assign them to an employee.

An external specificity counterexample: all three `postmaster@oceanicrealty.com` messages are marked automated although they are individualized rental replies signed Melissa/Sam (`dasovich-j/notes_inbox/1195.`, `/1235.`, `/1498.`). External senders are excluded from the main internal analysis anyway, so this example is a classifier-validation issue rather than a demonstrated change to its core network.

**Impact:** makes exclusions depend on whether an employee sends alerts from their own address, potentially removing precisely the technical operational contributors of interest. **Fix:** classify messages/streams separately from entity type; keep non-template human communications from mixed accounts; retain role/shared-mailbox labels and provenance; add these corpus examples to regression tests and quantify sensitivity.

## Major S2 — Repetition misses obvious system streams, including 927 calendar artifacts in analysis

`outlook.team@enron.com` has **1,473 messages**, **1,472 nonempty authored texts**, top-three share **0.097826**, and is unflagged. Routine filtering removes **500**, leaving **972** nonempty analysis messages. Exactly **1,321** authored texts start `CALENDAR ENTRY:`, and **927** of these survive routine filtering. Example `maildir/blair-l/meetings/100.` is a structured appointment with description/date/time and chairperson Outlook Migration Team. It is not an employee's authored language. Subject-specific descriptions break the 80-character prefix templates into too many types for the top-three rule.

Exact extra count command:

```python
import pandas as pd
m = pd.read_parquet('data/processed/messages.parquet', columns=['sender','authored','routine','path'], filters=[('sender','==','outlook.team@enron.com')])
c = m.authored.str.startswith('CALENDAR ENTRY:')
print(c.sum(), (c & ~m.routine).sum())  # 1321 927
```

Two further verified false-negative mechanisms:

- `perfmgmt@enron.com`: **412 messages, zero automated, 163 routine, 249 retained in analysis**. Inspected examples are personalized performance-review notifications; salutations containing a different employee's name defeat prefix matching. `maildir/arnold-j/inbox/2.` explicitly says attached evaluation forms are for the recipient's direct reports, then names them. This is also a direct organizational-label/identity leakage source, not just generic boilerplate.
- `community-relations@enron.com`: **14 messages, zero automated/routine, all14 analysis**. Inspected records are structured contribution receipts with employee name/ID/payment fields, so low volume and personalization defeat both rules. No private fields need to be reproduced in the paper; use path `maildir/white-s/itinerary_receipt/3.`.

`arsystem@mailman.enron.com` (**1,191 messages**, top-three share0.594, unflagged;1,160 routine) illustrates the “more than three templates” failure too, but is external under the exact-suffix policy and not counted in the internal NLP set. `melissa.videtto@enron.com` correctly remains a person account yet retains a TRV report notification (`maildir/mckay-b/deleted_items/167.`), demonstrating need for message-level handling, not simply a longer denylist.

**Impact:** text features and network nodes can describe migration software, notification delivery and mailbox-capture patterns rather than employee function. Performance notifications may encode formal reporting relationships explicitly. **Fix:** distinguish structured calendar/report/receipt data from authored prose; detect known event types and boilerplate below sender level, normalize recipient-specific slots, and evaluate a labeled sample of retained as well as removed messages. Recompute the funnel/network after rules are independently validated.

## Major S3 — “Routine” removes speech acts that are the proposed outcome signal

The rule tests only repeated sender+prefix (`senders.py:69–74`), not whether the text is a report or system-generated. Among internal routine messages, **2,520** fall into93 template groups of at most25 characters; **149** are exactly `thanks`, `thanks.`, `thank you`, or `thank you.`. These are observed literal template counts, not all asserted to be valuable business speech acts.

Specific genuine instructions/commitments removed:

- Jeffrey Shankman: **51 `print` +50 `please print`** messages. Examples `maildir/shankman-j/sent/1006.` (Article on Cattle Industry), `/101.` (Summary of EES Bear Trap).
- Jeff Dasovich: **20 `will do.`** messages (`maildir/dasovich-j/sent/107.`).
- Angela White: **19 `approved` out of22 messages (86.4%)**, including `maildir/donoho-l/deleted_items/101.` (credit request Sempra Energy Trading) and `/75.` (credit request Astra Power). This directly demonstrates highly uneven person-level removal of a role-relevant speech act.
- Mark Taylor: **15 `looks good to me.`** messages, including `maildir/taylor-m/sent/1077.` about vacation.
- Drew Fossum:34 `pls print. thanks df` and19 punctuated variant; Elizabeth Sager:19 `please print`.

The same utterance is retained for a sender using it nine times and excluded for one using it ten times, across the entire research window, regardless of date, context or addressee. Therefore an NLP model of requests, approvals, delegation or responsiveness would lose classes of behavior disproportionately for frequent users. This is a demonstrated selection mechanism, not proof of its final effect size on an as-yet unbuilt model.

**Fix:** preserve human speech acts even when text repeats; flag routine content rather than blanket-remove it; separately classify boilerplate/report templates; report per-person/per-role retained fractions and run speech-act/importance results with and without the filter. Hold out the decision rules from the final evaluation sample.

## Tests and documentation

`tests/test_senders.py` verifies hand-made successful string matches, repetitive feeds, low-volume behavior, empty forwards and a human with a minority report template. It has no test protecting minority human messages once a mixed account crosses the feed threshold, no personalized calendar/HR notification case, no human helpdesk case, and no repeated human approval/delegation case. `test_feed_split_across_three_templates_is_flagged` includes60 templated messages and40 distinct note-like messages and intentionally expects whole-account exclusion at feed_share0.5. `test_person_with_weekly_report_keeps_their_other_messages` tests12 reports plus40 human questions below the production0.9 threshold; it does not test an above-threshold mixed account. `test_templated_feed_is_flagged_but_a_person_is_not` uses Pete Davis' real address with invented scheduler messages and confirms account exclusion, so it would pass while the real corpus human-message loss persists. These tests validate the implemented heuristic, not its safety for human speech-act retention.

Docstring `senders.py:9–15` says people do not repeat a handful of templates and that people sending routine reports are kept. Actual code has no such guarantee: a sufficiently template-dominated mixed account loses all human work (Pete Davis), while real approvals/instructions are discarded as routine. Labeling all unflagged addresses “people” and all flagged ones “automated” is overstated without entity-type and message-type validation.

No claim that every312 flagged sender is wrong, no estimated global false-positive rate, and no assertion that fixing these issues must erase baseline degree accuracy. Full labels for312addresses would require an adjudicated message-level sample; this audit establishes concrete counterexamples and predictable selection biases.
