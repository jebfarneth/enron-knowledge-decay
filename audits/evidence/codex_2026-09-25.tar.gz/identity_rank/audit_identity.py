from pathlib import Path
from collections import defaultdict, Counter
import hashlib, itertools, json, re
import pandas as pd
import numpy as np
from enron_importance.config import load_config
from enron_importance.identity import build_identities, normalize_name, NICKNAMES
from enron_importance.formal_rank import formal_ranks
from enron_importance.evaluate import pairwise_accuracy

ROOT=Path('/Users/jebfarneth/projects/enron-knowledge-decay')
OUT=Path('/tmp/enron-audit-20260925.Xj3qoO/identity_rank')
c=load_config()
m=pd.read_parquet(ROOT/'data/processed/messages.parquet',columns=['path','custodian','folder','sender','x_from','to','cc','date','authored','sender_internal','sender_automated'])
i=build_identities(m,c['senders']['internal_domain'])
old=pd.read_parquet(ROOT/'data/processed/identities.parquet')
t=pd.read_excel(ROOT/'data/raw'/c['formal_rank']['filename'],header=None,names=['name','title','note'])
r=formal_ranks(t,i,c['formal_rank']['levels'],c['formal_rank']['corrections'])
ranked=r.dropna(subset=['person_key','level']).groupby('person_key',as_index=False)['level'].max()
central=pd.read_parquet(ROOT/'data/processed/centrality.parquet')
print('IDENTITIES',len(i),i.person_key.nunique(),int(i.groupby('person_key').size().gt(1).sum()),'exact equality',i.equals(old))
print('TITLE',len(r),r.person_key.notna().sum(),len(r.dropna(subset=['person_key','level'])),len(ranked))
print('HASH',hashlib.sha256((ROOT/'data/raw'/c['formal_rank']['filename']).read_bytes()).hexdigest())
print('MATCHES',r.match.value_counts().to_dict())
print('TITLE COUNTS',r.groupby(['title','level']).size().to_string())
print('TITLES',r.to_string(index=False))
print('DUPLICATE TITLE PEOPLE',r[r.person_key.duplicated(False)&r.person_key.notna()].to_string(index=False))
print('UNCORRECTED MATCHES',formal_ranks(t,i,c['formal_rank']['levels'],{}).person_key.notna().sum())

mm=m.merge(i,left_on='sender',right_on='address',how='inner')
for source,key in c['formal_rank']['corrections'].items():
    sub=mm[mm.person_key==key]
    print('\nCORRECTION',source,'=>',key,'messages',len(sub),'addresses',sub.sender.value_counts().to_dict(),'xfrom',sub.x_from.value_counts().head(8).to_dict(),'custodians',sub.custodian.value_counts().head(6).to_dict())
    # Evidence from probable own sent mail first.
    own=sub[sub.folder.str.contains('sent',case=False)]
    print('SENT_EXAMPLES',own[['path','sender','x_from','date']].head(3).to_dict('records'))
    terms=source.lower().split()+key.split()
    for row in sub.itertuples():
        lines=[x for x in str(row.authored).splitlines() if any(term in x.lower() for term in terms if len(term)>3)]
        if lines:
            print('BODY_NAME_EVIDENCE',row.path,[x[:160] for x in lines[:2]])
            break

partners=defaultdict(set); cust=defaultdict(set); sentcust=defaultdict(Counter); volumes=Counter()
for row in m.itertuples():
    if not isinstance(row.sender,str): continue
    recipients=set(row.to)|set(row.cc)
    partners[row.sender].update(recipients)
    cust[row.sender].add(row.custodian)
    volumes[row.sender]+=1
    if 'sent' in row.folder.lower(): sentcust[row.sender][row.custodian]+=1
    for recipient in recipients: partners[recipient].add(row.sender)
aliases=[]
for key,g in i.groupby('person_key'):
    aa=list(g.address)
    if len(aa)<2: continue
    for a,b in itertools.combinations(aa,2):
        inter=len(partners[a]&partners[b]); union=len(partners[a]|partners[b])
        aliases.append({'key':key,'a':a,'b':b,'n_a':volumes[a],'n_b':volumes[b],'partners_a':len(partners[a]),'partners_b':len(partners[b]),'overlap':inter,'jaccard':inter/union if union else 0,'custodian_overlap':len(cust[a]&cust[b]),'sent_a':sentcust[a].most_common(2),'sent_b':sentcust[b].most_common(2)})
aa=pd.DataFrame(aliases); aa.to_json(OUT/'alias_pairs.json',orient='records',indent=2)
print('ALIAS_PAIR_AUDIT',len(aa),'disjoint',int(aa.overlap.eq(0).sum()),'both10_disjoint',int((aa.overlap.eq(0)&aa.n_a.ge(10)&aa.n_b.ge(10)).sum()))
print(aa[(aa.n_a.ge(5)&aa.n_b.ge(5))].sort_values(['jaccard','n_a']).head(70).to_string(index=False))
# All source normalized keys per address, detect conflicting source identities hidden by mode.
nk=m[m.sender_internal].assign(key=m.loc[m.sender_internal,'x_from'].map(normalize_name))
conf=nk.dropna(subset=['key']).groupby(['sender','key']).size().rename('n').reset_index()
conf['total']=conf.groupby('sender').n.transform('sum');conf['share']=conf.n/conf.total
many=conf.groupby('sender').size();print('ADDRESSES_MULTIPLE_NORMALIZED_KEYS',many.gt(1).sum())
print(conf[conf.sender.isin(many[many.gt(1)].index)&conf.n.ge(3)].sort_values(['sender','n']).to_string(index=False))
conf.to_csv(OUT/'sender_name_conflicts.csv',index=False)
# No alias inference for recipient-only aliases; remit to network auditor.
known=dict(zip(i.address,i.person_key)); recipients=set().union(*(set(x)|set(y) for x,y in zip(m.to,m.cc)))
unknown=sorted(a for a in recipients if a.endswith('@enron.com') and a not in known)
print('INTERNAL_RECIPIENT_ONLY_ADDRESSES',len(unknown))

# Custodian estimate: dominant internal person in each raw mailbox sent folder; require winner report.
raw=pd.read_parquet(ROOT/'data/interim/messages_raw.parquet',columns=['path','custodian','folder','sender','x_from'])
raw['person_key']=raw.sender.map(known)
sent=raw[raw.folder.str.contains('sent',case=False)&raw.person_key.notna()]
sc=sent.groupby(['custodian','person_key']).size().rename('n').reset_index().sort_values(['custodian','n'],ascending=[True,False])
best=sc.drop_duplicates('custodian').copy(); best['total']=best.custodian.map(sent.groupby('custodian').size()); best['share']=best.n/best.total
best.to_csv(OUT/'custodian_identity_candidates.csv',index=False)
custkeys=set(best.person_key)
print('CUSTODIAN_ESTIMATE',raw.custodian.nunique(),len(best),len(custkeys),'ranked matches',ranked.person_key.isin(custkeys).sum(),'of',len(ranked))
print('NON_CUSTODIAN_RANKED',ranked[~ranked.person_key.isin(custkeys)].to_string(index=False))
print('LOW_CONF_CUSTODIANS',best[best.share.lt(.9)].to_string(index=False))
print('NETWORK_CUSTODIANS',central.person_key.isin(custkeys).sum(),'of',len(central))
ev=ranked.merge(central,on='person_key',how='left').fillna(0)
print('TITLE_MAPPING_SENSITIVITY')
for name,mapping in [('default',{}),('CEO_equals_President',{6:5}),('top3_equal',{6:4,5:4}),('lawyer_excluded',None),('CEO_President_excluded',None),('trader_employee_excluded',None)]:
    temp=ev.copy()
    if name=='lawyer_excluded': temp=temp[~temp.person_key.isin(r.loc[r.title.eq('In House Lawyer'),'person_key'])]
    elif name=='CEO_President_excluded': temp=temp[temp.level.lt(5)]
    elif name=='trader_employee_excluded': temp=temp[temp.level.gt(0)]
    else: temp['level']=temp.level.replace(mapping)
    print(name,len(temp),int(np.triu(temp.level.to_numpy()[:,None]!=temp.level.to_numpy()[None,:],1).sum()),{metric:pairwise_accuracy(temp.level.to_numpy(),temp[metric].to_numpy()) for metric in ['degree','pagerank','in_strength','out_strength','betweenness']})
