# Independent adjudication of dedupe scratch evidence

Command: `PYTHONDONTWRITEBYTECODE=1 .venv/bin/python /tmp/enron-audit-20260925.Xj3qoO/identity_rank/adjudicate_dedupe.py` from repository root. This inspects saved JSON evidence only; it does not independently rescan the corpus or reproduce the complete aggregate counts.

## Random sample

`dedupe_sample40.json` contains 40 sampled duplicate-key groups, 115 inspected rows of 118 total group members. Three groups were truncated to five rows. Within every inspected group, exact parsed body strings, sender, parsed date, subject and the sorted union of To/Cc recipient addresses are identical. This supports ordinary-copy behavior in this sample, not proof that every removed copy is legitimate. Say **parsed body strings**, not raw body bytes; say **To/Cc recipient union**, not identical separate To and Cc headers. The scratch JSON does not preserve those distinctions.

## Recipient conflicts

`data_attacks.py:27–36` computes the union of raw recipient-address sets across a key group minus the retained row's recipient set, and sums this per group. Accordingly:

- 312 means duplicate-key groups with more than one distinct To/Cc union.
- 449 means omitted internal raw-address assignments summed across groups; not 449 distinct people, globally unique addresses, final network edges, or messages. Alias collapsing and other messages can preserve some sender-person edges. No downstream ablation is present here.
- 236 means groups with at least one omitted internal raw-address assignment.
- 194 means the kept copy has a nonempty recipient set disjoint from at least one discarded copy's nonempty set. It does **not** mean every pair of copies within those groups is disjoint, and it is not restricted to internal recipients.

Concrete example (key `3e8078a3c163a9137c086722c515ba399dc74b81`, eight rows, five saved): `maildir/bass-e/sent/69.` and `/70.` both show sender Eric Bass, subject `Fuzzy Math!`, parsed date `2000-11-15 11:02:00+00:00`. The former is to Jim Schwieger; the latter is to seven completely different raw addresses, including Brian Hoskins, Matthew Lenhart, Shanna Husser and Timothy Blanchard. Corresponding `_sent_mail/167.` and `/168.` repeat the two distributions, strengthening the evidence that two distribution events were collapsed. Raw body strings differ by a trailing newline but normalized bodies agree. Because the source timestamp here has seconds `:00`, describe as **same recorded timestamp / same minute**, not evidence the human deliberately sent at the exact same second. Regardless of whether original deliveries were separate sends or incomplete exported recipient views, the present merge loses distribution information. `dedupe.py:71–77` keeps folder-rank/path first without merging recipients.

## Hour-offset candidates

The aggregate summary gives 1,499 adjacent candidate pairs (1,198 at four hours;253 at three;28 at two;16 at five;3 at eight;1 at one) and 2,992 participating retained content keys. `timezone_candidates.json` contains only the first 70, not all1,499. Matching is on same sender plus **normalized** subject/body, with body length over100, after ordinary deduplication. Only adjacent timestamps within each timeless-key group are inspected; groups larger than1,500 are skipped. Therefore the number is an intentionally constrained candidate screen, not a count of proven missed duplicates or all potential cases.

I inspected all seven raw-header pairs in `timezone_header_evidence.json`. Each pair has the same numeric timezone offset on both Date headers, but the wall-clock times differ by three or four hours; Message-IDs differ. Example: Allen inbox70 has `Tue, 27 Nov 2001 13:20:35 -0800 (PST)`, while Swerzbin inbox154 has `Tue, 27 Nov 2001 17:20:35 -0800 (PST)`. This is **not** the parser failing to canonicalize two equivalent timezone representations; the raw Date headers themselves disagree on the instant. Source/export timestamp corruption is plausible, supported by export-folder differences and the exactly matching seconds, but repeated sending is not ruled out for all candidates. Use “probable export-time shifts requiring adjudication,” not “1,499 proven duplicates caused by incorrect timezone parsing.” The synthetic equivalent-timezone check in the summary actually passes, consistent with correct UTC normalization.

Strong within-sender example: Williams `bill_williams_iii/778.` vs `sent_items/434.` has `Tue, 3 Jul 2001 11:08:36 -0700` vs `14:08:36 -0700`, with distinct Non-Privileged vs ExMerge source labels. These are useful evidence of source-dependent timing artifacts, still not a substitute for validating every candidate.
