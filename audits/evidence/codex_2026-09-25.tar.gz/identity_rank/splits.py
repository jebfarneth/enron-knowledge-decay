from pathlib import Path
from collections import defaultdict,Counter
import re
import pandas as pd
ROOT=Path('/Users/jebfarneth/projects/enron-knowledge-decay')
i=pd.read_parquet(ROOT/'data/processed/identities.parquet')
m=pd.read_parquet(ROOT/'data/processed/messages.parquet',columns=['path','sender','x_from','to','cc','authored','custodian','folder'])
m['person_key']=m.sender.map(dict(zip(i.address,i.person_key)))
# CN fields are evidence only, not assertion of ground truth.
m['cn']=m.x_from.str.extract(r'(?i)/CN=([^/>]+)>',expand=False).str.lower()
g=m.dropna(subset=['person_key','cn']).groupby('cn').person_key.nunique()
print('CN_MULTIKEYS',g.gt(1).sum())
for cn in g[g.gt(1)].index:
 s=m[m.cn.eq(cn)]
 print('CN',cn,s.groupby(['sender','person_key','x_from']).size().to_string())
 print(s[['path','sender','x_from']].head(2).to_dict('records'))
for pair in [('donald.black@enron.com','don.black@enron.com'),('donald.miller@enron.com','don.miller@enron.com'),('susan.m.scott@enron.com','susan.scott@enron.com'),('jr..legal@enron.com','james.derrick@enron.com')]:
 for addr in pair:
  s=m[m.sender.eq(addr)];print('SPLIT',addr,len(s),s.x_from.value_counts().to_dict())
  for row in s.head(3).itertuples():print(row.path,repr(row.authored[:360]))
# Auditable corpus evidence linking Harpreet and Harry.
raw=pd.read_parquet(ROOT/'data/interim/messages_raw.parquet',columns=['path','sender','x_from','body','custodian','folder'])
s=raw[raw.body.str.contains('harpreet',case=False,na=False)]
print('HARPREET_RAW',len(s))
for row in s.itertuples():
 hits=list(re.finditer('harpreet',row.body,re.I))
 print(row.path,[row.body[max(0,x.start()-70):x.end()+100].replace('\n',' ') for x in hits[:2]])
 if len(s)>50 and row.Index==s.index[49]:break
for box in ['lay-k','skilling-j','whalley-l','hodge-j','hernandez-j','fischer-m']:
 s=raw[raw.custodian.eq(box)&raw.folder.str.contains('sent',case=False)]
 print('BOX_SENT',box,s.groupby(['sender','x_from']).size().sort_values(ascending=False).head(6).to_string())
