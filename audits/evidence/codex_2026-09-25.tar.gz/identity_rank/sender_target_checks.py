from pathlib import Path
from collections import Counter
import json
import pandas as pd
from enron_importance.senders import template_of

out=Path('/tmp/enron-audit-20260925.Xj3qoO/identity_rank')
senders=['pete.davis@enron.com','outlook.team@enron.com','helpdesk.hottap@enron.com','ipayit@enron.com','postmaster@oceanicrealty.com','g.campbell@pecorp.com','melissa.videtto@enron.com','community-relations@enron.com','perfmgmt@enron.com','kenneth.thibodeaux@enron.com']
m=pd.read_parquet('data/processed/messages.parquet',columns=['sender','path','subject','authored','routine','sender_automated','sender_internal','to','cc'],filters=[('sender','in',senders)])
records=[]
for s,g in m.groupby('sender'):
 print('\nSENDER',s,'n',len(g),'auto',int(g.sender_automated.sum()),'routine',int(g.routine.sum()),'analysis',int((g.sender_internal&~g.sender_automated&~g.routine&g.authored.ne('')).sum()))
 if s=='pete.davis@enron.com':
  q=g[~g.authored.str.lower().str.startswith('start date:')];print('NOT_STARTDATE',len(q))
 elif s=='outlook.team@enron.com':
  q=g[~g.authored.str.startswith('CALENDAR ENTRY:')];print('NOT_CALENDAR',len(q))
  for r in g[~g.routine & g.authored.ne('')].head(3).to_dict('records'):print('ANALYSIS_CALENDAR',r['path'],r['subject'],r['authored'][:500])
 elif s in ['helpdesk.hottap@enron.com','ipayit@enron.com','g.campbell@pecorp.com','postmaster@oceanicrealty.com']:
  ts=g.authored.map(template_of);tops=set(ts.value_counts().head(3).index)
  q=g[~ts.isin(tops)] if len(g)>20 else g
 else:
  q=g[~g.routine].head(8)
 for r in q.to_dict('records'):
  print(r['path'],r['subject'],'routine',r['routine'],'\n',r['authored'][:5000]);records.append({k:r[k] for k in ['sender','path','subject','authored','routine','sender_automated']})
(out/'sender_target_examples.json').write_text(json.dumps(records,indent=2))
r=json.loads((out/'routine_profiles_audit.json').read_text())
short=[x for x in r if x['sender'].endswith('@enron.com') and len(x['template'])<=25]
print('SHORT_INTERNAL',sum(x['count'] for x in short),'GROUPS',len(short))
print('THANKS_INTERNAL',sum(x['count'] for x in r if x['sender'].endswith('@enron.com') and x['template'] in ['thanks','thanks.','thank you','thank you.']))
print('INSTRUCTIONS_INTERNAL',[(x['sender'],x['template'],x['count']) for x in short if any(k in x['template'] for k in ['print','approved','looks good','will do'])])
