# Identity and formal-rank independent audit

Repository inspected read-only: `/Users/jebfarneth/projects/enron-knowledge-decay`.
Scratch evidence directory: `/tmp/enron-audit-20260925.Xj3qoO/identity_rank`.
No repository files, configuration, tests, generated tables, or history modified.

## Reproduction commands

All Python commands below run from the repository root with the locked existing interpreter and bytecode disabled:

```sh
PYTHONDONTWRITEBYTECODE=1 .venv/bin/python /tmp/enron-audit-20260925.Xj3qoO/identity_rank/audit_identity.py > /tmp/enron-audit-20260925.Xj3qoO/identity_rank/audit_identity.txt
PYTHONDONTWRITEBYTECODE=1 .venv/bin/python -u /tmp/enron-audit-20260925.Xj3qoO/identity_rank/deep_identity.py > /tmp/enron-audit-20260925.Xj3qoO/identity_rank/deep_identity.txt
PYTHONDONTWRITEBYTECODE=1 .venv/bin/python -u /tmp/enron-audit-20260925.Xj3qoO/identity_rank/splits.py > /tmp/enron-audit-20260925.Xj3qoO/identity_rank/splits.txt
```

`audit_identity.py` recomputes `build_identities` and `formal_ranks` from the processed messages, config, and raw spreadsheet, then compares the entire identity table with the stored artifact. It also audits every multi-address pair's neighbors/custodians, all sender-name conflicts, and title mapping sensitivity. `deep_identity.py` inspects flagged identity groups and source-label evidence. `splits.py` independently groups directory CN identifiers and searches raw messages for the nontrivial Harpreet/Harry alias. These scripts are the full executable evidence, not pseudocode.

## Methods derived from code

### Identity resolution — plain language

The program learns an identity only for addresses that actually sent a message and end with `@enron.com`. For each such address, it cleans the sender's display names, reducing each to a first and last name. It removes middle names, initials and generational suffixes, and substitutes a hard-coded list of nickname forms. The most frequent resulting name becomes the identity for every message from that address; all addresses given the same name are merged. If no usable display name is available, the address remains its own identity. The procedure does not check whether an address represents a person, a shared mailbox, or a missing-address placeholder, and it does not resolve recipient-only addresses.

### Identity resolution — technical Methods

`identity.py:44–59` removes angle-bracket and parenthesized substrings, strips surrounding quotes, rejects remaining `@` or `/`, and reverses the material around the first comma. It lowercases, replaces everything except ASCII a–z, spaces, apostrophes and hyphens with spaces, trims edge apostrophes/hyphens, and drops single-letter tokens plus `jr/sr/ii/iii/iv`. Names with fewer than two surviving tokens are unusable. The key is `NICKNAMES.get(first,first) + last`, retaining no middle tokens. The nickname table and suffix rules are hard-coded in `identity.py:22–41`, not config. `build_identities` (`:62–79`) filters sender suffix, pools counts of *normalized* names by address, sorts sender ascending and count descending, and keeps the first normalized name for each address; it imposes no minimum evidence, purity, or dominance threshold. Remaining addresses fall back to their literal address. Output is one row per internal sender address with `address/person_key/display_name`; display_name is simply title-cased key, not the original display header. Important paper disclosures: corpus-only heuristic entity resolution; role/shared/unknown address treatment; recipient-only fallback; normalization/ambiguity policy and audit error rates. The docstring's 'most common X-From display name is normalized' is imprecise: normalized variants are counted together *before* choosing the most common key.

### Formal-rank labels — plain language

The program downloads or reuses an archived employee-title spreadsheet and verifies its stored checksum. It maps each listed name through the same first/last-name cleaning, except eleven configured names receive manual corrections. A match means only that the key appears in the identity table. A configured lookup turns the title into an ordinal number. Names without matches and missing/unrecognized titles remain missing. Additional notes in the spreadsheet, including more specific executive roles, are ignored. The evaluator later merges duplicate rows by choosing the highest title number for a person; it has no dated job history or reporting lines.

### Formal-rank labels — technical Methods

`formal_rank.py:24–34` retrieves config URL if the raw XLS is absent and hashes its bytes, exiting on SHA mismatch. `:62–68` reads its three columns as `name/title/note`, reads sender/X-From from processed messages, regenerates the identity table, and saves identities and rank rows. `formal_ranks` (`:37–56`) strips string names/titles, applies exact case-sensitive correction-dictionary lookup before `normalize_name`, checks key membership in `identities.person_key`, and looks up `levels[title]`. Notes are never consulted. Levels (`config.yaml:55–65`) are CEO 6, President 5, Managing Director 4, Vice President 3, Director/Director of Trading 2, Manager/In House Lawyer 1, Trader/Employee 0. Eleven corrections are `config.yaml:70–81`. Evaluation keeps max level per person (`evaluate.py:58–60`). Paper needs to describe labels as a coarse, time-agnostic title proxy; disclose conflicting titles, ignored notes, missing labels and non-representative sampling. It cannot present these as verified reporting relationships or functional-importance ground truth.

## Reproduction results

| Claimed output | Independently obtained | Status |
|---|---:|---|
| Internal sender addresses | 6,455 | Match |
| Resolved person keys | 5,866 | Match as **keys**, not verified people |
| Keys with >1 address | 525 | Match |
| Listed names | 161 | Match |
| Matched rows | 160 (149 normalization +11 corrections) | Match |
| Titled matched rows | 131 | Intermediate fact |
| Distinct matched titled keys | 129 | Match |
| Identity stored-table comparison | `i.equals(old) == True` | Match |
| Raw XLS SHA-256 | `5f67ea06209a51a57c5b05608cc9f56c58c97e62892735eed4232313ff54c071` | Match |

## Major findings

### M-ID1. The generic missing-address mailbox becomes Don Miller and assigns unrelated people and feeds to him

Code: `identity.py:67–78` ignores unusable names when voting and propagates the winning name to the entire address. Evidence: `deep_identity.py`, `PLACEHOLDER IDENTITY` output. `no.address@enron.com` has **778 deduplicated messages**, all marked `sender_automated=False`. Only 138 have usable normalized names: 98 Don Miller, 17 Mark Evans, 12 Aaron Brown, 3 Clemens Ste, 2 David Oxley, and one each Jennifer Rub, Mark Palmer, Mark Taylor, Donna Lowry, Charla Stuart and Sally Beck. The remaining **640** have unusable names, often corporate feeds. All 778 nevertheless become `don miller`, together with the 161 messages genuinely using `don.miller@enron.com`.

Examples: `maildir/arnold-j/inbox/31.` has `X-From: Public Relations@ENRON`; `maildir/arnold-j/inbox/41.` is `Corporate Security@ENRON`; `maildir/arora-h/inbox/67.` is `Corporate Benefits@ENRON`. These are all assigned to Don Miller, not just a speculative homonym ambiguity. Stored centrality gives the combined Don Miller node degree **491**, betweenness **7,855,152**. The separate network audit now reports a placeholder-exclusion ablation: degree falls **491→128**, while aggregate title-ordering accuracy remains similar. See `network_eval/noaddress.py` and `noaddress_output.txt`; these are not claimed to be his true fully adjudicated centralities.

Impact: person-level language profiles and network structure mix distinct authors and system traffic. Phase 3 models could infer role, topics, and importance from misattributed corporate announcements. Fix: quarantine source-placeholder addresses, distinguish record-specific author identity from mailbox identity, use confidence/evidence fields, and never let an address-level plurality classify a generic missing-address address. Audit all sixteen addresses with multiple usable name keys; the spreadsheet `sender_name_conflicts.csv` lists them.

### M-ID2. Number stripping collapses six different temporary/legal mailboxes into one person

Code: `identity.py:23,54–59` drops digits, then retains only first/last tokens. Evidence: `deep_identity.py` `KEY legal temp`. Addresses `legal.1`, `.2`, `.3`, `.4`, `.5`, and `.7` at enron.com, with original names `Legal Temp 1/2/3/4/5/7`, collapse into one `legal temp` key: **78 messages** (22,16,4,5,1,30). `maildir/haedicke-m/notes_inbox/450.` is signed `Regards, Keegan Farrell`; `maildir/sager-e/notes_inbox/123.` directs contact to Lavon Wilson; `maildir/shackleton-s/notes_inbox/3226.` is signed `Gaby`. The numbered account distinction is erased despite distinct author evidence. The combined node's degree is **68**. The source also contains role nodes `office chairman` (87 messages across four addresses) and `enron chairman` (47 across two), which are not individual employees.

Impact: individual functional-importance and topic-ownership analyses acquire artificial composite people; common-role names are especially exposed. Fix: classify role/shared mailboxes separately, preserve numeric identity-bearing tokens, retain full-name/CN evidence, and refuse merges based solely on generic labels. Do not simply map corporate-office mail to the executive: delegation must be modeled explicitly.

### M-ID3. Display-name-only linking splits aliases even when the original directory identifier provides corroboration

Code: `identity.py:22,48,55–59` discards directory identifiers then uses a small nickname dictionary. Evidence: `splits.py` finds **19 directory CN values associated with multiple person keys**; these are candidate collisions/splits, not nineteen adjudicated people (some are role mailboxes). Concrete high-confidence example: `albert.meyers@enron.com` and `bert.meyers@enron.com` share `/O=ENRON/OU=NA/CN=RECIPIENTS/CN=BMEYERS`, with **44 and 53** such sender headers, yet remain `albert meyers` and `bert meyers`. Examples include `maildir/dean-c/deleted_items/10.` (Albert); all exact CN groups are in `splits.txt`. Stored degrees are **33 and 40**; unioning their graph neighbors yields **58**, excluding the two aliases themselves. Albert Meyers is a labeled evaluation person.

Other corroborated name variants sharing directory CN include Alex/Alexandra Villarreal (`AVILLAR4`), Georganne/Georgeanne Hodges (`GHODGES`), Laura O'Keefe/OKeefe (`LOKEEFE`), Mathew/Matt Smith (`MSMITH18`). Avoid mechanically merging all shared CN: announcement mailboxes use them for multiple authors.

Impact: per-person connectivity and text samples are fragmented, including at least one evaluation target; author-disjoint evaluation can leak through unresolved aliases. Fix: retain directory identifiers as evidence, develop a documented probabilistic or rule-plus-review linker, classify shared-account exceptions, then validate on labeled merge/non-merge pairs and rerun all results.

### M-ID4. Two explicitly distinguished people, Mark A and Mark E Taylor, are merged

Source rule: `identity.py:54–59` drops middle initials, and `:67–78` propagates a modal normalized key over a whole raw address. Independent thread-review lead was then checked with a targeted parquet query, without reloading the corpus. Exact command:

```sh
PYTHONDONTWRITEBYTECODE=1 .venv/bin/python /tmp/enron-audit-20260925.Xj3qoO/identity_rank/mark_taylor_evidence.py > /tmp/enron-audit-20260925.Xj3qoO/identity_rank/mark_taylor_evidence.txt
```

`maildir/taylor-m/sent_items/336.` is sent by `.taylor@enron.com`, X-From `Taylor, Mark E (Legal)` with directory CN `MTAYLO1`. Its authored text explicitly requests deletion of **Mark A Taylor** from a distribution and adding the writer as **Mark E Taylor**. The raw quoted chain also shows Mark A forwarding to Mark E, independently establishing two people rather than merely two spellings. The identities table nevertheless maps `.taylor@enron.com` (465 messages), `a.taylor@enron.com` (10), and `mark.taylor@enron.com` (1,966) into the same `mark taylor` key.

All465 `.taylor` X-From headers identify Mark E/MTAYLO1. Nine of10 `a.taylor` headers identify Mark A with distinct directory CN `NOTESADDR/CN=947B69F4-7B3595B3-86256879-579CBC`; examples are `maildir/taylor-m/archive/2001_06/5.` and `/6.`. The remaining `a.taylor` row, `maildir/neal-s/deleted_items/399.`, identifies Charles A Taylor/CN `CTAYLOR6`, exposing another synthetic-address ambiguity. `mark.taylor` itself includes19 explicit `Mark A Taylor` and40 explicit `Mark E Taylor` headers, as well as generic and legal forms. Thus separating only the three raw addresses would not completely repair the mixed authorship. Counts quantify the **2,441-record combined key**, not2,441 false records; ambiguous generic-name records remain unadjudicated. Evidence: `mark_taylor_evidence.json/.txt` and the raw-body excerpt in `clean_threads/unlinked_quoted_candidate_pairs.json` (record with index233345).

Impact: this is a directly established first/last-name collision between real individuals, beyond role mailboxes/placeholders. It also shows why blindly making thread matching identity-aware can add false recipient matches: Mark A's presence on a list is not proof Mark E received it. Fix: preserve initials and directory identifiers, assign record-level evidence/confidence for synthetic address collisions, adjudicate ambiguous generic rows, and validate negative homonym pairs before alias-aware threading. No graph-repair effect size was computed for this new case.

### M-RANK1. Title conflict handling is unsupported, and source notes contradict coarse assigned levels

Code: `formal_rank.py:46–55` ignores `note`; `evaluate.py:59–60` selects max level. In the raw spreadsheet, `Micheal Swerzzbin` is Vice President while `Mike Swerzbin` is Trader, and `James Schweiger` is Vice President while `Jim Schwieger` is Trader. The corrected identities are reasonable but selecting the higher title is not a verified correction. A primary contemporary source explicitly identified these **same two conflicts** and dropped the Vice President versions after comparison to FERC files: [Diesner & Carley, 2005, p.5 footnote 3](https://jdiesnerlab.ischool.illinois.edu/publications/diesner_carley_siam_enron_03_05.pdf).

The source XLS also says `Sally Beck | Employee | Chief Operating Officer`, `Rick Buy | Manager | Chief Risk Management Officer`, and `Rod Hayslett | Vice President | Also Chief Financial Officer and Treasurer`. The pipeline assigns levels 0,1,3, respectively, without using those notes. This is an observable mismatch between a generic title column and richer source information, not proof of the correct global rank of each subsidiary role. Independently inspected corpus evidence is stronger than notes alone: sender-authored `maildir/kaminski-v/all_documents/11199.` (2000-06-02) and `/5603.` (2000-06-19) contain the signature `Vincent Kaminski / Managing Director`, yet the benchmark assigns Manager, level1. `maildir/buy-r/sent_items/208.` (2001-03-21) contains `Executive Vice President / Chief Risk Officer and member of VP PRC Committee`, while Richard Buy is level1. Sally Beck's source messages contain both Vice President and later Managing Director descriptions. The benchmark is not a faithful representation of even its observed historical titles.

Sensitivity (`deep_identity.py`, original measures held fixed): max-title version has 6,285 pairs and degree **0.647494**, PageRank **0.614002**; setting only the two conflicted people to Trader produces 6,235 pairs, degree **0.651724**, PageRank **0.616359**. Excluding them produces 6,081 pairs, degree **0.651044**. Thus this correction does **not** erase the numerical degree result; the issue is invalid confidence in labels and their meaning. `audit_identity.py` additionally finds removing CEO/President rows leaves 121 people/5,301 pairs, degree **0.594793** versus 0.647494 overall. Treat this as subgroup sensitivity, not cherry-picked replacement.

Fix: preserve source rows and provenance, create an explicit conflict/unknown flag, consult dated independent roles or reporting lines, evaluate corrected/excluded alternatives, and report a title-proxy sensitivity analysis. Do not collapse job family and seniority into one unqualified ground truth for all Enron employees.

## Alias-disjointness and custodian checks: findings versus non-findings

All **664** address pairs inside multi-address keys were checked for To/Cc communication-partner overlap (incoming and outgoing). **94** pairs have zero overlapping partners, but only **3** zero-overlap pairs have at least 10 sent messages from both addresses. Sparse observation explains many such cases, so disjointness alone is **not** counted as a false merge. Example candidate `christopher smith`: 35 messages from `a..smith`, five from `christopher.smith`, disjoint partners/custodians, with IT-infrastructure versus valuation subject matter. This warrants adjudication, but the current audit does not establish two individuals. The full `alias_pairs.json` contains overlaps, message counts, custodians and sent-folder counts.

An in-process ablation clearing `NICKNAMES` without editing source yields **5,906** keys rather than 5,866; **41** current key groups pool multiple no-nickname keys. The difference is not simply41 because normalization can also change which key wins an address-level plurality. The tested candidates are listed in `deep_identity.txt`. I did not prove an additional false merge attributable to NICKNAMES alone; the Christopher Smith case remains unadjudicated. Blanket expansion of the nickname table is not the recommended fix because it could worsen homonym merging.

A dominant-internal-sender estimate of mailbox owners covered 148 of 150 custodians, yielded 147 keys, and overlaps **102/129** labeled identities. It is **not a gold owner map**: Kenneth Lay and Jeff Skilling's sent folders contain more assistant-sent mail than executive-sent mail (Lay: Rosalee Fleming497 versus Kenneth15; Skilling: Sherri Sera380 versus Jeff76). `hodge-j` contains Jeffrey T Hodge93 and John Hodge44 with different directory CNs; `hernandez-j` contains Judy442 and Juan215. Consequently the 102 count is an approximate diagnostic, not a final exact estimate of evaluation-set representativeness. Completed network controls use this102 baseline and explicit broader104/106 mailbox-access proxies; their trivial custodian/volume predictors do not match degree's ordering accuracy. See `network_eval/controls_output.txt`. The original hierarchy paper explicitly identifies title-list coverage as core-mailbox-centric: [Agarwal et al. 2012](https://aclanthology.org/P12-2032.pdf), p.161. No claim of population-representative labels is justified.

## Title-source provenance and the eleven corrections

Independent network retrieval command (successful, 25,088 bytes):

```sh
curl -L --max-time 25 --fail -o /tmp/enron-audit-20260925.Xj3qoO/identity_rank/title_refetched.xls 'https://web.archive.org/web/20130918164648id_/http://www.isi.edu:80/~adibi/Enron/Enron_Employee_Status.xls'
shasum -a 256 /tmp/enron-audit-20260925.Xj3qoO/identity_rank/title_refetched.xls
```

It matches the pinned SHA byte for byte. [Agarwal et al. 2012](https://aclanthology.org/P12-2032.pdf) cites the original exact XLS filename; [Diesner & Carley 2005](https://jdiesnerlab.ischool.illinois.edu/publications/diesner_carley_siam_enron_03_05.pdf) reports 161 names/132 titled rows, exactly matching the raw sheet, and the same conflicting names. This strongly corroborates artifact provenance. It is not authentication of every historical title; no publisher-signed checksum or row-level underlying court-document provenance was available.

All eleven target spellings are independently present in sender/X-From evidence. Counts below refer to deduplicated processed messages assigned the target key, not independent evidence of job title:

| Source name → key | Messages | Corpus path and observed sender evidence |
|---|---:|---|
| Micheal Swerzzbin → michael swerzbin |75| `maildir/swerzbin-m/sent_items/1.`; `mike.swerzbin@enron.com`, `Swerzbin, Mike .../CN=MSWERZB` |
| James Schweiger → james schwieger |184| `maildir/schwieger-j/sent_items/1.`; `jim.schwieger@enron.com`, `Jim Schwieger` |
| TimothyHeizenrader → timothy heizenrader |58| `maildir/allen-p/notes_inbox/29.`; `tim.heizenrader@enron.com`, `Tim Heizenrader`; other headers explicitly `Heizenrader, Timothy` |
| Douglas Gilberth-Smith → douglas gilbert-smith |115| `maildir/gilbertsmith-d/sent_items/1.`; `doug.gilbert-smith@enron.com`, `Gilbert-smith, Doug .../CN=DSMITH3` |
| Thomos Alonso → thomas alonso |8| `maildir/salisbury-h/holden_s/4.`; `tom.alonso@enron.com`, `Alonso, Tom .../CN=TALONSO` |
| Cristopher Foster → christopher foster |267| `maildir/dasovich-j/notes_inbox/12101.`; `chris.foster@enron.com`, `Chris H Foster` |
| John Lloldra → john llodra |29| `maildir/baughman-d/deleted_items/360.`; `john.llodra@enron.com`, `Llodra, John .../CN=JLLODRA` |
| Eric Lynder → eric linder |12| `maildir/linder-e/_sent_mail/1.`; `eric.linder@enron.com`, `Eric Linder` |
| Daron Giron → darron giron |1,092| `maildir/giron-d/sent/1.`; `darron.giron@enron.com`, `Darron C Giron` |
| John Giffith → john griffith |312| `maildir/griffith-j/sent_items/1.`; `john.griffith@enron.com`, `Griffith, John .../CN=JGRIFFIT` |
| Harpreet Arora → harry arora |87| `maildir/arora-h/sent/1.`; `harry.arora@enron.com`, `Harry Arora`; raw `maildir/arora-h/inbox/saved_mail/53.` quotes Harry explaining it is a short form of his real name Harpreet |

For Heizenrader, Alonso, Foster and Llodra, retained deduplicated examples were in recipients' folders rather than a custodian's sent folder. They are sender-authored message records, not proof the author inspected an own-mailbox sent copy as config commentary might imply. Harpreet/Harry is an alias rather than a spelling error. None of these verification results validates the attached seniority label.

## Tests inspected and missing checks

`tests/test_identity.py:6–43` comprises hand-made display formats, unusable strings, one constructed alias merge, suffix stripping, and three nickname cases. It does not test placeholder addresses, multi-author addresses, numbered role accounts, conflicting directory identities, false-split CN evidence, or majority confidence. Its suffix test deliberately expects `John Smith III`→`john smith`; it would pass even if two generations were wrongly merged. No data-based error bound follows from those fixtures. `tests/test_formal_rank.py:12–30` tests normalized matches, one supplied correction, and missing/unmatched entries; it does not test conflicting title rows, ignored notes, dated roles, manual correction authenticity, or representativeness. Concrete fixes should add adjudicated real-corpus regression cases, not merely synthetic strings engineered to satisfy the current implementation.

## Phase 3 risks specific to this audit

- Partition data by reviewed person clusters, not raw sender addresses: the Albert/Bert split demonstrates alias leakage across author splits.
- Remove/quarantine placeholder and role-mailbox nodes before person-level text aggregation, or label them as separate entity types. Otherwise model predictions describe corporate communications and assistants rather than the named employee.
- Preserve and audit delegated-author behavior. The top sender in a CEO's sent folder is not necessarily the CEO; metadata/paths must not be model features or labels without justification.
- Treat formal rank as a noisy outcome with dated provenance, not validation of functional importance; preregister sensitivity to disputed labels and source-note information.

## Not verified

No population-wide name-linking accuracy is claimed. Shared CN and partner overlap are evidence, not universal ground truth. Complete custodian ownership, historical title dates/reporting lines and row-level source evidence behind the archived XLS were not established. Full corrected-network and NLP-impact estimates were not run by this sub-audit; the reported false identities establish concrete data problems without claiming that all baseline accuracy disappears.
