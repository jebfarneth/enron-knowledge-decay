from pathlib import Path
import pandas as pd, json
from enron_importance.clean import authored_text,reply_start
ROOT=Path('/Users/jebfarneth/projects/enron-knowledge-decay')
OUT=Path('/tmp/enron-audit-20260925.Xj3qoO/identity_rank')
m=pd.read_parquet(ROOT/'data/processed/messages.parquet',columns=['path','sender','subject','authored','has_quoted'])
s=m[m.has_quoted].sample(200,random_state=20260925)
raw=pd.read_parquet(ROOT/'data/interim/messages_raw.parquet',columns=['path','body'],filters=[('path','in',s.path.to_list())]).set_index('path')
records=[]
for ordinal,(i,row) in enumerate(s.iterrows()):
 body=raw.loc[row.path,'body']
 records.append({'sample_id':ordinal,'index':int(i),'path':row.path,'sender':row.sender,'subject':row.subject,'body':body,'authored':row.authored,'cut':reply_start(body)})
(OUT/'manual_clean_sample200_early.json').write_text(json.dumps(records,ensure_ascii=False,indent=2)+'\n')
print('records',len(records),'bodychars',sum(len(x['body']) for x in records),'secondhalf',sum(len(x['body']) for x in records[100:]))
