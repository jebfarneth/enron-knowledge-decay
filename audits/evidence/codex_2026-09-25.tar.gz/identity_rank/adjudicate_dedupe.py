import json,re
from pathlib import Path

O=Path('/tmp/enron-audit-20260925.Xj3qoO')
sample=json.loads((O/'dedupe_sample40.json').read_text())
print('SAMPLE',len(sample),'inspected_rows',sum(len(g['rows']) for g in sample),'all_group_members',sum(g['n'] for g in sample),'truncated_groups',sum(g['n']>len(g['rows']) for g in sample))
for field in ['body','recipients','sender','date','subject']:
    bad=[(g['key'],len({json.dumps(r[field],sort_keys=True) for r in g['rows']})) for g in sample if len({json.dumps(r[field],sort_keys=True) for r in g['rows']})!=1]
    print('SAMPLE differences',field,bad)
conf=json.loads((O/'dedupe_recipient_examples.json').read_text())
print('CONFLICT example groups',len(conf),'truncated',sum(g['n']>len(g['rows']) for g in conf))
for g in conf:
    if any('bass-e/sent/69.' in r['path'] or 'bass-e/sent/70.' in r['path'] for r in g['rows']):
        print('BASS group',g['key'],'n',g['n'],'disjoint',g['disjoint'])
        for r in g['rows']:
            print({k:r[k] for k in ['path','sender','date','subject','recipients']},'body',repr(r['body'][:220]))
tz=json.loads((O/'timezone_candidates.json').read_text())
print('TZ serialized pairs',len(tz),'delta_counts serialized subset',{d:sum(t['delta_seconds']==d for t in tz) for d in sorted({t['delta_seconds'] for t in tz})})
headers=json.loads((O/'timezone_header_evidence.json').read_text())
print('TZ raw header pairs',len(headers))
for pair in headers:
    print('PAIR delta',pair['delta_seconds'])
    for r in pair['rows']:
        print(' ',r['path'],'UTC',r['date'])
        for field in ['Message-ID','Date','X-Folder','X-Origin','X-FileName']:
            found=re.search('^'+field+r':[^\r\n]*',r['raw_headers'],flags=re.M|re.I)
            print('  ',found.group(0) if found else field+' MISSING')
