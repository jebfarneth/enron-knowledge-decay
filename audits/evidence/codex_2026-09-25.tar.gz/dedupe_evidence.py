import json,tarfile,re
from pathlib import Path
import pyarrow.parquet as pq
O=Path('/tmp/enron-audit-20260925.Xj3qoO');R=Path('/Users/jebfarneth/projects/enron-knowledge-decay')
candidates=json.loads((O/'timezone_candidates.json').read_text())
selected=[candidates[i] for i in [0,3,4,7,10,15,23]]
wanted={x['path'] for p in selected for x in p['rows']}
found={}
with tarfile.open(R/'data/raw/enron_mail_20150507.tar.gz','r|gz') as t:
 for m in t:
  if m.name in wanted:
   b=t.extractfile(m).read().decode('utf-8','replace')
   h=re.split(r'\r?\n\r?\n',b,maxsplit=1)[0]
   found[m.name]={'headers':h,'body':b[len(h):]}
   if len(found)==len(wanted):break
for p in selected:
 a,b=(found[x['path']] for x in p['rows'])
 p['same_full_body_whitespace_normalized']=re.sub(r'\s+',' ',a['body']).strip().lower()==re.sub(r'\s+',' ',b['body']).strip().lower()
 for x in p['rows']: x['raw_headers']=found[x['path']]['headers'];x.pop('body',None)
(O/'timezone_header_evidence.json').write_text(json.dumps(selected,indent=2))
print(json.dumps(selected,indent=2))
