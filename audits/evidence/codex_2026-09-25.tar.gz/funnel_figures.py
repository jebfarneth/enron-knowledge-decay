import os,json,hashlib
from pathlib import Path
os.environ['MPLCONFIGDIR']='/tmp/enron-audit-20260925.Xj3qoO/mplconfig'
from enron_importance.figures.funnel import draw
from enron_importance.figures.style import save
R=Path('/Users/jebfarneth/projects/enron-knowledge-decay');O=Path('/tmp/enron-audit-20260925.Xj3qoO')
f=json.loads((R/'data/processed/funnel.json').read_text())['funnel']
out={}
for i in [1,2]:
 p=O/f'funnel_figures{i}';p.mkdir(exist_ok=True)
 save(draw(f),p,'fig01_data_funnel')
 out[f'run{i}']={q.name:hashlib.sha256(q.read_bytes()).hexdigest() for q in p.iterdir()}
out['existing']={q.name:hashlib.sha256(q.read_bytes()).hexdigest() for q in (R/'figures').glob('fig01*')}
(O/'funnel_figures.json').write_text(json.dumps(out,indent=2))
print(json.dumps(out,indent=2))
