import json,hashlib,subprocess
from pathlib import Path
R=Path('/Users/jebfarneth/projects/enron-knowledge-decay');O=Path('/tmp/enron-audit-20260925.Xj3qoO')
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
before=json.loads((O/'original_hashes.json').read_text())
changed=[p for p,h in before.items() if not (R/p).is_file() or sha(R/p)!=h]
status=subprocess.check_output(['git','status','--porcelain=v1','--untracked-files=all'],cwd=R).decode()
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R).decode().strip()
out={'compared_files':len(before),'changed_or_missing_existing_files':changed,'head':head,'git_status':status}
(O/'final_integrity.json').write_text(json.dumps(out,indent=2))
print(json.dumps(out,indent=2))
assert not changed
assert head=='8c595e7e6cc842260843d49547f20b796994db6a'
expected={'?? results/cleaning_crosscheck_disagreements.csv','?? audits/data_audit_codex_2026-09-25.md'}
assert set(status.splitlines())==expected,status
