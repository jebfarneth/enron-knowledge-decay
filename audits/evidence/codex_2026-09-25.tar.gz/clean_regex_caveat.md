**Line-limit precision:** the `{0,2}`/`{0,1}` wildcard-line limits in `clean.py:26,30,36` are not bounds on the total number of intervening physical lines: adjacent `\s*` can consume arbitrary blank lines. The wording “within two lines” in the source comment is therefore too strict. This was tested, not inferred only from the regex:

```sh
PYTHONDONTWRITEBYTECODE=1 .venv/bin/python - <<'PY'
from enron_importance.clean import _MARKERS, authored_text
x = 'Original text\nFrom: Alice\n' + '\n'*100 + 'Sent: Monday\nTo: Bob\nEarlier text'
y = 'Original text\nAlice\n05/14/2001 09:00 AM\n' + '\n'*100 + 'To: Bob\nEarlier text'
for text, pattern in [(x, 2), (y, 3)]:
    print(pattern, bool(_MARKERS[pattern].search(text)), repr(authored_text(text)))
PY
```

Both match and return only `'Original text'` despite100 blank lines. This is a documentation/Methods precision issue, not an estimated natural false-cut rate. The actual natural and adversarial boundary checks are reported in Section4.
