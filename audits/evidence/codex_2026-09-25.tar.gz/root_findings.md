### Major — Deduplication discards recipient evidence and misses timestamp-shifted copies

**Code:** `dedupe.py:33–50,68–79`; `ingest.py:54–63`. Exact timestamp is part of the content key, but recipients are not. Folder priority selects one entire row; it does not preserve discarded-copy provenance or reconcile recipients.

**Commands/evidence:** from the repository root:

```sh
PYTHONDONTWRITEBYTECODE=1 .venv/bin/python /tmp/enron-audit-20260925.Xj3qoO/data_attacks.py
PYTHONDONTWRITEBYTECODE=1 .venv/bin/python /tmp/enron-audit-20260925.Xj3qoO/dedupe_evidence.py
```

The first recomputes content keys for all 516,359 in-window raw rows, sorts by the production folder/path priority, and compares complete To/Cc sets within each key. `data_attack_summary.json` reports **131,371 groups containing multiple copies; 312 groups with conflicting recipient sets; 526 discarded group-recipient assignments, including 449 internal assignments across 236 groups; 194 groups with at least two nonempty, disjoint recipient sets**. Assignments are counted within groups, not distinct employees across the corpus, and some addresses are alternate renderings of one recipient. These are verified information losses, not 449 verified missing people or 194 adjudicated false merges.

Concrete example: `maildir/bass-e/sent/69.` and `/70.` have the same sender Eric Bass, UTC timestamp 2000-11-15 11:02, subject `Fuzzy Math!`, and normalized short URL body. The first is to Jim Schwieger only; the second has seven disjoint recipients, four internal. Both are in the highest-priority `sent` folder, with corroborating separate `_sent_mail` copies. Lexicographic path selection keeps `/69.` and loses the other distribution. This is consistent with separate repeated sends; whether to call it two sends or conflicting exports, the second distribution's per-message contribution is absent. The net effect on unique graph edges requires a recipient-reconciliation sensitivity run, because aliases and other messages can preserve the same contacts. Sally Beck's `sent/1066.` versus `all_documents/115.` instead contains alternate-looking Casandra/Cassandra routing addresses: blindly unioning strings is not a sufficient fix.

A fresh seed20260925 sample of **40 duplicate-key groups** inspected115 parsed rows out of118 in those groups, at most five copies per group (three groups actually contain six). All inspected parsed body strings are identical and combined To∪Cc sets agree; this does not prove raw MIME byte identity or identical assignment to To versus Cc. Paths typically show familiar sent/all_documents/discussion_threads or cross-mailbox copies. This supports the ordinary-copy interpretation for that sample, not perfect deduplication precision. No naturally occurring short `Thanks` false merge was established; the observed URL/disjoint-distribution case is the concrete counterexample. Seconds in that example are recorded as`:00`; different sends rounded to one minute remain possible.

Missed-copy search: after exact-key deduplication, **14,378 messages** share sender/normalized subject/body with another retained row at a different timestamp. Among adjacent dates within these groups, restricting bodies to more than100 normalized characters, **1,499 pairs / 2,992 participating messages** differ by exactly1–8hours: 1hour1pair; 2hours28; 3hours253; 4hours1,198; 5hours16; 8hours3. These are candidates, not all confirmed duplicates: legitimate retransmission remains possible. Group sizes above1,500 are explicitly skipped by this diagnostic, and only adjacent pairs are counted; this is not an exhaustive recall estimate. Selected raw-header corroboration is in `timezone_header_evidence.json`; the final reproduction section records its outcome.

The date parser correctly equates `14 May 2001 16:39 -0700` with `23:39 +0000` in a direct probe (`recipient_invariant_example=true`, awkwardly named in the scratch JSON). Seven targeted candidate pairs were re-extracted directly from the archive: all have identical whitespace-normalized full bodies and the same combined recipients, but differing source wall times with **the same numeric timezone offset**. For example, Bill Williams' `maildir/salisbury-h/inbox/1079.` versus `maildir/williams-w3/sent_items/512.` both say June11,2001 with`-0700`, but16:23:06 versus19:23:06; `maildir/dean-c/inbox/583.` versus`maildir/williams-w3/sent_items/146.` both say October29,2001 with`-0800`, but07:29:56 versus11:29:56. Different export-generated Message-IDs prevent ID recovery. These are strong probable-copy/source-export timestamp conflicts, not proven parser timezone errors; genuine delivery history is unavailable.

A relaxed NFKC/HTML-unescape/common MIME-soft-break body comparison finds **one additional same-sender/date/subject copy**; ordinary trailing whitespace is already normalized. There are **three null senders** and **zero bodies containing U+FFFD** in the in-window raw table. This does not prove all encoding was correct. Attachment equivalence cannot be validated from missing attachment payloads.

**Impact:** omitted recipient evidence can change edge weights and possibly unique contacts; residual copies can inflate repeated language and cross future train/test boundaries; timestamp shifts can reverse inferred reply order. **Fix:** preserve a copy-membership/provenance table and competing recipient evidence; validate a timestamp-tolerant, content-and-header linkage model on adjudicated examples; separate repeated sends from storage copies; reconcile recipient identities before unioning address variants. Split future train/test data by reviewed near-duplicate/thread groups. Do not simply merge all same-text messages within eight hours.

### Major — Cached parsing bypasses verification and provenance; the provided default runner is incomplete

**Code:** `prepare.py:29–32,73–79`; `download.py:26–56`; `Makefile:6–16`. The manifest writes the *configured* archive SHA, even when the archive was not checked on that execution. A preexisting raw parquet is accepted without a hash binding to archive, parser code, or config. The default Makefile target does not run identity/rank/network/evaluation/cross-check/figures.

**Reproduced failure:**

```sh
PYTHONDONTWRITEBYTECODE=1 .venv/bin/python /tmp/enron-audit-20260925.Xj3qoO/cache_probe.py
```

This uses the project's tiny test-corpus constructor strictly in scratch, runs preparation, then replaces the scratch archive's424bytes with22bytes. Direct `ensure_corpus` correctly exits on the size mismatch. `prepare` nonetheless reuses the cache, succeeds and returns the same manifest (`cache_probe.json`: `prepare_reused_cache_and_succeeded: true`). No real archive was changed. This proves a stale/unverified-cache path; it does **not** establish that the supplied real parquet is stale. The fresh real-corpus rebuild separately checks that.

**Impact/fix:** changes in parser, archive or extraction policy can silently leave old rows under a misleading source hash. Add input/output/code/config provenance and dependency-aware invalidation; verify the archive/cache binding on cached runs; make the documented end-to-end command actually include every reported artifact.

### Minor — Passing tests are not corpus validity, and two weak assertions survive deliberately wrong implementations

**Command:** `PYTHONDONTWRITEBYTECODE=1 .venv/bin/python /tmp/enron-audit-20260925.Xj3qoO/test_mutations.py`; code inspected in `tests/test_evaluate.py` and `tests/test_identity.py`. The scratch script changes only imported test namespaces in memory, not any repository file. The existing bootstrap test still passes a stub that always returns `(0,1)`. The identity-builder fixture still passes when the implementation takes the first message per address, ignoring the required normalized-name modal rule. Results are in `test_mutations.json` (both mutations pass).

These do not show that the actual bootstrap or modal rule is wrong: independent oracle checks support the implemented bootstrap arithmetic. They show that these tests cannot detect important wrong alternatives. Likewise, the real Pete Davis human-message exclusion passes a synthetic test that uses his address as a wholly templated sender. Tests of the intended regex outputs are not empirical validation of message authorship, identity, title correctness, thread precision or population representativeness.

**Fix:** assert independently calculated expected intervals/weighted resample results and fixtures with disagreeing first/modal names; add adjudicated real-corpus regression cases for each failure above; maintain a frozen, separately sampled evaluation set rather than repeatedly converting discovered failures into development-only fixtures.
