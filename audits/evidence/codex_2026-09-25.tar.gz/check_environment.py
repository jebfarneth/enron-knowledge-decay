import sys, subprocess, shutil, json, os
from pathlib import Path
REPO=Path('/Users/jebfarneth/projects/enron-knowledge-decay')
ROOT=Path('/tmp/enron-audit-20260925.Xj3qoO')
dest=ROOT/'environment'
dest.mkdir(exist_ok=True)
for f in ['pyproject.toml','uv.lock','.python-version','README.md','config.yaml']:
    shutil.copy2(REPO/f,dest/f)
shutil.copytree(REPO/'src',dest/'src',dirs_exist_ok=True,ignore=shutil.ignore_patterns('__pycache__'))
shutil.copytree(REPO/'tests',dest/'tests',dirs_exist_ok=True,ignore=shutil.ignore_patterns('__pycache__'))
env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1','MPLCONFIGDIR':str(ROOT/'mplconfig')}
for name,cmd in [('uv_sync',['/Users/jebfarneth/.local/bin/uv','sync','--locked','--group','dev']),('pytest',['.venv/bin/python','-m','pytest','-q','-p','no:cacheprovider','--basetemp',str(ROOT/'pytest_tmp')])]:
    result=subprocess.run(cmd,cwd=dest,env=env,capture_output=True,text=True)
    (ROOT/f'{name}.log').write_text(result.stdout+result.stderr)
    print(name, result.returncode, result.stdout, result.stderr,flush=True)
cmd="import importlib.metadata as m,json,sys; print(json.dumps({'python':sys.version,'packages':dict(sorted((p.metadata['Name'],p.version) for p in m.distributions()))},indent=2))"
for label,exe in [('original',REPO/'.venv/bin/python'),('synced',dest/'.venv/bin/python')]:
    result=subprocess.check_output([str(exe),'-c',cmd],env=env,text=True)
    (ROOT/f'packages_{label}.json').write_text(result)
    print(label,result,flush=True)
