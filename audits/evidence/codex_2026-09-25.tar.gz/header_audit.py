import tarfile,re,json,collections,time
from pathlib import Path
p=Path('/Users/jebfarneth/projects/enron-knowledge-decay/data/raw/enron_mail_20150507.tar.gz')
c=collections.Counter(); ex=collections.defaultdict(list)
t=tarfile.open(p,'r|gz')
for m in t:
    if not m.isfile() or not m.name.startswith('maildir/'): continue
    c['files']+=1
    b=t.extractfile(m).read()
    h=re.split(br'\r?\n\r?\n',b,maxsplit=1)[0]
    for name,pat in [('in_reply_to',br'^In-Reply-To:'),('references',br'^References:'),('mime_multipart',br'^Content-Type:\s*multipart/'),('attachment_disposition',br'^Content-Disposition:\s*attachment'),('message_id',br'^Message-ID:')]:
        if re.search(pat,h,re.M|re.I):
            c[name]+=1
            if len(ex[name])<3: ex[name].append(m.name)
    if c['files']%100000==0: print(c['files'],flush=True)
t.close()
out={'counts':dict(c),'example_paths':dict(ex)}
Path('/tmp/enron-audit-20260925.Xj3qoO/header_audit.json').write_text(json.dumps(out,indent=2))
print(json.dumps(out,indent=2))
