import os, sys, json, hashlib, time, subprocess, shutil
from pathlib import Path

REPO = Path('/Users/jebfarneth/projects/enron-knowledge-decay')
ROOT = Path('/tmp/enron-audit-20260925.Xj3qoO')
sys.path.insert(0, str(REPO/'src'))
from enron_importance.config import load_config
from enron_importance.prepare import prepare
from enron_importance.download import sha256_of, ensure_corpus

def snapshot():
    paths = list(subprocess.check_output(['git','ls-files','-z'],cwd=REPO).decode().strip('\0').split('\0'))
    paths += [str(p.relative_to(REPO)) for d in ['data','results'] for p in (REPO/d).rglob('*') if p.is_file()]
    return {p: sha256_of(REPO/p) for p in sorted(set(paths)) if (REPO/p).is_file()}

if __name__=='__main__':
    (ROOT/'original_hashes.json').write_text(json.dumps(snapshot(),indent=2))
    (ROOT/'original_git_status.txt').write_text(subprocess.check_output(['git','status','--porcelain=v1','--untracked-files=all'],cwd=REPO).decode())
    original = load_config()
    print('Verified archive:', ensure_corpus(original), flush=True)
    manifest={}
    for i in [1,2]:
        start=time.monotonic()
        cfg=load_config()
        for key in cfg['paths']:
            if key!='raw': cfg['paths'][key]=ROOT/f'run{i}'/key
        result=prepare(cfg)
        hashes={str(p.relative_to(ROOT/f'run{i}')):sha256_of(p) for p in (ROOT/f'run{i}').rglob('*') if p.is_file()}
        manifest[f'run{i}']={'seconds':time.monotonic()-start,'result':result,'hashes':hashes}
        (ROOT/'reproduction.json').write_text(json.dumps(manifest,indent=2))
        print(json.dumps(manifest[f'run{i}'],indent=2),flush=True)
    print('Run hashes match', manifest['run1']['hashes']==manifest['run2']['hashes'],flush=True)
