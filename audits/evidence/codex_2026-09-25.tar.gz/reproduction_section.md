## 3. Reproduction table and repeatability

### Executed scope and environment

One **fresh archive parse and complete, unmodified `prepare(config)` execution** finished successfully with output paths redirected to scratch. Its raw parquet, processed message parquet, sender parquet and funnel manifest are all **byte-identical to the existing repository artifacts**. This verifies the actual current data against source execution; the cache-bypass finding below is not evidence that these particular files are stale.

Identity resolution, title mapping, edge construction, **full exact betweenness and every other centrality**, evaluation and figure6 were then independently rebuilt in two processes with `PYTHONHASHSEED=101` and`202`. The cleaning cross-check and figure1 render were also repeated twice. A redundant second full Phase1 pass was started with a hardlink to the fresh raw parse, then deliberately terminated after the first pass completed; **that incomplete pass and its hardlinked raw file are not counted as independent verification**. This audit uses the user's allowance to repeat the relevant stages, not a claim of two complete fresh end-to-end builds. Timing of the first pass includes a deliberate resource-management pause and concurrent jobs; it is not a clean performance benchmark.

Environment reproduction used a source/config/test/lockfile copy outside the repository. `uv sync --locked --group dev` succeeded; original and freshly synced installed-version inventories are identical. Both use Python3.12.13. **All65 tests passed** in the freshly synced environment. Logs and inventories: `uv_sync.log`, `pytest.log`, `environment.log`, `packages_original.json`, `packages_synced.json`. The command was stricter than plain `uv sync`: it refused lockfile updates. Cross-platform reproducibility was not tested.

Core commands, run from the repository:

```sh
PYTHONDONTWRITEBYTECODE=1 .venv/bin/python /tmp/enron-audit-20260925.Xj3qoO/check_environment.py
PYTHONDONTWRITEBYTECODE=1 .venv/bin/python /tmp/enron-audit-20260925.Xj3qoO/reproduce.py
PYTHONDONTWRITEBYTECODE=1 PYTHONHASHSEED=101 .venv/bin/python -u /tmp/enron-audit-20260925.Xj3qoO/network_eval/reproduce.py run1
PYTHONDONTWRITEBYTECODE=1 PYTHONHASHSEED=202 .venv/bin/python -u /tmp/enron-audit-20260925.Xj3qoO/network_eval/reproduce.py run2
PYTHONDONTWRITEBYTECODE=1 .venv/bin/python /tmp/enron-audit-20260925.Xj3qoO/funnel_figures.py
PYTHONDONTWRITEBYTECODE=1 .venv/bin/python /tmp/enron-audit-20260925.Xj3qoO/header_audit.py
```

`reproduce.py` still contains the originally planned two-pass loop; on this audit execution PID3037 was stopped with`kill -TERM 3037` only after `reproduction.json` contained the successfully completed first pass. Its completed result is preserved as`run1`; the scope is also recorded in`reproduction_scope.txt`. The pipeline source was not changed.

### Data funnel

Every value in the obtained column below comes from the completed fresh run, not a reading of the existing funnel alone.

| Claim | Obtained | Status |
|---|---:|---|
|Files parsed:517,401|517,401|Match|
|In1998–2002 window:516,359|516,359|Match|
|Outside window:1,042|1,042|Match|
|Undated:0|0|Match|
|Content-duplicate copies removed:262,482|262,482|Match to rule; removal validity audited separately|
|Unique messages:253,877|253,877|Match to rule; residual probable copies remain|
|Additional Message-ID duplicates:0|0|Match|
|Nonempty authored estimates:234,078|234,078|Match; not verified authorship|
|Automated sender flags:312|312|Match; all domains, only21 internal|
|Routine messages from unflagged senders:11,799|11,799|Match;6,269 internal, not all reports|
|Messages linked as replies:47,130|47,130|Match; not47,130 validated replies|
|Threads:206,747|206,747|Match to inferred-link components|
|Analysis messages:167,905|167,905|Match|
|Analysis senders:6,348|6,348|Match as addresses;5,766 inferred keys under current map|

Additional reproduced funnel fields:112,277 quotation-flagged messages;20,293 sender profiles;9,505 messages from flagged automated addresses. Exact hashes:

```text
messages_raw.parquet  2460bc2b9a5be00d36a1d8769b1b1d072fe7779071eef27d40eba0676f7bd607
messages.parquet      36ab7b73beb8ff61893f4446bfd1bcd5aaf9f7c162e4988b8d19c3100567baa1
senders.parquet       363fdd3a733034f73809fcd16fefa1f1c0157156368edd970f8e193a7790ca85
funnel.json           76e47cd516c7a00f7fb269d33d96ceafbf3410e6112e63653147892490a23519
```

An independent streaming scan of **all517,401 archive files' top-level headers** found517,401 Message-ID headers and **zero In-Reply-To, References, multipart Content-Type, or attachment-disposition headers** (`header_audit.py`, `header_audit.json`). Thus standard reply headers really are unavailable in this release; proposing their simple reuse would not repair threading. This scan is not a reconstruction of attachment payloads or pre-release original mail.

### Identity and title labels

| Claim | Obtained independently | Status |
|---|---:|---|
|Internal sender addresses:6,455|6,455|Match|
|Resolved people:5,866|5,866 keys|Numeric match; person interpretation fails in verified cases|
|People with multiple addresses:525|525 keys|Match to identity rule|
|Names in title list:161|161 rows|Match|
|Matched title-list names:160|160 rows:149 normalization +11 corrections|Match; not160 distinct verified people|
|Distinct titled people:129|129 inferred keys from131 matched titled rows|Match under current label policy|

Identity and rank parquet files are byte-identical across both independent reruns and existing files. Independent identity diagnostics and the eleven correction checks were run with:

```sh
PYTHONDONTWRITEBYTECODE=1 .venv/bin/python /tmp/enron-audit-20260925.Xj3qoO/identity_rank/audit_identity.py
PYTHONDONTWRITEBYTECODE=1 .venv/bin/python /tmp/enron-audit-20260925.Xj3qoO/identity_rank/deep_identity.py
PYTHONDONTWRITEBYTECODE=1 .venv/bin/python /tmp/enron-audit-20260925.Xj3qoO/identity_rank/splits.py
PYTHONDONTWRITEBYTECODE=1 .venv/bin/python /tmp/enron-audit-20260925.Xj3qoO/identity_rank/mark_taylor_evidence.py
```

### Network and evaluation

| Claim | First full rerun | Second full rerun | Status |
|---|---:|---:|---|
|21,047 people|21,047 nodes|21,047 nodes|Numeric match; not all people|
|220,807 directed edges|220,807|220,807|Match|
|6,285 different-level pairs|6,285|6,285|Match|
|Degree0.647, CI0.568–0.719|0.6474940334;[0.5679609760,0.7193037872]|Same|Match|
|PageRank0.614|0.6140015911;[0.5332828772,0.6845796014]|Same|Match|
|Weighted in-strength0.604|0.6035003978;[0.5250726997,0.6743004272]|Same|Match at quoted precision|
|Betweenness0.567|0.5673826571;[0.4831074615,0.6384996627]|Same|Match|
|Weighted out-strength0.517|0.5170246619;[0.4388527642,0.5947447841]|0.5172633254;[0.4388654782,0.5947707149]|Three-decimal match, **but committed CSV0.5172 becomes0.5170/0.5173**|

The last discrepancy is genuine: floating summation breaks mathematically equal outgoing-message totals. An independent exact integer count gives accuracy**0.5175815434**, CI**[0.4397790954,0.5953736687]**. This does not rescue the near-chance baseline, but it refutes exact repeatability and the implemented interpretation of some ties. See the numerical finding below.

### Cleaning cross-check

Both5000-message runs reproduce the committed summary exactly: whitespace-normalized agreement**76.4%**, median token-set Jaccard**1.0**, and Jaccard≥0.9 for**79.66%**.

| Residue marker prevalence | Project cleaner | email_reply_parser | Status |
|---|---:|---:|---|
|Original Message|0.02%|2.12%|Match|
|Forwarded by|0.02%|6.36%|Match|
|Quoted-header regex|1.08%|7.90%|Match|
|Angle-quoted line|0.00%|0.10%|Match|

Both summary files have SHA-256`dee6b18ded54f9f0af6ec6af2e2f7bf11ba5ec93641a601ecade743cb1a04c9c`. These are marker/agreement measurements, not an authored-span accuracy estimate. The fresh200-message review and detector-negative stratum are reported separately below.

### Is every output deterministic? **No.**

- The fresh Phase1 artifacts match existing data byte-for-byte. Two identity/rank rebuilds and two cleaning summaries are also byte-identical to each other and existing outputs.
- `edges.parquet` differs across the existing artifact and both reruns because unsorted recipient sets change row insertion order. Sorting by`(source,target)` yields exactly equal endpoints, weights and counts. This is ordering nondeterminism, not a different edge set.
- After sorting centrality by person, degree, in-strength and betweenness are exactly equal. Between reruns, maximum out-strength difference is5.68434e−13 across890 nodes; PageRank difference is3.91354e−15 across21,042 nodes. Those tiny differences change some out-strength tie credits, but do not change PageRank accuracy here.
- Consequently centrality parquet, baseline CSV and figure6 are not byte-stable. Figure6 PDFs differ; run1 PNG matches the existing PNG, but run2 differs. The actual figure entrypoint was rerun against each regenerated CSV and confirmed the same renderings: changed plotted inputs explain this, not an invented plotting-randomness diagnosis.
- Figure1 PDF and PNG are each identical across two renders and the existing files (`funnel_figures.json`). Their input counts were subsequently verified by the fresh rebuild.
- Config seed42 is actually passed to the5000-message sampling and1000 bootstrap resamples. Those repeat correctly on fixed inputs. It does not control Python hash/set iteration order or eliminate floating-point summation effects. There is no sampled betweenness random seed: all nodes are evaluated exactly.

Complete hash/numerical comparison: `network_eval/comparison.json`; numerical outputs: `network_eval/run1/summary.json`, `run2/summary.json`; actual figure entrypoint checks: `figure_main_output.txt`. Do not interpret exact data-file reproduction as proof of construct validity.
