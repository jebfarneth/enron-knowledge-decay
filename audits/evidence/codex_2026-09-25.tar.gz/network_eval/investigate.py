import os
os.environ['MPLCONFIGDIR']='/tmp/enron-audit-20260925.Xj3qoO/network_eval/mpl'
from pathlib import Path
from collections import Counter,defaultdict
import json,itertools,hashlib
import numpy as np
import pandas as pd
from enron_importance import network,evaluate
from enron_importance.config import load_config

root=Path('/Users/jebfarneth/projects/enron-knowledge-decay')
out=Path('/tmp/enron-audit-20260925.Xj3qoO/network_eval')
ids=pd.read_parquet(root/'data/processed/identities.parquet')
mapping=dict(zip(ids.address,ids.person_key))
measures=pd.read_parquet(root/'data/processed/centrality.parquet')
edges=pd.read_parquet(root/'data/processed/edges.parquet')
msg=pd.read_parquet(root/'data/processed/messages.parquet',columns=['sender','to','cc','sender_internal','sender_automated','routine','custodian'])
netmsg=msg[msg.sender_internal & ~msg.sender_automated]
unknown=set(measures.person_key)-set(ids.person_key)
print('network address unresolved',len(unknown),'named_or_sender',len(measures)-len(unknown),flush=True)
print(measures[measures.person_key.isin(unknown)].sort_values('degree',ascending=False).head(30).to_string(index=False),flush=True)
print('self_loops',int((edges.source==edges.target).sum()),'unresolved_non_enron',[x for x in unknown if not x.endswith('@enron.com')],flush=True)
print('node_zero_indegree',int((measures.in_strength==0).sum()),'node_zero_outdegree',int((measures.out_strength==0).sum()),flush=True)
print('no_addr',ids[ids.address.str.contains('no.address|no_address',regex=True)].to_dict('records'),flush=True)

# Independent edge construction with sorted recipient aliases and integer multiplicities.
auditweights=defaultdict(float); auditcounts=Counter(); usable=0
for sender,to,cc in netmsg[['sender','to','cc']].itertuples(index=False,name=None):
    src=mapping.get(sender,sender)
    target=set()
    for addr in itertools.chain(to,cc):
        if isinstance(addr,str) and addr.endswith('@enron.com'):
            key=mapping.get(addr,addr)
            if key != src: target.add(key)
    if target:
        usable+=1
        for dst in sorted(target):
            auditweights[(src,dst)]+=1/len(target)
            auditcounts[(src,dst)]+=1
original={(s,t):(w,n) for s,t,w,n in edges.itertuples(index=False,name=None)}
print('edge_independent',{'usable_messages':usable,'weight_sum':float(edges.weight.sum()),'keys_match':set(original)==set(auditweights),'max_weight_diff':max(abs(w-original[k][0]) for k,w in auditweights.items() if k in original),'message_count_mismatch':sum(n!=original[k][1] for k,n in auditcounts.items() if k in original)},flush=True)

# Pairwise exhaustive independent scalar oracle, ties included, all small states.
def oracle(levels,scores):
    v=[]
    for i in range(len(levels)):
        for j in range(i+1,len(levels)):
            if levels[i]==levels[j]: continue
            if scores[i]==scores[j]: v.append(.5)
            else:v.append(float((levels[i]>levels[j])==(scores[i]>scores[j])))
    return np.mean(v) if v else float('nan')
nchecks=0
for lev in itertools.product([0,1,2],repeat=3):
    for scr in itertools.product([0,1,2],repeat=3):
        got=evaluate.pairwise_accuracy(np.array(lev),np.array(scr)); want=oracle(lev,scr)
        assert (np.isnan(got) and np.isnan(want)) or got==want,(lev,scr,got,want)
        nchecks+=1
print('pairwise_exhaustive_pass',nchecks,flush=True)
# Duplicated-person bootstrap comparison to original unique-person pair multiplicity weights.
rng=np.random.default_rng(83217); lev=np.array([0,1,1,3]); scr=np.array([4.,1.,2.,3.])
maxdiff=0
for _ in range(1000):
    idx=rng.integers(0,4,4); c=Counter(idx); num=den=0
    for i,j in itertools.combinations(range(4),2):
        if lev[i]==lev[j]:continue
        mult=c[i]*c[j]; den+=mult
        num+=mult*(.5 if scr[i]==scr[j] else float((lev[i]>lev[j])==(scr[i]>scr[j])))
    v=evaluate.pairwise_accuracy(lev[idx],scr[idx]); exp=num/den if den else np.nan
    assert (np.isnan(v) and np.isnan(exp)) or v==exp
print('bootstrap_multiset_oracle_pass',1000,flush=True)

# Test direction collapse and inverse weight length independently on hand-calculated graph.
toy=pd.DataFrame([('a','b',2.,1),('b','a',8.,1),('b','c',10.,1),('a','c',1.,1)],columns=['source','target','weight','messages'])
print('hand_graph',network.centrality(toy).to_dict('records'),flush=True)

# Weight normalized by target PEOPLE not target addresses, and self excluded before normalization.
aliasmsg=pd.DataFrame([{'sender':'a@enron.com','to':['a@enron.com','b@enron.com','b2@enron.com','c@enron.com'],'cc':[]}])
print('alias_normalization',network.build_edges(aliasmsg,{'a@enron.com':'a','b@enron.com':'b','b2@enron.com':'b','c@enron.com':'c'},'enron.com').to_dict('records'),flush=True)

npairs = lambda x:int(np.triu(x[:,None]!=x[None,:],k=1).sum())
ranked=evaluate.ranked_people(load_config())
print('ranked_counts',len(ranked),npairs(ranked.level.to_numpy()),ranked.level.value_counts().sort_index().to_dict(),flush=True)
print('ranked_zerodegree',ranked[ranked.degree==0].to_dict('records'),flush=True)
print('ranked_degree',ranked.sort_values('degree',ascending=False).head(15).to_string(index=False),flush=True)

# Custodian sensitivity baseline. Authoritative mailbox-name corrections inspected separately.
owners=pd.read_csv(out/'custodian_owners.csv')
overrides={'lay-k':'kenneth lay','skilling-j':'jeffrey skilling','whalley-l':'lawrence whalley'}
for cust,key in overrides.items(): owners.loc[owners.custodian==cust,'person_key']=key
raw_counts=pd.read_parquet(root/'data/interim/messages_raw.parquet',columns=['custodian']).custodian.value_counts()
owners=pd.concat([owners,pd.DataFrame([{'custodian':'harris-s','person_key':'steven harris','mailbox_files':raw_counts['harris-s']},{'custodian':'stokley-c','person_key':'christopher stokley','mailbox_files':raw_counts['stokley-c']}])],ignore_index=True)
owners.to_csv(out/'custodian_corrected.csv',index=False)
custset=set(owners.person_key)
mailcounts=owners.groupby('person_key').mailbox_files.sum()
ranked['is_custodian']=ranked.person_key.isin(custset).astype(int)
ranked['mailbox_file_count']=ranked.person_key.map(mailcounts).fillna(0)
ranked['total_sent_messages']=ranked.person_key.map(netmsg.sender.map(mapping).value_counts()).fillna(0)
ranked['surviving_custodian_files']=ranked.person_key.map(owners.assign(count=owners.custodian.map(msg.custodian.value_counts()).fillna(0)).groupby('person_key')['count'].sum()).fillna(0)
baseline=evaluate.evaluation_table(ranked,['degree','is_custodian','mailbox_file_count','surviving_custodian_files','total_sent_messages'],1000,42)
baseline.to_csv(out/'custodian_baselines.csv',index=False)
print('custodian_eval',int(ranked.is_custodian.sum()),'of',len(ranked),baseline.to_dict('records'),flush=True)
print('ranked_not_custodian',ranked.loc[ranked.is_custodian==0,['person_key','level','degree']].to_dict('records'),flush=True)
measures['is_custodian']=measures.person_key.isin(custset)
print('custodian_degree_summary',measures.groupby('is_custodian').degree.agg(['count','mean','median','min','max']).to_dict(),flush=True)
print('degree_mailcount_spearman',ranked[['degree','mailbox_file_count','level']].corr(method='spearman').to_dict(),flush=True)
print('custodian_only_accuracy',len(ranked[ranked.is_custodian==1]),evaluate.evaluation_table(ranked[ranked.is_custodian==1],['degree','mailbox_file_count','total_sent_messages'],1000,42).to_dict('records'),flush=True)
ranked.to_csv(out/'ranked_with_controls.csv',index=False)

# Avoid asserting best baseline superiority solely from ranked point estimates.
levels=ranked.level.to_numpy(); degree=ranked.degree.to_numpy(); pr=ranked.pagerank.to_numpy()
rng=np.random.default_rng(42); diffs=[]
for _ in range(1000):
    ix=rng.integers(0,len(levels),len(levels))
    diffs.append(evaluate.pairwise_accuracy(levels[ix],degree[ix])-evaluate.pairwise_accuracy(levels[ix],pr[ix]))
print('degree_minus_pagerank_bootstrap',{'difference':evaluate.pairwise_accuracy(levels,degree)-evaluate.pairwise_accuracy(levels,pr),'ci':np.percentile(diffs,[2.5,97.5]).tolist()},flush=True)

# Rank duplicate decisions sensitivity and very broad level pooling.
rawranks=pd.read_parquet(root/'data/processed/formal_rank.parquet').dropna(subset=['person_key','level'])
for kind in ['min','drop_conflicts']:
    if kind=='min': rr=rawranks.groupby('person_key',as_index=False)['level'].min()
    else:
        conflicting=rawranks.groupby('person_key')['level'].nunique(); bad=set(conflicting[conflicting>1].index)
        rr=rawranks[~rawranks.person_key.isin(bad)].groupby('person_key',as_index=False)['level'].max()
    rr=rr.merge(measures,on='person_key',how='left').fillna({m:0 for m in evaluate.BASELINES})
    print('rank_policy',kind,len(rr),npairs(rr.level.to_numpy()),{m:evaluate.pairwise_accuracy(rr.level.to_numpy(),rr[m].to_numpy()) for m in evaluate.BASELINES},flush=True)
