import os
os.environ['MPLCONFIGDIR']='/tmp/enron-audit-20260925.Xj3qoO/network_eval/mpl'
from pathlib import Path
from collections import defaultdict
import itertools
import numpy as np,pandas as pd
from enron_importance.network import centrality

root=Path('/Users/jebfarneth/projects/enron-knowledge-decay')
edges=pd.read_parquet(root/'data/processed/edges.parquet')
old=pd.read_parquet(root/'data/processed/centrality.parquet').set_index('person_key')
names=sorted(set(edges.source)|set(edges.target));index={v:i for i,v in enumerate(names)};n=len(names)
src=edges.source.map(index).to_numpy();dst=edges.target.map(index).to_numpy();wt=edges.weight.to_numpy()
outs=np.bincount(src,weights=wt,minlength=n)
transition=wt/outs[src]
v=np.full(n,1/n);damping=.85
for it in range(10000):
    w=(1-damping)/n+damping*(np.bincount(dst,weights=transition*v[src],minlength=n)+v[outs==0].sum()/n)
    error=np.abs(w-v).sum();v=w
    if error<1e-13:break
expected=old.loc[names,'pagerank'].to_numpy()
print('independent_full_graph_pagerank',{'iterations':it+1,'l1_step':float(error),'max_abs_difference':float(np.max(np.abs(v-expected))),'sum':float(v.sum())},flush=True)

# Enumerate every simple path for each source/target pair in 30 five-node graphs.
# Positive dyadic lengths avoid tolerance ambiguity while preserving tied shortest paths.
rng=np.random.default_rng(712611)
worst=0
for case in range(30):
    rows=[]
    for a,b in itertools.combinations('abcde',2):
        if rng.random()<.6:rows.append((a,b,float(rng.choice([1,2,4,8])),1))
    if not rows:rows=[('a','b',1.,1)]
    df=pd.DataFrame(rows,columns=['source','target','weight','messages'])
    got=centrality(df).set_index('person_key').betweenness.to_dict()
    adj=defaultdict(dict)
    for a,b,w,_ in rows:adj[a][b]=1/w;adj[b][a]=1/w
    answer={a:0. for a in adj}
    for source,target in itertools.combinations(adj,2):
        allpaths=[]
        def walk(node,path,length):
            if node==target:allpaths.append((path,length));return
            for nxt,d in adj[node].items():
                if nxt not in path:walk(nxt,path+[nxt],length+d)
        walk(source,[source],0.)
        if not allpaths:continue
        best=min(d for _,d in allpaths);short=[p for p,d in allpaths if d==best]
        for path in short:
            for node in path[1:-1]:answer[node]+=1/len(short)
    error=max(abs(answer[a]-got[a]) for a in answer);worst=max(worst,error)
    assert error<1e-12,(case,rows,answer,got)
print('independent_exhaustive_shortest_path_betweenness',{'random_graphs':30,'nodes_per_graph':5,'worst_abs_error':worst},flush=True)
