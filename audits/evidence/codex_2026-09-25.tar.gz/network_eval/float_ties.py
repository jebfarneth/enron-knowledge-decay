from pathlib import Path
import json,itertools
from collections import Counter
import numpy as np,pandas as pd
from enron_importance.evaluate import evaluation_table,pairwise_accuracy
root=Path('/Users/jebfarneth/projects/enron-knowledge-decay')
out=Path('/tmp/enron-audit-20260925.Xj3qoO/network_eval')
old=pd.read_parquet(root/'data/processed/centrality.parquet').set_index('person_key').sort_index()
new=pd.read_parquet(out/'run1/centrality.parquet').set_index('person_key').sort_index()
ranks=pd.read_parquet(root/'data/processed/formal_rank.parquet').dropna(subset=['person_key','level']).groupby('person_key')['level'].max()
names=ranks.index.tolist();lev=ranks.to_numpy();a=old.loc[names,'out_strength'].to_numpy();b=new.loc[names,'out_strength'].to_numpy()
changes=[]
def contrib(li,lj,si,sj):return .5 if si==sj else float((li>lj)==(si>sj))
for i,j in itertools.combinations(range(len(names)),2):
    if lev[i]==lev[j]:continue
    ca=contrib(lev[i],lev[j],a[i],a[j]);cb=contrib(lev[i],lev[j],b[i],b[j])
    if ca!=cb:
        changes.append({'person1':names[i],'level1':lev[i],'person2':names[j],'level2':lev[j],'committed_scores':[a[i],a[j]],'run1_scores':[b[i],b[j]],'committed_credit':ca,'run1_credit':cb})
print('different_pair_credits',json.dumps(changes,indent=2),flush=True)
print('max_outstrength_distance_from_integer',float(np.max(np.abs(new.out_strength-np.rint(new.out_strength)))),flush=True)
ranked=pd.DataFrame({'level':lev,'out_strength_committed':a,'out_strength_run1':b,'out_strength_integer':np.rint(b)})
print('evaluation_with_exact_message_count_ties',evaluation_table(ranked,['out_strength_committed','out_strength_run1','out_strength_integer'],1000,42).to_dict('records'),flush=True)
different_from_exact=0;math_ties=0;false_orders=0
for i,j in itertools.combinations(range(len(names)),2):
    if lev[i]==lev[j]:continue
    if round(b[i])==round(b[j]):
        math_ties+=1
        false_orders+=int(b[i]!=b[j])
print('labeled_outstrength_ties',{'integer_count_ties':math_ties,'run1_false_non_ties':false_orders},flush=True)
pd.DataFrame(changes).to_json(out/'float_pair_changes.json',orient='records',indent=2)

# Exact integer oracle: one unit per eligible message with any nonself internal target.
# No graph weights and no rounding are used to construct this score.
ids=pd.read_parquet(root/'data/processed/identities.parquet'); mapping=dict(zip(ids.address,ids.person_key))
messages=pd.read_parquet(root/'data/processed/messages.parquet',columns=['sender','to','cc','sender_internal','sender_automated'])
messages=messages[messages.sender_internal & ~messages.sender_automated]
counts=Counter()
for sender,to,cc in messages[['sender','to','cc']].itertuples(index=False,name=None):
    source=mapping.get(sender,sender)
    for recipient in itertools.chain(to,cc):
        if isinstance(recipient,str) and recipient.endswith('@enron.com') and mapping.get(recipient,recipient)!=source:
            counts[source]+=1
            break
all_exact=np.array([counts[name] for name in new.index],dtype=np.int64)
print('exact_contributing_message_counts',{'total':sum(counts.values()),'max_float_difference':float(np.max(np.abs(new.out_strength.to_numpy()-all_exact))),'integer_rounding_mismatches':int(np.sum(np.rint(new.out_strength.to_numpy())!=all_exact))},flush=True)
ranked['exact_message_count']=[counts[name] for name in names]
print('exact_count_evaluation',evaluation_table(ranked,['exact_message_count'],1000,42).to_dict('records'),flush=True)
pd.DataFrame({'person_key':new.index,'exact_outgoing_count':all_exact,'float_out_strength':new.out_strength.to_numpy()}).to_csv(out/'exact_outgoing_counts.csv',index=False)
