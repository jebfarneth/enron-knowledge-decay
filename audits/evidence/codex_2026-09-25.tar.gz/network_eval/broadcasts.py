from pathlib import Path
from collections import defaultdict,Counter
import pandas as pd,numpy as np
from enron_importance.evaluate import ranked_people,pairwise_accuracy
from enron_importance.config import load_config
root=Path('/Users/jebfarneth/projects/enron-knowledge-decay')
out=Path('/tmp/enron-audit-20260925.Xj3qoO/network_eval')
ids=pd.read_parquet(root/'data/processed/identities.parquet');mp=dict(zip(ids.address,ids.person_key))
msg=pd.read_parquet(root/'data/processed/messages.parquet',columns=['sender','to','cc','sender_internal','sender_automated','path'])
msg=msg[msg.sender_internal & ~msg.sender_automated]
thresholds=[1,5,10,50,100,10000]
contacts={t:defaultdict(set) for t in thresholds};counts=Counter(); biggest=[]
for sender,to,cc,path in msg[['sender','to','cc','path']].itertuples(index=False,name=None):
    src=mp.get(sender,sender)
    targets={mp.get(r,r) for r in list(to)+list(cc) if isinstance(r,str) and r.endswith('@enron.com')}-{src}
    n=len(targets);counts[n]+=1
    if n>=100:biggest.append({'sender':sender,'person_key':src,'n_targets':n,'path':path})
    for t in thresholds:
        if n<=t:
            contacts[t][src].update(targets)
            for dst in targets:contacts[t][dst].add(src)
r=ranked_people(load_config());r.to_csv(out/'broadcast_ranked_original.csv',index=False)
print('recipient_counts',{'messages':len(msg),'max':max(counts),'over10':sum(v for n,v in counts.items() if n>10),'over50':sum(v for n,v in counts.items() if n>50),'over100':sum(v for n,v in counts.items() if n>100)},flush=True)
for t in thresholds:
    r[f'degree_maxrecips_{t}']=r.person_key.map({k:len(v) for k,v in contacts[t].items()}).fillna(0)
    print('maxrecipients',t,'messages',sum(v for n,v in counts.items() if n<=t),'accuracy',pairwise_accuracy(r.level.to_numpy(),r[f'degree_maxrecips_{t}'].to_numpy()),flush=True)
r['lost_above50']=r.degree-r.degree_maxrecips_50
print('largest_degree_changes',r.sort_values('lost_above50',ascending=False)[['person_key','level','degree','degree_maxrecips_1','degree_maxrecips_10','degree_maxrecips_50','lost_above50']].head(15).to_dict('records'),flush=True)
big=pd.DataFrame(biggest).sort_values('n_targets',ascending=False)
big.to_csv(out/'largest_recipient_messages.csv',index=False)
print('largest_messages',big.head(10).to_dict('records'),flush=True)
r.to_csv(out/'broadcast_sensitivity.csv',index=False)
