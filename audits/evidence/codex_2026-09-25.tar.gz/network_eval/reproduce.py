import os
os.environ.setdefault('MPLCONFIGDIR', '/tmp/enron-audit-20260925.Xj3qoO/network_eval/mpl')
import sys, time, json, hashlib
from pathlib import Path
import numpy as np
import pandas as pd
from enron_importance import network, evaluate
from enron_importance.config import load_config
from enron_importance.identity import build_identities
from enron_importance.formal_rank import formal_ranks
from enron_importance.figures.baselines import draw
from enron_importance.figures.style import save

root = Path('/Users/jebfarneth/projects/enron-knowledge-decay')
out = Path('/tmp/enron-audit-20260925.Xj3qoO/network_eval') / sys.argv[1]
out.mkdir(parents=True, exist_ok=True)
config = load_config()
messages = pd.read_parquet(root/'data/processed/messages.parquet', columns=['sender','x_from','to','cc','sender_internal','sender_automated','routine'])
identities=build_identities(messages,config['senders']['internal_domain'])
identities.to_parquet(out/'identities.parquet',index=False)
titles=pd.read_excel(root/'data/raw/Enron_Employee_Status.xls',header=None,names=['name','title','note'])
ranks=formal_ranks(titles,identities,config['formal_rank']['levels'],config['formal_rank']['corrections'])
ranks.to_parquet(out/'formal_rank.parquet',index=False)
messages=messages[messages.sender_internal & ~messages.sender_automated]
print('rows_in_network', len(messages), 'routine',int(messages.routine.sum()),flush=True)
start=time.time()
edges=network.build_edges(messages,dict(zip(identities.address,identities.person_key)),config['senders']['internal_domain'])
edges.to_parquet(out/'edges.parquet',index=False)
print('built edges',len(edges),'in',time.time()-start,flush=True)
measures=network.centrality(edges)
measures.to_parquet(out/'centrality.parquet',index=False)
print('centrality complete',len(measures),'seconds',time.time()-start,flush=True)
config['paths']['processed']=out
ranked=evaluate.ranked_people(config)
table=evaluate.evaluation_table(ranked,evaluate.BASELINES,config['evaluation']['bootstrap_reps'],config['random_seed'])
table.to_csv(out/'baselines_formal_rank.csv',index=False,float_format='%.4f')
save(draw(table.round(4)),out,'fig06_baselines_formal_rank')
summary={'network_messages':len(messages),'people':len(measures),'edges':len(edges),'ranked':len(ranked),'pairs':int(np.triu(ranked.level.to_numpy()[:,None]!=ranked.level.to_numpy()[None,:],k=1).sum()),'evaluation':table.to_dict('records'),'hashes':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in out.iterdir() if p.is_file()}}
(out/'summary.json').write_text(json.dumps(summary,indent=2))
print(json.dumps(summary,indent=2),flush=True)
