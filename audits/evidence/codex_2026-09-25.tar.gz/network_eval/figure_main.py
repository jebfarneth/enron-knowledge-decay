import os
os.environ['MPLCONFIGDIR']='/tmp/enron-audit-20260925.Xj3qoO/network_eval/mpl'
from pathlib import Path
import hashlib,json
from enron_importance.figures import baselines
from enron_importance.config import load_config
base=Path('/tmp/enron-audit-20260925.Xj3qoO/network_eval')
for run in ['run1','run2']:
    out=base/run
    config=load_config();config['paths']['results']=out;config['paths']['figures']=out
    files=[out/f'fig06_baselines_formal_rank.{suffix}' for suffix in ['pdf','png']]
    before={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
    baselines.load_config=lambda:config
    baselines.main()
    after={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
    print(run,'direct_main_matches_initial_functions',before==after,'hashes',after,flush=True)
    summary=json.loads((out/'summary.json').read_text());summary['hashes'].update(after)
    (out/'summary.json').write_text(json.dumps(summary,indent=2))
