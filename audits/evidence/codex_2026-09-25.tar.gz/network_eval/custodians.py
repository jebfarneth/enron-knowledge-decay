import os
os.environ['MPLCONFIGDIR']='/tmp/enron-audit-20260925.Xj3qoO/network_eval/mpl'
from pathlib import Path
import json
import numpy as np
import pandas as pd
from enron_importance.config import load_config
from enron_importance import evaluate
root=Path('/Users/jebfarneth/projects/enron-knowledge-decay')
out=Path('/tmp/enron-audit-20260925.Xj3qoO/network_eval')
ids=pd.read_parquet(root/'data/processed/identities.parquet')
mapping=dict(zip(ids.address,ids.person_key))
raw=pd.read_parquet(root/'data/interim/messages_raw.parquet',columns=['custodian','folder','sender'])
raw['person_key']=raw.sender.map(mapping)
sent=raw[raw.folder.isin(['sent','sent_items','_sent_mail','_sent'])].dropna(subset='person_key')
counts=sent.groupby(['custodian','person_key']).size().rename('sent_count').reset_index()
tops=counts.sort_values(['custodian','sent_count'],ascending=[True,False]).groupby('custodian').head(3)
tops.to_csv(out/'custodian_candidates.csv',index=False)
print('candidate counts',len(tops), 'custodians_with_sent',tops.custodian.nunique(),flush=True)
owners=tops.groupby('custodian').first().reset_index()
owners['mailbox_files']=owners.custodian.map(raw.custodian.value_counts())
owners['sent_total']=owners.custodian.map(sent.custodian.value_counts())
owners['sent_share']=owners.sent_count/owners.sent_total
owners.to_csv(out/'custodian_owners.csv',index=False)
print(owners.to_string(index=False),flush=True)
print('NO SENT',sorted(set(raw.custodian)-set(owners.custodian)),flush=True)
