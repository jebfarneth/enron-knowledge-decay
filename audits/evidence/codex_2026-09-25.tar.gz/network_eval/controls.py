import os
os.environ['MPLCONFIGDIR']='/tmp/enron-audit-20260925.Xj3qoO/network_eval/mpl'
from pathlib import Path
import numpy as np,pandas as pd
from enron_importance import evaluate
from enron_importance.config import load_config
root=Path('/Users/jebfarneth/projects/enron-knowledge-decay')
out=Path('/tmp/enron-audit-20260925.Xj3qoO/network_eval')
ranked=evaluate.ranked_people(load_config())
measures=pd.read_parquet(root/'data/processed/centrality.parquet')
owners=pd.read_csv(out/'custodian_owners.csv')
candidates=pd.read_csv(out/'custodian_candidates.csv')
npairs=lambda x:int(np.triu(x[:,None]!=x[None,:],k=1).sum())
for definition in ['dominant_sent_sender','dominant_plus_verified_mailbox_named_executives','shared_access_sent_share_atleast10pct']:
    o=owners[['custodian','person_key','mailbox_files']].copy()
    if definition=='dominant_plus_verified_mailbox_named_executives':
        # Retain assistant as mailbox-access user, add named executive.
        for cust,key in [('lay-k','kenneth lay'),('skilling-j','jeffrey skilling')]:
            o=pd.concat([o,pd.DataFrame([{'custodian':cust,'person_key':key,'mailbox_files':int(owners.set_index('custodian').loc[cust,'mailbox_files'])}])],ignore_index=True)
    if definition=='shared_access_sent_share_atleast10pct':
        c=candidates.merge(owners[['custodian','sent_total','mailbox_files']],on='custodian')
        o=c[c.sent_count/c.sent_total>=.10][['custodian','person_key','mailbox_files']]
        # Always include named executive even where delegates dominate.
        for cust,key in [('lay-k','kenneth lay'),('skilling-j','jeffrey skilling')]:
            if key not in set(o.person_key):o=pd.concat([o,pd.DataFrame([{'custodian':cust,'person_key':key,'mailbox_files':int(owners.set_index('custodian').loc[cust,'mailbox_files'])}])],ignore_index=True)
    count=o.groupby('person_key').mailbox_files.sum()
    r=ranked.copy(); r['is_custodian']=r.person_key.isin(set(o.person_key)).astype(int);r['mailbox_file_count']=r.person_key.map(count).fillna(0)
    print('definition',definition,'ranked_with_access',int(r.is_custodian.sum()),'distinct_access_people',o.person_key.nunique(),flush=True)
    print('controls',evaluate.evaluation_table(r,['degree','is_custodian','mailbox_file_count'],1000,42).to_dict('records'),flush=True)
    mm=measures.assign(has_access=measures.person_key.isin(set(o.person_key)))
    print('degree_by_access',mm.groupby('has_access').degree.agg(['count','mean','median']).to_dict(),flush=True)
    print('spearman',r[['degree','mailbox_file_count','level']].corr(method='spearman').to_dict(),flush=True)
    for value in [0,1]:
        sub=r[r.is_custodian==value]
        print('subset',value,len(sub),npairs(sub.level.to_numpy()),evaluate.pairwise_accuracy(sub.level.to_numpy(),sub.degree.to_numpy()),flush=True)
    r.to_csv(out/f'controls_{definition}.csv',index=False)

rawranks=pd.read_parquet(root/'data/processed/formal_rank.parquet').dropna(subset=['person_key','level'])
for kind in ['min','drop_conflicts']:
    if kind=='min': rr=rawranks.groupby('person_key',as_index=False)['level'].min()
    else:
        conflicting=rawranks.groupby('person_key')['level'].nunique();bad=set(conflicting[conflicting>1].index)
        rr=rawranks[~rawranks.person_key.isin(bad)].groupby('person_key',as_index=False)['level'].max()
    rr=rr.merge(measures,on='person_key',how='left').fillna({m:0 for m in evaluate.BASELINES})
    print('rank_policy',kind,len(rr),npairs(rr.level.to_numpy()),{m:evaluate.pairwise_accuracy(rr.level.to_numpy(),rr[m].to_numpy()) for m in evaluate.BASELINES},flush=True)

# Ignored source-note hierarchy: Sally Beck is Employee but COO in same file.
r=ranked.copy();r.loc[r.person_key=='sally beck','level']=5
print('sally_beck_employee_to_5_sensitivity_not_asserted_truth',npairs(r.level.to_numpy()),evaluate.pairwise_accuracy(r.level.to_numpy(),r.degree.to_numpy()),flush=True)

# A formal mechanism-only regression control: partial rank correlation on mailbox-size rank.
r=pd.read_csv(out/'controls_dominant_plus_verified_mailbox_named_executives.csv')
x=np.c_[np.ones(len(r)),r.mailbox_file_count.rank().to_numpy(),r.is_custodian.to_numpy()]
dr=r.degree.rank().to_numpy(copy=True);lr=r.level.rank().to_numpy(copy=True)
dr-=x@np.linalg.lstsq(x,dr,rcond=None)[0];lr-=x@np.linalg.lstsq(x,lr,rcond=None)[0]
print('partial_rank_correlation_degree_title_controlling_mailcount_access',float(np.corrcoef(dr,lr)[0,1]),flush=True)
