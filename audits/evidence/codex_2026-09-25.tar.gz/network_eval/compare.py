from pathlib import Path
import hashlib,json
import pandas as pd,numpy as np
root=Path('/Users/jebfarneth/projects/enron-knowledge-decay')
out=Path('/tmp/enron-audit-20260925.Xj3qoO/network_eval')
hashof=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
results={}
for name in ['identities.parquet','formal_rank.parquet','edges.parquet','centrality.parquet','baselines_formal_rank.csv','fig06_baselines_formal_rank.pdf','fig06_baselines_formal_rank.png']:
    p=out/'run1'/name;q=out/'run2'/name
    if not p.exists() or not q.exists():continue
    old=root/('data/processed' if name.endswith('.parquet') else 'results' if name.endswith('.csv') else 'figures')/name
    row={'run1_sha256':hashof(p),'run2_sha256':hashof(q),'byte_identical':hashof(p)==hashof(q),'committed_sha256':hashof(old),'run1_matches_committed_bytes':hashof(p)==hashof(old)}
    if name.endswith('.parquet'):
        a=pd.read_parquet(p);b=pd.read_parquet(q);c=pd.read_parquet(old)
        row['same_row_order_and_values']=a.equals(b)
        keys={'identities.parquet':['address'],'formal_rank.parquet':['name'],'edges.parquet':['source','target'],'centrality.parquet':['person_key']}[name]
        a=a.sort_values(keys).reset_index(drop=True);b=b.sort_values(keys).reset_index(drop=True);c=c.sort_values(keys).reset_index(drop=True)
        row['sorted_exact_equal']=a.equals(b);row['sorted_matches_committed']=a.equals(c)
        if name=='centrality.parquet':
            row['run2_max_abs_difference']={col:float((a[col]-b[col]).abs().max()) for col in a if col!='person_key'}
            row['committed_max_abs_difference']={col:float((a[col]-c[col]).abs().max()) for col in a if col!='person_key'}
            row['changed_values_vs_run2']={col:int((a[col]!=b[col]).sum()) for col in a if col!='person_key'}
    results[name]=row
print(json.dumps(results,indent=2))
(out/'comparison.json').write_text(json.dumps(results,indent=2))
