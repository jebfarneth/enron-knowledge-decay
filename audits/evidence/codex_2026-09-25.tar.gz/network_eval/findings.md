# Network / evaluation independent audit

All commands below run from `/Users/jebfarneth/projects/enron-knowledge-decay`. Scratch root is `/tmp/enron-audit-20260925.Xj3qoO/network_eval`. Repo inputs were read only; all generated outputs are outside it. No code/config/data modifications. Both full graph/evaluation reruns completed, including exact full-graph betweenness, under separate Python processes and different hash seeds.

## Methods from code

### Communication network — plain language

The graph uses all date-windowed, deduplicated emails sent by internal addresses not flagged as automated, including messages marked routine and messages without extracted authored text. It collects To and Cc recipients but ignores Bcc. It keeps only recipient addresses ending exactly in `@enron.com`, replaces addresses by identity keys where the sender-derived identity table knows them, removes the sender's own identity, and gives each distinct remaining recipient identity an equal fraction of one message. Repeated messages accumulate directed edge weights and counts. People without any included edge are not graph nodes. Degree counts distinct contacts without using those weights. Incoming/outgoing strength sums weights. PageRank runs on the directed weighted graph. Betweenness runs on a separate undirected graph that sums both directions' weights, using inverse weight as distance. Thus a strong tie is short, but the ordinary degree measure is not protected from large broadcasts by the fractional weighting.

### Communication network — technical Methods wording

From processed messages, select `sender_internal & ~sender_automated` (`network.py:72–75`), without authored-text or routine filtering. For message m, map sender s and the set union of To/Cc addresses having the exact internal-domain suffix through `address_to_person`, retaining unmapped addresses as node keys. Let T_m be the set of distinct mapped recipient keys excluding s. For |T_m|>0, add 1/|T_m| to w_st and 1 to the integer message counter for every t in T_m (`network.py:34–49`). Node set is the union of edge endpoints, not all identities. Build a directed igraph graph; collapse reciprocal arcs into undirected edges with summed weights. Report undirected unweighted degree, weighted directed in/out strength, directed weighted PageRank with hard-coded damping 0.85, and unnormalized exact undirected betweenness using length 1/w (`network.py:53–65`). No sample parameter is passed to igraph betweenness. The suffix domain is config `senders.internal_domain`; damping and metric choices are **not** in config. Bcc, time variation, uncertainty in identity resolution, and mailbox inclusion are not modeled.

### Evaluation — plain language

The evaluation only uses people whose source title can be mapped to a configured level and identity. If one identity has multiple titles, the code chooses the highest level. It looks up each person's centralities, supplying zero for missing values. Every unordered pair at different title levels is checked: the more senior person should have the higher score; an exact score tie earns half credit. Confidence intervals repeatedly resample people, retaining all repetitions of a sampled person, then recompute those pairs. These intervals describe resampling of this particular labeled set on this fixed observed graph; the code does not resample mailboxes or messages, correct title errors, or establish an external measure of functional importance.

### Evaluation — technical Methods wording

Drop title rows missing person key or level; aggregate by person using maximum level; left-join centralities and zero-impute missing baseline scores (`evaluate.py:56–63`). Let d_ij=sign(l_i−l_j), s_ij=sign(x_i−x_j). For i<j and d_ij≠0, award 1 if d_ij=s_ij, 0.5 if s_ij=0, otherwise 0; take the arithmetic mean (`evaluate.py:25–34`). There are 129 persons and 6,285 eligible pairs under the current title mapping. For each score, initialize `numpy.random.default_rng(42)`, draw 129 indices with replacement 1,000 times, and use the 2.5/97.5 `nanpercentile` of the recomputed accuracies (`evaluate.py:37–52`, `config.yaml:83–91`). The same seed is restarted for each measure, giving paired draws suitable for method-difference intervals, although the shipped evaluation only reports separate marginal intervals. The bootstrap conditions on the already-built graph, resolved identities, chosen titles, and selected labeled people. It is a plug-in person-sampling uncertainty calculation, not demonstrated coverage for the whole Enron workforce.

### Figure 6 — plain language and technical description

The figure reads the rounded baseline CSV, sorts measures by point accuracy, and draws point estimates with horizontal percentile intervals and a chance line at 0.5. Technical details: CSV input at `figures/baselines.py:52`; ascending sort at line 26; intervals/points at lines 32–36; fixed x-axis 0.4–0.8 at line 39. It does not calculate significance of differences. The shared save helper removes PDF CreationDate (`figures/style.py:48–50`), writes PDF plus 200-DPI PNG, and closes the figure. Hard-coded damping, figure range, and bootstrap quantiles contradict the literal blanket statement that all parameters are in config, although not the substantive mathematics.

## Verified arithmetic and algorithm checks

Command: `PYTHONDONTWRITEBYTECODE=1 .venv/bin/python -u /tmp/enron-audit-20260925.Xj3qoO/network_eval/investigate.py` (stdout `investigate_output.txt`; an unrelated last-step scratch-script error was corrected in `controls.py`; all reported checks precede it).

- Independent scalar edge aggregation, without calling the project's edge builder: same 220,807 (source,target) keys; maximum weight difference 0.0; message-count mismatches 0. Network selection includes 191,814 messages, of which 6,269 are routine; 159,157 contribute at least one nonself internal target; total edge weight 159,157.0.
- There are zero self-loops; all 15,240 recipient-only fallback keys are internal-domain strings, not outside-domain addresses. This checks syntactic domain filtering, not whether CMU's addresses are genuinely Enron employees.
- Independently enumerated all 729 three-person level/score combinations with values 0/1/2: exact agreement with a scalar pair-by-pair oracle, including mixed ties and undefined all-same-level cases.
- Independently tested 1,000 four-person bootstrap resamples against the weighted-unique-pair formula c_i c_j. Exact agreement. Repeated copies of one original person share a level and are excluded from comparison with themselves; their cross-person multiplicities are correctly retained. Duplicated people are **not** a bootstrap bug.
- Hand graph a→b weight2, b→a8, b→c10, a→c1 gives undirected a–b weight10; path a–b–c length0.2 beats direct a–c length1. Code returns b betweenness1, others0, validating inverse weights and reciprocal collapse on a case with a known answer.
- Alias normalization example: To contains self, b, an alias of b, c. Code yields b0.5, c0.5, not four address shares. The actual algorithm weights unique nonself **identities**, so paper wording should say that explicitly.

Further independent numerical oracles: `PYTHONDONTWRITEBYTECODE=1 .venv/bin/python -u /tmp/enron-audit-20260925.Xj3qoO/network_eval/numeric_oracles.py` → `numeric_oracles_output.txt`. A separately coded PageRank power iteration using NumPy `bincount` (uniform teleportation, uniform redistribution of dangling-node mass, damping0.85) converged on the full21,047-node graph in113 iterations to L1 step9.828e−14, maximum discrepancy6.155e−14 from committed PageRank. Independent enumeration of **every simple path** for all source-target pairs on30 random five-node graphs, with exact dyadic lengths and shortest-path tie accounting, matched the project's weighted betweenness with maximum error0. This goes beyond trusting igraph or the project's fixtures.

## Major findings / methodological limits

### Graph is not 21,047 validated people

Evidence: `investigate.py`, stdout lines beginning `network address unresolved`, `node_zero...`; code `identity.py:67–79` creates identities only for senders while `network.py:39–40` uses raw-address fallback for unknown recipients. Among 21,047 nodes, **15,240 (72.41%) are recipient-only addresses absent from the identity table**; only 5,807 nodes match an identity key. **15,301 have zero out-strength**. A node named `center.dl-portland@enron.com` has degree49, in-strength357.983369, and betweenness1,050,047. Actual correspondence and identity evidence are needed before treating role/list addresses as people. `cliff.baxter@enron.com` is a recipient-only node with degree84; `berney.aucoin@enron.com` is a separate unresolved recipient node with degree58 despite a ranked `berney aucoin` identity with degree81. The last example warrants identity evidence before merging, but definitively shows the current node table does not complete recipient-side resolution.

Impact: the title-accuracy computation remains a reproducible calculation on this graph, but whole-network centralities/claims about employees inherit unvalidated receiver aliases, administrative/list nodes, and source address synthesis. Fix: extend resolution to recipient metadata, maintain uncertainty/role-mailbox classifications, and call the current object an address/identity hybrid graph; report sensitivity excluding unresolved and role nodes.

### CMU placeholder aliases directly corrupt a named person's network score

Command: `PYTHONDONTWRITEBYTECODE=1 .venv/bin/python -u /tmp/enron-audit-20260925.Xj3qoO/network_eval/noaddress.py` → `noaddress_output.txt`. Code: `identity.py:69–77`, `network.py:39–40`. The identities table maps `no.address@enron.com` to `don miller`; the identity audit supplies independent raw X-From conflicts. Excluding the placeholder as both sender and recipient removes 778 messages from network candidates. Don Miller's degree falls **491→128**; original degree rank is66. Graph becomes21,032 nodes/220,441 edges; 364 node degrees change. Aggregate title degree accuracy changes only **0.647494→0.647971**, and PageRank becomes0.614320. Therefore this is a demonstrable person-attribution failure, not evidence that the entire aggregate rank result vanishes.

Fix: quarantine placeholder/synthetic addresses before person resolution and graph construction; do not assign them to the plurality display name. Keep evidence and unknown identity explicitly.

### Labeled population and mailbox availability are unmodeled selection mechanisms

Commands: `custodians.py` constructs sent-folder candidates; `controls.py` evaluates three operational definitions. Outputs: `custodian_candidates.csv`, `custodian_owners.csv`, `controls_output.txt`, and `controls_*.csv`. Source lines: network selection `network.py:72–75`; fixed-label evaluation `evaluate.py:56–63`.

Define a conservative mailbox-access proxy as the dominant mapped sender in `sent`, `sent_items`, `_sent_mail`, or `_sent`, adding Kenneth Lay and Jeffrey Skilling based on their named mailbox and actual sent records. This is **not** a validated owner roster: assistants share executive mailboxes, 2/150 custodians have no sent-folder data, and conflicting name/owner evidence exists. Under that proxy **104/129** ranked people are linked to corpus mailboxes. Their median degree is201 versus3 for other graph nodes; labeled-person Spearman correlation of mailbox-file count and degree is0.599. Broader access proxy (top sender candidates accounting for≥10% of sent-folder messages, plus named executives) gives106/129 and median degree198.5 versus3. Dominant-sender-only gives102/129. Report the range and qualification rather than assert an exact gold count.

Crucial negative control: under the conservative proxy, `is_custodian` accuracy is**0.439220** (95% CI0.390726–0.483697), raw mailbox-file-count accuracy **0.482100** (0.401620–0.557182), compared with degree**0.647494** (0.567961–0.719304). Across all three proxy definitions those trivial accuracies stay below degree. Degree restricted to the104 proxy-custodian labeled people is0.693660 on3,896 pairs; nonproxy25 people give0.653680 on231 pairs. Partial rank correlation of degree/title controlling mailbox size and access is0.40611. These checks **do not support** the hypothesis that the reported ranking accuracy is just raw mailbox size. They do show a highly selected, availability-dependent graph, not a representative measurement of employees' functional importance. Require mailbox-aware validation, documented population boundaries, and title/role strata before generalization.

### Fractional edge weights do not neutralize broadcasts for degree

Command: `PYTHONDONTWRITEBYTECODE=1 .venv/bin/python -u /tmp/enron-audit-20260925.Xj3qoO/network_eval/broadcasts.py` → `broadcasts_output.txt`, `broadcast_sensitivity.csv`, `largest_recipient_messages.csv`. Code: weighting `network.py:43–46`, unweighted degree line61; docstring lines5–6 and commit `e164fd2` broadly justify weights as preventing broadcast domination.

Among191,814 network messages,3,573 have>50 unique internal target identities,1,329 have>100; maximum889. `maildir/lay-k/sent_items/10.` alone has879 targets. Removing>50-target messages reduces Kenneth Lay's degree1394→458, Jeffrey Skilling1043→380, Sally Beck1441→781. Aggregate accuracy stays0.646539 (full0.647494), so this sensitivity does not refute aggregate ordering. Restricting to one-recipient messages yields0.555688;≤5 recipients0.602546;≤10 recipients0.624662. This reveals that broad contact exposure and rank-related broadcast affordances contribute substantially to the meaning of the score; it does not prove all broadcast contacts are invalid.

Fix: explicitly state that fractionation affects weighted strengths/PageRank/betweenness, not degree, and include recipient-count-stratified sensitivities or a substantive communication-exchange definition before interpreting degree as functional importance.

## Minor / interpretation findings

### Floating arithmetic breaks intended ties and changes the reported evaluation across processes

Commands: `PYTHONDONTWRITEBYTECODE=1 PYTHONHASHSEED=101 .venv/bin/python -u /tmp/enron-audit-20260925.Xj3qoO/network_eval/reproduce.py run1`; analogous run2 with `PYTHONHASHSEED=202`; `PYTHONDONTWRITEBYTECODE=1 .venv/bin/python -u /tmp/enron-audit-20260925.Xj3qoO/network_eval/float_ties.py`. Evidence code: set iteration `network.py:38–45`, igraph strength accumulation `network.py:63`, exact subtraction/sign tie test `evaluate.py:28,33`.

One eligible message contributes total outgoing weight exactly1 mathematically, so weighted out-strength is an integer number of contributing messages per source. Floating sums depart from integers by up to1.97815e−11. Among the6,285 evaluated different-level pairs,14 have equal integer totals; run1 treats11 of those as strict orderings. For example Geir Solberg(level0) and Geoffrey Storey(level2) both have72 contributing messages: committed scores are72/72 but run1 scores72.00000000000001/72, changing the pair's credit0.5→0. Michael Curry(level1) and Michael Swerzbin(level3) likewise change59/59→59.00000000000001/59, credit0.5→0.

Consequently committed out-strength accuracy is0.5171837709 (CSV0.5172) while run1 gives0.5170246619 (CSV0.5170), despite the sorted edge lists matching exactly. Using mathematically exact integer totals gives0.5175815434, CI0.4397790954–0.5953736687. The near-chance conclusion is unchanged; exact reproducibility and the claimed half-credit tie semantics are not. Fix: compute outgoing counts as integers directly; stabilize edge/node order; define scientifically justified numerical tie handling for other floating scores; add cross-process regression tests with equal true totals distributed across different numbers of edges.

The integer totals were subsequently **independently counted from source processed messages**, without using graph weights or rounding: count one unit for each internal/nonautomated message containing at least one nonself internal To/Cc target. Total159,157; zero mismatches between those integer counts and rounded floating out-strength over all21,047 nodes. Full evidence table is `exact_outgoing_counts.csv`. Run2 confirms the nondeterminism with out-strength accuracy0.5172633254 (CSV0.5173), CI0.4388654782–0.5947707149.

### Highest point estimate is not demonstrated superiority

Command: `investigate.py` output `degree_minus_pagerank_bootstrap`. Same1,000 paired person resamples/seed42 as shipped. Degree−PageRank=**0.033492**, percentile95% difference CI**−0.009661 to0.072080**. README58–60 and commit953b4b3 call degree “strongest”; accurate only as highest observed point estimate, not demonstrated superior predictive performance. Fix wording or show paired differences; do not compare overlapping marginal intervals informally.

### Source-label choice matters, and highest-level duplicate resolution is untested

Command: `controls.py`; source `evaluate.py:59–60`, `formal_rank.py:62–65`. Two identities have conflicting VP/Trader entries. Replacing maximum by minimum gives6,235 pairs, degree0.651724, in-strength0.611067, out-strength0.521652, PageRank0.616359, betweenness0.574659. Removing both conflicted identities gives127 people/6,081 pairs and degree0.651044. The independent identity/title audit supplies the source evidence for which labels are supportable. The ignored spreadsheet note marks Sally Beck “Chief Operating Officer” while title column is“Employee”; a purely illustrative change to level5 raises degree accuracy to0.661848 on6,330 pairs, showing the target is sensitive to title-column interpretation. This illustration is not a verified replacement rank. Fix source reconciliation, date/unit scope, and tests for conflict policy.

### Test gaps relevant to this audit

`tests/test_network.py` has3 synthetic graph tests (lines11–42); `tests/test_evaluate.py` has5 arithmetic/bootstrap/table tests (lines8–39); `tests/test_figures.py:14–22` checks ordering/rendering. The graph tests correctly check inverse-weight direction (not merely names); my independent hand case confirms it. Missing coverage: recipient-only aliases/role nodes/placeholder addresses; end-to-end sender filtering; repeat-process byte/numeric determinism; genuine corpus-owner cases; title conflicts and missing-centrality zero filling; bootstrap coverage assumptions or paired differences. A source-placeholder name collapse can be catastrophically wrong for a person while all existing network tests pass. Repeating one deterministic CI and checking it brackets one synthetic estimate is not a coverage test. Add independent corpus regression cases and avoid treating passing fixture tests as validation of identity or construct validity.

## What is not established

- No reference truth for functional importance; title agreement is convergent evidence against chosen title labels, not validation that importance is measured.
- The person bootstrap correctly handles duplicated draws, but no repeated-corpus sampling or cluster-aware empirical coverage test establishes its nominal95% coverage for the true workforce graph. Do not assert that it is definitely too narrow or too wide from the implemented formula alone.
- Custodian proxies are stated heuristics rather than a verified150-owner roster; no exact percentage of centrality explained causally by mailbox availability is claimed.
- No full alternative-network betweenness sensitivity rerun (placeholder/broadcast exclusion) was attempted; only cheap degree/PageRank sensitivity plus full original-graph exact reruns.

## Completed reproduction and checksum results

Commands, executed in independent processes:

```sh
PYTHONDONTWRITEBYTECODE=1 PYTHONHASHSEED=101 .venv/bin/python -u /tmp/enron-audit-20260925.Xj3qoO/network_eval/reproduce.py run1
PYTHONDONTWRITEBYTECODE=1 PYTHONHASHSEED=202 .venv/bin/python -u /tmp/enron-audit-20260925.Xj3qoO/network_eval/reproduce.py run2
PYTHONDONTWRITEBYTECODE=1 .venv/bin/python -u /tmp/enron-audit-20260925.Xj3qoO/network_eval/figure_main.py
PYTHONDONTWRITEBYTECODE=1 .venv/bin/python -u /tmp/enron-audit-20260925.Xj3qoO/network_eval/compare.py
```

`reproduce.py` reads the current processed messages, independently rebuilds identity and formal-rank tables from source functions and the XLS, then rebuilds edges, recalculates **all** centralities including exact all-node betweenness, evaluates all baselines, and renders figure6 outside the repository. `figure_main.py` additionally calls the project's actual figure `main()` on each regenerated CSV with only output-path configuration redirected. `run1/summary.json`, `run2/summary.json`, and `comparison.json` contain full-precision values and SHA-256 hashes. The mathematical subchecks use independent implementations, not merely these source calls.

| Claim | Run1 | Run2 | Result |
|---|---:|---:|---|
|21,047 graph nodes|21,047|21,047|Numeric match; nodes are not all validated people|
|220,807 directed edges|220,807|220,807|Match|
|129 ranked persons|129|129|Match under current identity/title policy|
|6,285 different-level pairs|6,285|6,285|Match|
|Degree0.647; CI0.568–0.719|0.6474940334;0.5679609760–0.7193037872|Same|Match|
|PageRank0.614|0.6140015911;CI0.5332828772–0.6845796014|Same|Match|
|In-strength0.604|0.6035003978;CI0.5250726997–0.6743004272|Same|Match at claimed precision|
|Betweenness0.567|0.5673826571;CI0.4831074615–0.6384996627|Same|Match|
|Out-strength0.517|0.5170246619;CI0.4388527642–0.5947447841|0.5172633254;CI0.4388654782–0.5947707149|Matches three-decimal claim; **mismatches committed CSV0.5172 and fails exact repeatability**|

Repeatability findings:

- `identities.parquet` and `formal_rank.parquet` are byte-identical in run1, run2, and the repository.
- `edges.parquet` has different hashes across all three, but sorting by `(source,target)` produces exact equality, including every weight and message count. Thus current processed inputs reproduce the older graph content: timestamps alone do **not** establish stale substantive output. Run1 edge SHA=`ee992e5227c79749ef647513d872d50c6a317d478a8d30e5b1e9c459c5ecd91f`; run2=`de1ea60f055436a6cde2e062c404de1dc28e60ca4e6b50f26f41430f637c47b3`; committed=`df4b3049ee3a103917a089aaa49ff07fed536e09c3bd7d6bb26df6b1d5d2fb78`.
- After sorting by person, degree, in-strength, and **betweenness are exactly identical across both reruns and the repository**. Run1/run2 maximum difference is5.68434e−13 for out-strength(890 nodes differ) and3.91354e−15 for PageRank(21,042 nodes differ). Against committed scores the corresponding maxima are7.38964e−13 and4.35329e−15. Tiny differences do not change PageRank ranking accuracy here, but change out-strength tie credits as shown above.
- Therefore `centrality.parquet` and `baselines_formal_rank.csv` are not byte-identical. Bootstrap seed42 is applied correctly; it cannot repair prior floating-score differences caused by uncontrolled set/graph ordering.
- Figure6 PDF is not byte-identical across runs. PNG run1 matches committed output while run2 differs, tracking the small changed plotted out-strength estimate/interval. See `comparison.json` for complete hashes, and `figure_main_output.txt` for the actual figure-entrypoint verification. This is not evidence that figure style rendering itself is random: its input table genuinely differs.

All network/evaluation audit processes have finished; none remain running.
