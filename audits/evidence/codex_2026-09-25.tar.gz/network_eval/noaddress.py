import os
os.environ['MPLCONFIGDIR']='/tmp/enron-audit-20260925.Xj3qoO/network_eval/mpl'
from pathlib import Path
import pandas as pd, numpy as np
import igraph as ig
from enron_importance.network import build_edges
from enron_importance.evaluate import ranked_people,pairwise_accuracy
from enron_importance.config import load_config
root=Path('/Users/jebfarneth/projects/enron-knowledge-decay')
out=Path('/tmp/enron-audit-20260925.Xj3qoO/network_eval')
ids=pd.read_parquet(root/'data/processed/identities.parquet')
msg=pd.read_parquet(root/'data/processed/messages.parquet',columns=['sender','to','cc','sender_internal','sender_automated'])
msg=msg[msg.sender_internal & ~msg.sender_automated]
bad={'no.address@enron.com','no_address@enron.com'}
print('bad_senders',msg[msg.sender.isin(bad)].sender.value_counts().to_dict(),flush=True)
before=len(msg)
msg=msg[~msg.sender.isin(bad)].copy()
for col in ['to','cc']: msg[col]=msg[col].map(lambda seq:[x for x in seq if x not in bad])
edges=build_edges(msg,dict(zip(ids.address,ids.person_key)),'enron.com')
g=ig.Graph.TupleList(edges[['source','target','weight']].itertuples(index=False),directed=True,edge_attrs=['weight'])
u=g.as_undirected(mode='collapse',combine_edges={'weight':'sum'})
alt=pd.DataFrame({'person_key':g.vs['name'],'degree_new':u.degree(),'pagerank_new':g.pagerank(weights='weight',damping=.85)})
measures=pd.read_parquet(root/'data/processed/centrality.parquet')
compare=measures.merge(alt,on='person_key',how='left').fillna(0)
compare['degree_change']=compare.degree_new-compare.degree
compare.sort_values('degree_change').head(25).to_csv(out/'noaddress_largest_changes.csv',index=False)
r=ranked_people(load_config()).merge(alt,on='person_key',how='left').fillna(0)
print('removal_result',{'nodes':len(alt),'edges':len(edges),'removed_messages':before-len(msg),'degree_accuracy_old':pairwise_accuracy(r.level.to_numpy(),r.degree.to_numpy()),'degree_accuracy_new':pairwise_accuracy(r.level.to_numpy(),r.degree_new.to_numpy()),'pagerank_accuracy_new':pairwise_accuracy(r.level.to_numpy(),r.pagerank_new.to_numpy()),'nodes_degree_changed':int((compare.degree_change!=0).sum())},flush=True)
print('don_miller',compare[compare.person_key=='don miller'].to_dict('records'),flush=True)
print('don_miller_rank',int((measures.degree>measures.loc[measures.person_key=='don miller','degree'].iloc[0]).sum()+1),flush=True)
print('ranked_degree_changes',r.loc[r.degree!=r.degree_new,['person_key','level','degree','degree_new']].to_dict('records'),flush=True)
