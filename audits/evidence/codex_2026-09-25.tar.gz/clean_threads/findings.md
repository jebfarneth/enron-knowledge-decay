# Independent cleaning/thread audit findings

Audit date: 2026-09-25. Repository was read-only for this subaudit. All scripts and outputs are under `/tmp/enron-audit-20260925.Xj3qoO/clean_threads/` (abbreviated `SCRATCH` below). Methods are in `methods.md`. This is a manual Codex audit, not a human/expert annotated gold standard; two agents reviewed non-overlapping halves of 200 messages, which is not an inter-rater agreement exercise.

## Exact reproduction commands and evidence files

Run from `/Users/jebfarneth/projects/enron-knowledge-decay`:

```sh
PYTHONDONTWRITEBYTECODE=1 .venv/bin/python /tmp/enron-audit-20260925.Xj3qoO/clean_threads/audit_clean_threads.py
PYTHONDONTWRITEBYTECODE=1 .venv/bin/python /tmp/enron-audit-20260925.Xj3qoO/clean_threads/negative_controls.py
PYTHONDONTWRITEBYTECODE=1 .venv/bin/python /tmp/enron-audit-20260925.Xj3qoO/clean_threads/supplement.py
PYTHONDONTWRITEBYTECODE=1 .venv/bin/python /tmp/enron-audit-20260925.Xj3qoO/clean_threads/thread_probes.py
PYTHONDONTWRITEBYTECODE=1 .venv/bin/python /tmp/enron-audit-20260925.Xj3qoO/clean_threads/thread_analysis_subset.py
PYTHONDONTWRITEBYTECODE=1 .venv/bin/python /tmp/enron-audit-20260925.Xj3qoO/clean_threads/alias_examples.py
python3 /tmp/enron-audit-20260925.Xj3qoO/clean_threads/record_manual_labels.py
```

The last command serializes the recorded manual judgments; it does not automatically recreate human/Codex judgments from rules. The first command regenerates exact sampled raw/authored pairs and both cleaner outputs. Review commands: `python3 SCRATCH/review.py clean 0 20` (and subsequent intervals), `python3 SCRATCH/review.py thread 0 15` (and subsequent intervals). Full raw/authored bodies, including omitted middles from the display helper, were subsequently inspected directly from the JSON for all 200 cleaner cases. Thread review inspected the portions establishing the parent relationship, not every long newsletter appendix.

## Reproduction

The existing processed data contain **47,130 linked messages and 206,747 threads**, matching claims. Root's pipeline reproduction is the independent reconstruction check; this subaudit also reruns relevant methods in scratch.

The exact 5,000-message, seed42 comparison gives **0.764 equality, 1.0 median token-set Jaccard, and 0.7966 Jaccard >=0.9**. Marker prevalence is original-message `.0002/.0212`, forwarded-by `.0002/.0636`, quoted-header `.0108/.079`, and angle-quote `0/.001`, project cleaner/email_reply_parser respectively. `crosscheck.json` and `crosscheck_repeat.json` are byte-identical; both equal the committed summary's values. Evidence: `audit_clean_threads.py`, `crosscheck_rows.csv`, two summary JSONs. Equality is after whitespace normalization, not raw character equality.

## Major: inferred reply links cannot be treated as validated responses

**Code:** `src/enron_importance/threads.py:32–46`; docstring `:3–11`; `prepare.py:60`. The rule accepts any same-subject message sent to the current raw sender in the last14days, without requiring the current message to address the earlier sender, a reply prefix, or quotation evidence. Linking happens before automation/routine exclusion. This is not an implementation departure from the documented heuristic; the defect is treating its outputs as observed reply/response-time ground truth.

**Checked evidence:** simple random sample of60 of47,130 links, seed20260925, recorded in `manual_thread_sample60.json` and `manual_thread_labels60.json`:

| Manual class | Count |
|---|---:|
| Supported direct reply |27|
| Forward/relay with the correct source, not a direct reply |10|
| Wrong immediate parent |12|
| Independent broadcast or unrelated topic |4|
| Same-author related update, not a reply |1|
| Uncertain immediate parent |6|

Confirmed direct replies are27/60=45%; counting every uncertain case as valid gives33/60=55%. These are descriptive sample bounds, not a globally calibrated precision confidence interval. Same-conversation linkage is a different, more permissive target and must not be assigned the45% number. At least16/60 have a wrong immediate parent or independent/unrelated message; forwards and update messages are separate categories rather than falsely calling them unrelated.

The problem is not confined to excluded messages: there are **35,568 linked messages in the text-analysis set**. Forty-five of the 60 sampled children pass that analysis mask; their classes are 22 supported direct replies, 10 wrong immediate parents, 2 independent/unrelated broadcasts, 5 forwards, 1 same-author update, and 5 uncertain. The descriptive direct-reply fraction in this nested subset is 22/45 = 48.9%, or 27/45 = 60% if all uncertain cases are counted. This is a subset of the same sample, not additional independent validation. Evidence: `thread_analysis_subset.py` and `manual_thread_analysis_subset.json`.

Reproducible examples:

- ID44: `maildir/hodge-j/deleted_items/466.` (Carol St.Clair, **Netting agreement**,2001-11-16) is linked to `maildir/heard-m/inbox/255.` (John Viverito). The child concerns Carolina Power & Light/Florida Power/North Carolina Natural Gas; the selected parent lists Dreyfuss/Richardson/Navajo/Unocal. This is a generic-subject collision, not a response.
- ID11: `maildir/dasovich-j/sent/662.` answers a quoted Jacqueline Kelly 14:03 message, addressed to Jeff's external `dasovich@haas.berkeley.edu` alias. The inferred parent is Kimberly Kupiecki 10:16, `maildir/dasovich-j/notes_inbox/959.`, not the quoted person/message.
- ID13: `maildir/bass-e/sent/1335.` quotes Bryan Hull 12/21 14:01 while the selected parent is Matthew Lenhart 12/20, `maildir/lenhart-m/sent/112.`, under **Happy Hour**. Exact pairs and quotes are stored in the sample JSON.
- IDs36 and52 are causally inverted: selected parents already quote the entirety of their purported children. ID52 `maildir/kaminski-v/var/2.` at22:57 is linked to `maildir/kaminski-v/sent/8.` at13:00, whose quoted original is David Port12:57. Stored timestamp/duplicate artifacts can therefore turn original messages into apparent responses.
- ID2, `maildir/guzman-m/notes_inbox/581.` linked to `582.`, is a self-addressed **Schedule Crawler: HourAhead Failure** alert linked to the prior hour's independent alert. ID24, `maildir/dasovich-j/notes_inbox/4677.` linked to `4723.`, is a March 28 Enron Mentions digest linked to the March 23 digest. ID29, `maildir/watson-k/e_mail_bin/657.` linked to `maildir/schoolcraft-d/inbox/junk/333.`, consists of two independently distributed copies of a travel-services announcement.

Full paths for every case, classification, and semantic evidence are in `manual_thread_labels60.json`; preserve those along with the report for reproducibility.

**Structural census:**4,150/47,130 linked pairs have identical raw sender strings, and13,908/47,130 do not address the selected parent sender in current To/Cc. These are diagnostic strata, not automatic error counts. Generic groups in `largest_subject_groups.csv`: empty normalized subject17,443 messages/0links (7,293 quote-flagged); Schedule Crawler623/622links and the `<codesite>` variant229/226; Lunch302/73; `(no subject)`297/47; Hi278/47; Enron Mentions285/34. Empty/Re:/FW:-only subjects are excluded outright byline32.

**Full rerun sensitivity and runtime:** Canonicalizing sender/To/Cc through the existing identity map before calling the unmodified `link_replies` yields 47,513 links: 383 previously unlinked messages gain a link and 20 existing links change parents. Adding Bcc to the raw recipient union yields **zero additional links** on this corpus. Alias-run elapsed wall time was 365.15 seconds under concurrent audit load; this is reproducible-run timing, not an isolated performance benchmark. The implementation loops over prior messages within subject groups (`threads.py:39–46`) and has quadratic worst-case comparisons within a dense nonmatching group. Empty subjects are explicitly skipped rather than scanned. No hang or exception occurred in either counterfactual rerun. Evidence: `thread_alias_bcc.json` and `thread_probes.py`.

**Missed-link investigation:** From 75,325 unlinked, quote-flagged messages, a fresh sample of 300 (seed 20260926) was searched for exact, whitespace/case-normalized, unique 80-character authored prefixes (at least 12 words) inside the quoted suffix. This yielded 72 candidate predecessor pairs for 57 messages, using 145,248 unique prefix keys; 11 pairs have changed normalized subjects, 12 have empty current subjects, two are alias-only recipient matches, and zero are Bcc-only recipient matches. These are **candidate-source overlaps, not true-reply counts**: they include ancestors, forwarded articles, boilerplate collisions and sources outside 14 days. Global reply recall cannot be estimated from this search.

Four checked candidates are real missed direct replies: candidate 14 `maildir/kaminski-v/deleted_items/1328.` replies to `maildir/kaminski-v/sent_items/929.` (Kevin Presto alias mismatch); candidate 42 `maildir/maggi-m/sent_items/94.` replies to `maildir/maggi-m/deleted_items/2280.`; candidate 60 `maildir/arnold-j/sent_items/25.` replies to `maildir/arnold-j/notes_inbox/81.`; and candidate 71 `maildir/ring-r/inbox/59.` replies to `maildir/ring-r/sent_items/19.`. The last three are omitted solely because the normalized subject is empty despite matching recipient and time conditions. Separate purposive inspection of five alias-added pairs (`alias_examples.json`) confirms five matching quoted immediate sources, including `maildir/allen-p/sent_items/114.` / `maildir/dasovich-j/sent/11755.` and `maildir/campbell-l/sent_items/42.` / `maildir/campbell-l/notes_inbox/509.`. Do not generalize five selected examples to all 383 additions.

The other alias-only candidate is a warning against blindly applying identity normalization: `maildir/taylor-m/sent_items/336.` explicitly asks Janette to **"delete Mark A Taylor and add me as Mark E Taylor"** and quotes a Mark A → Mark E (Legal) forward. The map treats current Mark E as equivalent to broadcast recipient Mark A, even though the raw message itself establishes that they are different people. Candidate 63 links this text to `maildir/nemec-g/inbox/1204.`. Ten reviewed missed-source dispositions are in `manual_missed_link_examples.json`; raw examples and metadata in `unlinked_quoted_candidate_pairs.json`. This confirms at least one false identity equivalence without assuming the alias map is ground truth.

**Impact/fix:** Phase3 speech-act dependencies and response speed would mix replies, routing/forwarding, repeated alerts, and wrong ancestors. Do not use `response_seconds` as behavioral evidence without a held-out annotated parent-link benchmark and explicit reply/forward classification. Use canonical identities cautiously, recover quoted sender/time/body where possible, distinguish thread membership from direct parent, and abstain on low-information generic subjects. Exclude feeds before response-time analysis. Test sensitivity to alias, window, and empty-subject handling. Do not simply add Bcc to improve recall without privacy/recipient semantics and false-positive checks.

## Major: quote truncation drops real inline answers and misses flat headers

**Code:** `clean.py:77–92` cuts all content after the earliest marker. `:29–31` is broad Lotus detection,`:50` cuts at Received/Return-path/Content-transfer-encoding. No reconstruction of bottom-posted or interleaved answers exists.

**Fresh detector-positive sample:**200 random messages from112,277 `has_quoted=True`, seed20260925. Seven retain quoted headers (3.5%), zero retain confirmed quoted-body prose, one drops confirmed substantive current-author prose (0.5%), and one has ambiguous copied-table authorship. This is conditional on the cleaner itself detecting quotation, so it cannot establish corpus-wide quote recall. Exact full-case labels: `manual_clean_combined.json`.

- Definite false cut ID49, `maildir/shackleton-s/sent_items/27.`: starts with an Original Message block; genuine inline Sara replies are marked `[Shackleton, Sara]`, including **"not yet"** and a sentence about engaging bankruptcy lawyers. Both cleaners produce the empty string. This is a real example, not just a synthetic bottom-posting attack.
- ID20, `maildir/farmer-d/sent/369.` retains the quoted Aimee Lannou name/date line after Daren's own message. ID82, `maildir/shackleton-s/notes_inbox/4.` retains Spanish original-message/De/Para/Fecha/Asunto headers; email_reply_parser removes them. The otherfive cases are IDs140,141,162,174,186, recorded in the combined JSON.

**Fresh detector-negative analysis stratum:**40 messages sampled seed20260927 from88,186 internal/nonautomated/nonroutine/nonempty analysis messages with`has_quoted=False`. Full raw/authored inspection found one full multi-author chain retained by both cleaners: `maildir/shackleton-s/nelson/336.`. Its Lotus headers have name/date/To/cc/Subject on a single line. Authored output is4,132characters versus4,156raw characters, with several older messages credited to the current sender. This is1/40=2.5% in a small, restricted sample, not a precise global error estimate. Two additional messages retain explicitly copied non-email sources (contract text and third-party memorandum); these are not classified as failed email-quote detection but matter to an authorship/topic-ownership construct. All40labels: `manual_unflagged_labels40.json`.

**Targeted Lotus/Received checks:** `marker_diagnostics.json` counts 34,694 Lotus pattern 3 matches and 14,100 earliest cuts; 1,550 transport-header pattern 8 matches and 888 earliest cuts. Inspected 20 seeded examples per pattern, drawn from the first 250 earliest-hit examples saved in archive order: 0 confirmed natural false-boundary cases among these 40. Exact boundary contexts and manual dispositions are in `manual_marker_boundaries40.json`, reproduced by `record_manual_labels.py`. This is a convenience-stratum check, not a random population prevalence estimate. It does not invalidate the broader false-cut finding above. Synthetic negative controls do demonstrate overbreadth: a current-author `Received: from supplier, 20 barrels.` line deletes itself and following text, and `Meeting agenda\n05/14/2001 09:00 AM\nTo: operations staff\n...` loses all content. These controls are in `negative_controls.py/json`; do not report their occurrence as a measured corpus rate.

**Impact/fix:** Inline answers can disappear entirely, while undetected chains inflate a sender's subject-matter contributions and reproduce other employees' text/titles. Preserve spans and provenance rather than assuming the top prefix is all authorship. Create held-out span annotations covering inline/bottom replies, flat/foreign-language headers, date-like prose, logs, signatures, and copied documents; report retention recall and contamination separately. Until then, call this `estimated top-posted text`, not verified sender-authored text.

## Major for Phase3: title/signature and copied-source leakage remains

**Code:** `clean.py:83–92` does not remove ordinary signatures. Keyword screen over167,905 analysis messages finds6,761messages (4.03%) from1,503resolved people with a broad job-title term, and3,895messages from1,068people have one within the last8lines. This is a **keyword screen, not a measured own-title rate**. Exact known ground-truth title phrases appear somewhere in205messages from63titled identities; those may be discussion of somebody else's title and must not be called own signatures.

**Stronger checked lower bound:** `supplement.py` uses four literal name-followed-by-title signature patterns and a matching sender surname: Vincent Kaminski/Managing Director19 analysis messages; Sally Beck/Vice President1; Sally Beck/Chief Operating Officer2; Sue Nord/Sr.Director19. Thus at least41analysis messages fromthese3people contain explicit own-name/title signatures. Full paths and patterns in `literal_signature_counts.json`. Examples include `maildir/kaminski-v/all_documents/11199.` and`5603.`. This is a conservative selected-pattern lower bound, not exhaustive classification, and title wording need not equal the formal-rank label (Kaminski's label mismatch is separately audited).

The detector-negative sample also retains Cheryl Nelson's Senior Counsel title inside a multi-author quoted chain and an8,000-character John&Hengerer memorandum copied under another sender. Clean-sample ID1andID80 are signature-only retained text; such messages are nonempty without substantive contribution. Title prediction could therefore learn identity/rank vocabulary or circulating documents rather than functional importance.

**Fix/tests:** Produce signature-stripped, identity/contact-redacted and quoted-document-redacted ablations. Train/test splits must be person-disjoint (and, for temporal claims, date-disjoint); report a title-keyword-only baseline and name/contact-only baseline. Test masking against a manual own-title sample rather than treating every occurrence of manager/director as leakage. Retain unredacted source for audit, but not as an uncontrolled feature source.

## Major evaluation limitation: independent cleaner agreement is not a gold standard

**Code:** `validate_cleaning.py:25–30,44–69`; `tests/test_clean.py:119–140`. Four residue regexes are format markers, not quoted-span labels; no retention check is included. `negative_controls.py` obtains zero residues from an empty-string cleaner, which still agrees with email_reply_parser on4.22% ofsample5000. A destructive cleaner can therefore win every residue column. `README.md:77–78` and commit`7e8f228` acknowledge adding rules identified from the same cross-check, so the final fixed sample is development data, not a pristine external validation set.

**Fairer check actually run:** both cleaners were compared to full raw bodies on the fresh200cases. Project:7/200 any quote residue (all headers),0/200 confirmed quote prose,1/200 substantive authored deletion. email_reply_parser:80/200any residue,35/200quote prose,1/200substantive authored deletion. One authorship ambiguity inboth. Four email_reply_parser signature/device-footers removals were kept separate, not automatically counted as body-text errors. This suggests relative advantage on the observed detector-positive formats, while the independent detector-negative40 shows both fail a flat-header chain. It does **not** validate a global accuracy rate or prove superiority on all message types. Neither review was blinded/human gold.

**Fix:** replace "less quoted material" with the measured "fewer selected quotation markers" unless supported by held-out annotation. Evaluate blinded span precision/recall or sentence labels for current author, earlier email, boilerplate and signature; stratify by export format and empty outputs. Freeze cleaner rules before final test annotation.

## Minor documentation/test discrepancies

- `README.md:90` says all parameters live in config. Cleaner length limits (80/160/120), date templates, intervening-line limits, disclaimer patterns, and comparison Jaccard >=.9 threshold are hard-coded in `clean.py:20–74`/`validate_cleaning.py:61`.
- `README.md:67–75` and commit`61fdf7b` imply equality is exact text and residue percentages are amounts of quoted material. Equality is whitespace-normalized; residue values are message-level marker hits, not quoted-text proportion or semantic correctness.
- Commit`61ec27c` says remaining Lotus/Outlook formats caught and residual0.0% in an unspecified20,000sample. The historical sample is not reconstructable from this claim alone; fresh cases demonstrate that any exhaustive reading is false. Do not claim its specific historical rounded number was disproved without the exact sample/metric.
- Commits`ba3757b`/`67ebf20` state topic/dialog models will see "only what the sender wrote." The flat-header chain, external memo, and signatures above refute that as a general guarantee.
- Threads' implementation matches its stated heuristic, but the phrasing "response time" (`threads.py:11`) suppresses classification uncertainty; forwards and independent feeds are not responses.
- Existing cleaning fixtures lack real annotated inline/bottom-reply, flat-header, language-varied, and literal Received/date negative cases. Thread tests lack alias, Bcc, generic-subject, self-alert, causal-inversion and quoted-parent gold cases. Comparison tests can pass with a cleaner that deletes genuine text elsewhere. No code/tests were changed.

## Limits

No exhaustive own-signature prevalence or true-reply recall can be established without annotation. Manual labels are fallible single-model judgments, not independently adjudicated expert gold. Source-boundary checks for broad Lotus/transport rules used40examples from saved early archive matches, not a representative full-population sample. Thread source/copy timestamp artifacts need the ingest/dedupe audit to attribute their root cause. The user should not treat any of the sample percentages as unbiased universal correctness metrics.
