from pathlib import Path
import json
import pandas as pd
import pyarrow as pa,pyarrow.compute as pc,pyarrow.parquet as pq
ROOT=Path('/Users/jebfarneth/projects/enron-knowledge-decay');OUT=Path('/tmp/enron-audit-20260925.Xj3qoO/clean_threads')
examples=json.loads((OUT/'thread_alias_bcc.json').read_text())['alias_added_examples']
chosen=[examples[i] for i in [0,6,7,16,19]]
m=pd.read_parquet(ROOT/'data/processed/messages.parquet',columns=['path','sender','to','cc','subject','date'])
records=[]
for ex in chosen:
    child=m[m.path.eq(ex['path'])].iloc[0];parent=m.loc[int(ex['parent'])]
    records.append({'path':child.path,'parent_path':parent.path,'sender':child.sender,'parent_sender':parent.sender,'subject':child.subject,'parent_subject':parent.subject,'date':str(child.date),'parent_date':str(parent.date),'parent_to':parent.to.tolist(),'parent_cc':parent.cc.tolist()})
want=pa.array([r[k] for r in records for k in ['path','parent_path']]);bodies={}
for batch in pq.ParquetFile(ROOT/'data/interim/messages_raw.parquet').iter_batches(batch_size=2000,columns=['path','body']):
    b=batch.filter(pc.is_in(batch.column(0),value_set=want));bodies.update(zip(b.column(0).to_pylist(),b.column(1).to_pylist()))
for r in records:r.update(body=bodies[r['path']],parent_body=bodies[r['parent_path']])
(OUT/'alias_examples.json').write_text(json.dumps(records,indent=2)+'\n')
for i,r in enumerate(records):print(i,r['path'],r['parent_path'],r['sender'],r['parent_to'])
