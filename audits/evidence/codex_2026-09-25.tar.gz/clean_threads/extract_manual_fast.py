from pathlib import Path
import json
import pandas as pd
import pyarrow as pa
import pyarrow.parquet as pq
import pyarrow.compute as pc
from enron_importance.clean import authored_text,reply_start
from email_reply_parser import EmailReplyParser
ROOT=Path('/Users/jebfarneth/projects/enron-knowledge-decay');OUT=Path('/tmp/enron-audit-20260925.Xj3qoO/clean_threads')
columns=['path','sender','subject','date','to','reply_to','has_quoted']
m=pd.read_parquet(ROOT/'data/processed/messages.parquet',columns=columns)
sample=m[m.has_quoted].sample(200,random_state=20260925)
ts=m[m.reply_to.notna()].sample(60,random_state=20260925)
want=set(sample.path)|set(ts.path)|set(m.loc[ts.reply_to.astype(int),'path']);wanted=pa.array(sorted(want))
bodies={};authored={}
for fname,target,col in [('data/processed/messages.parquet',authored,'authored'),('data/interim/messages_raw.parquet',bodies,'body')]:
    for batch in pq.ParquetFile(ROOT/fname).iter_batches(batch_size=2000,columns=['path',col]):
        keep=batch.filter(pc.is_in(batch.column(0),value_set=wanted))
        for p,b in zip(keep.column(0).to_pylist(),keep.column(1).to_pylist()):target[p]=b
records=[]
for ordinal,(i,row) in enumerate(sample.iterrows()):
    b=bodies[row.path];records.append({'sample_id':ordinal,'index':int(i),'path':row.path,'sender':row.sender,'subject':row.subject,'body':b,'authored':authored[row.path],'cut':reply_start(b),'ours':authored_text(b),'theirs':EmailReplyParser.parse_reply(b)})
(OUT/'manual_clean_sample200.json').write_text(json.dumps(records,indent=2,ensure_ascii=False)+'\n')
records=[]
for ordinal,(i,row) in enumerate(ts.iterrows()):
    p=m.loc[int(row.reply_to)];records.append({'sample_id':ordinal,'index':int(i),'parent_index':int(row.reply_to),'path':row.path,'parent_path':p.path,'sender':row.sender,'parent_sender':p.sender,'to':row.to.tolist(),'parent_to':p.to.tolist(),'subject':row.subject,'parent_subject':p.subject,'date':row.date,'parent_date':p.date,'body':bodies[row.path],'parent_body':bodies[p.path],'authored':authored[row.path],'parent_authored':authored[p.path]})
(OUT/'manual_thread_sample60.json').write_text(json.dumps(records,indent=2,ensure_ascii=False,default=str)+'\n')
print('Saved 200 clean samples and 60 thread pairs',flush=True)
