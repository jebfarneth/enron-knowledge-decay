from pathlib import Path
from collections import Counter,defaultdict
import json,re,time
import pandas as pd
import pyarrow.parquet as pq
from enron_importance.dedupe import normalize_subject
from enron_importance.threads import link_replies
from enron_importance.clean import authored_text,reply_start
ROOT=Path('/Users/jebfarneth/projects/enron-knowledge-decay');OUT=Path('/tmp/enron-audit-20260925.Xj3qoO/clean_threads')
def save(name,obj):(OUT/name).write_text(json.dumps(obj,indent=2,default=str,ensure_ascii=False)+'\n')
m=pd.read_parquet(ROOT/'data/processed/messages.parquet')
ids=pd.read_parquet(ROOT/'data/processed/identities.parquet');amap=dict(zip(ids.address,ids.person_key))
linked=m[m.reply_to.notna()];parents=m.loc[linked.reply_to.astype(int)].reset_index(drop=True)
ld=linked.reset_index(drop=True)
selfsender=ld.sender.eq(parents.sender)
norecip=[p not in set(t)|set(c) for p,t,c in zip(parents.sender,ld.to,ld.cc)]
save('thread_structural.json',{'linked':len(ld),'same_sender':int(selfsender.sum()),'parent_sender_not_current_ToCc':sum(norecip),'same_sender_examples':ld[selfsender][['path','sender','subject','reply_to']].head(30).to_dict('records'),'no_reverse_edge_examples':ld[norecip][['path','sender','subject','reply_to']].head(30).to_dict('records')})

# Counterfactual with identities/Bcc only for count; it is not ground-truth recall.
base=m[['sender','to','cc','subject','date']].copy()
alias=base.copy();alias['sender']=alias.sender.map(lambda x:amap.get(x,x));alias['to']=alias.to.map(lambda xs:[amap.get(x,x) for x in xs]);alias['cc']=alias.cc.map(lambda xs:[amap.get(x,x) for x in xs])
t=time.perf_counter();ar=link_replies(alias,14);elapsed=time.perf_counter()-t
new_alias=m.reply_to.isna()&ar.reply_to.notna()
changed=m.reply_to.notna()&ar.reply_to.notna()&m.reply_to.ne(ar.reply_to)
bx=base.copy();bx['cc']=[list(set(c)|set(b)) for c,b in zip(m.cc,m.bcc)]
br=link_replies(bx,14);new_bcc=m.reply_to.isna()&br.reply_to.notna()
save('thread_alias_bcc.json',{'alias_links':int(ar.reply_to.notna().sum()),'alias_added':int(new_alias.sum()),'alias_changed_parent':int(changed.sum()),'bcc_added':int(new_bcc.sum()),'elapsed_seconds_alias':elapsed,'alias_added_examples':m.loc[new_alias,['path','sender','subject','date']].assign(parent=ar.loc[new_alias,'reply_to']).head(30).to_dict('records'),'bcc_added_examples':m.loc[new_bcc,['path','sender','subject','date']].assign(parent=br.loc[new_bcc,'reply_to']).head(30).to_dict('records')})

# Independent exact-text candidate search: normalize whitespace/case; unique 80-character
# authored prefixes (>=12 words) found literally in an unlinked message's quoted portion.
# Does not establish an immediate reply; human review is mandatory.
norm=lambda s:re.sub(r'\s+',' ',s).strip().lower()
prefix=defaultdict(list)
for i,text in m.authored.items():
    s=norm(text)
    if len(s)>=80 and len(s.split())>=12:prefix[s[:80]].append(i)
prefix={p:ii[0] for p,ii in prefix.items() if len(ii)==1}
unlinked=m[m.reply_to.isna()&m.has_quoted].sample(300,random_state=20260926)
candidate_paths=set(unlinked.path);bodies={}
for batch in pq.ParquetFile(ROOT/'data/interim/messages_raw.parquet').iter_batches(batch_size=5000,columns=['path','body']):
    for p,b in zip(batch.column(0).to_pylist(),batch.column(1).to_pylist()):
        if p in candidate_paths:bodies[p]=b
matched=[]
for i,row in unlinked.iterrows():
    b=bodies[row.path];q=norm(b[reply_start(b):]);found=set()
    for pos in range(max(0,len(q)-79)):
        pi=prefix.get(q[pos:pos+80])
        if pi is not None and pi!=i:found.add(pi)
    for pi in sorted(found):
        p=m.loc[pi]
        if p.date>=row.date:continue
        dt=(row.date-p.date).total_seconds()/86400
        same=normalize_subject(row.subject)==normalize_subject(p.subject)
        recipient=row.sender in set(p.to)|set(p.cc)
        aliasrecipient=amap.get(row.sender,row.sender) in {amap.get(x,x) for x in set(p.to)|set(p.cc)}
        matched.append({'index':int(i),'parent_index':int(pi),'path':row.path,'parent_path':p.path,'sender':row.sender,'parent_sender':p.sender,'subject':row.subject,'parent_subject':p.subject,'days':dt,'same_subject':same,'raw_recipient':recipient,'alias_recipient':aliasrecipient,'bcc_recipient':row.sender in set(p.bcc),'body':b,'parent_authored':p.authored})
save('unlinked_quoted_candidate_pairs.json',matched)
save('unlinked_quoted_summary.json',{'sample':len(unlinked),'unlinked_quoted_population':int((m.reply_to.isna()&m.has_quoted).sum()),'unique_prefixes':len(prefix),'candidate_pairs':len(matched),'candidate_messages':len({x['index'] for x in matched}),'same_subject':sum(x['same_subject'] for x in matched),'different_subject':sum(not x['same_subject'] for x in matched),'alias_recipient_only':sum(x['alias_recipient'] and not x['raw_recipient'] for x in matched),'bcc_recipient_only':sum(x['bcc_recipient'] and not x['raw_recipient'] for x in matched),'empty_subject':sum(normalize_subject(x['subject'])=='' for x in matched)})
print((OUT/'thread_alias_bcc.json').read_text());print((OUT/'unlinked_quoted_summary.json').read_text())
