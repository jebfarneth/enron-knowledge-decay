from pathlib import Path
import json,re
import pandas as pd
import pyarrow as pa,pyarrow.parquet as pq,pyarrow.compute as pc
from enron_importance.clean import authored_text
from email_reply_parser import EmailReplyParser
ROOT=Path('/Users/jebfarneth/projects/enron-knowledge-decay');OUT=Path('/tmp/enron-audit-20260925.Xj3qoO/clean_threads')
m=pd.read_parquet(ROOT/'data/processed/messages.parquet',columns=['path','sender','subject','authored','has_quoted','sender_internal','sender_automated','routine'])
analysis=m.sender_internal & ~m.sender_automated & ~m.routine & m.authored.ne('')
s=m[analysis&~m.has_quoted].sample(40,random_state=20260927)
want=pa.array(s.path.tolist());bodies={}
for batch in pq.ParquetFile(ROOT/'data/interim/messages_raw.parquet').iter_batches(batch_size=2000,columns=['path','body']):
    q=batch.filter(pc.is_in(batch.column(0),value_set=want))
    bodies.update(zip(q.column(0).to_pylist(),q.column(1).to_pylist()))
r=[{'sample_id':j,'index':int(i),'path':x.path,'sender':x.sender,'subject':x.subject,'body':bodies[x.path],'authored':x.authored,'theirs':EmailReplyParser.parse_reply(bodies[x.path])} for j,(i,x) in enumerate(s.iterrows())]
(OUT/'unflagged_sample40.json').write_text(json.dumps(r,indent=2,ensure_ascii=False)+'\n')
patterns={
 'vincent_kaminski_managing_director':re.compile(r'Vincent\s+(?:J\.?\s+)?Kaminski\s*\nManaging Director',re.I),
 'sally_beck_vice_president':re.compile(r'Sally\s+Beck\s*\nVice President',re.I),
 'sally_beck_chief_operating_officer':re.compile(r'Sally\s+Beck\s*\nChief Operating Officer',re.I),
 'sue_nord_senior_director':re.compile(r'Sue Nord,?\s+Sr\.? Director',re.I),
}
result={}
for name,pat in patterns.items():
    flag=m.authored.map(lambda x:bool(pat.search(x)))
    # Literal observed signatures combined with matching sender surname, not arbitrary title hits.
    surname='kaminski' if name.startswith('vincent') else ('beck' if name.startswith('sally') else 'nord')
    own=flag&m.sender.str.contains(surname,case=False,na=False,regex=False)
    result[name]={'all_matches':int(flag.sum()),'matching_sender_signature_messages':int(own.sum()),'analysis_matching_sender_signature_messages':int((own&analysis).sum()),'paths':m.loc[own,'path'].tolist()}
(OUT/'literal_signature_counts.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'unflagged_population':int((analysis&~m.has_quoted).sum()),'sample':40,'signatures':{k:{a:b for a,b in v.items() if a!='paths'} for k,v in result.items()}},indent=2))
