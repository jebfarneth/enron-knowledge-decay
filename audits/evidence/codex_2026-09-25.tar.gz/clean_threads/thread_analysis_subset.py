from pathlib import Path
from collections import Counter
import json
import pyarrow.parquet as pq

ROOT=Path('/Users/jebfarneth/projects/enron-knowledge-decay')
OUT=Path('/tmp/enron-audit-20260925.Xj3qoO/clean_threads')
labels=json.loads((OUT/'manual_thread_labels60.json').read_text())['labels']
by_path={r['path']:r for r in labels}
count=0;included=[]
cols=['path','sender_internal','sender_automated','routine','authored','reply_to']
for batch in pq.ParquetFile(ROOT/'data/processed/messages.parquet').iter_batches(batch_size=2000,columns=cols):
    d=batch.to_pydict()
    for p,internal,automatic,routine,authored,parent in zip(*(d[k] for k in cols)):
        analysis=internal and not automatic and not routine and authored!=''
        if analysis and parent is not None:count+=1
        if analysis and p in by_path:included.append(by_path[p])
result={'population_analysis_links':count,'sample_analysis_messages':len(included),'classes':dict(Counter(x['classification'] for x in included)),'included_ids':sorted(x['sample_id'] for x in included),'note':'Analysis mask is identical to prepare.py; this is a nested subset of the original60 linked-edge sample, not a newly independent sample.'}
(OUT/'manual_thread_analysis_subset.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
