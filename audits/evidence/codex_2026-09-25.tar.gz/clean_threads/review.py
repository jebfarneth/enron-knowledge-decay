import json,sys
from pathlib import Path
out=Path('/tmp/enron-audit-20260925.Xj3qoO/clean_threads')
mode=sys.argv[1];start=int(sys.argv[2]);end=int(sys.argv[3])
name={'clean':'manual_clean_sample200.json','thread':'manual_thread_sample60.json','marker':'marker_diagnostics.json','title':'title_leakage_candidates.json','miss':'unlinked_quoted_candidate_pairs.json'}[mode]
x=json.loads((out/name).read_text())
if mode=='marker':x=x['examples'][sys.argv[4]]
def excerpt(s,n=1400):
    return s if len(s)<=n else s[:int(n*.7)]+f'\n[...{len(s)-n} characters omitted...]\n'+s[-int(n*.3):]
for row in x[start:end]:
    if mode=='clean':
        print('\nID',row['sample_id'],row['path'],row['sender'],row['subject'])
        print('AUTHORED:',excerpt(row['authored'],1000))
        print('REMOVED HEADER/TAIL:',excerpt(row['body'][row['cut']:] if row['cut']<len(row['body']) else row['body'],1300))
        print('ERP:',excerpt(row['theirs'],200))
    elif mode=='thread':
        print('\nID',row['sample_id'],row['path'],'<=',row['parent_path'])
        print(row['sender'],row['to'],row['subject'],row['date'],'PARENT',row['parent_sender'],row['parent_subject'],row['parent_date'])
        print('CHILD:',excerpt(row['body'],1500));print('PARENT:',excerpt(row['parent_body'],1100))
    else: print(json.dumps(row,ensure_ascii=False,indent=2))
