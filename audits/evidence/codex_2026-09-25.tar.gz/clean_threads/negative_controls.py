import json
from pathlib import Path
from enron_importance.clean import authored_text
from enron_importance.validate_cleaning import RESIDUE,compare,summary
import pandas as pd
OUT=Path('/tmp/enron-audit-20260925.Xj3qoO/clean_threads')
cases={
 'bottom_post':'-----Original Message-----\nFrom: Ann\nSent: Monday\nTo: Bob\nSubject: Budget\nShould we approve?\n\nYes, approve the budget.\nBob',
 'literal_received':'Delivery log:\nReceived: from supplier, 20 barrels.\nCount verified by warehouse.',
 'literal_agenda':'Meeting agenda\n05/14/2001 09:00 AM\nTo: operations staff\nDiscuss warehouse budget.',
 'inline_reply':'My responses below.\n-----Original Message-----\nFrom: Ann\nSent: Monday\n> First proposal?\nAgreed.\n> Second proposal?\nRejected.',
}
result={'synthetic_counterexamples':{k:{'input':v,'cleaned':authored_text(v)} for k,v in cases.items()},'empty_cleaner_residue':{n:bool(p.search('')) for n,p in RESIDUE.items()}}
if (OUT/'crosscheck_rows.csv').exists():
    f=pd.read_csv(OUT/'crosscheck_rows.csv').fillna('')
    result['empty_cleaner_agreement_with_ERP']=float(f.theirs.map(lambda x:not str(x).strip()).mean())
    result['crosscheck_exact_file_equality']=(OUT/'crosscheck.json').read_bytes()==(OUT/'crosscheck_repeat.json').read_bytes()
(OUT/'negative_controls.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
