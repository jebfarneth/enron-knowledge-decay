"""Serialize manual Codex review labels; no automatic accuracy judgments.

Review material: manual_clean_sample200.json, manual_thread_sample60.json,
unflagged_sample40.json. Every raw/authored cleaner pair was read in full;
thread pairs were read to establish immediate-parent evidence (not every long
article/newsletter appendix was read). Two agents split cleaner IDs 0–99 and
100–199: this is NOT a human gold set or inter-rater reliability study.
"""
from pathlib import Path
import json,random
from collections import Counter

OUT=Path('/tmp/enron-audit-20260925.Xj3qoO/clean_threads')
OTHER=OUT.parent/'identity_rank'
def read(name): return json.loads((OUT/name).read_text())
def save(name, value): (OUT/name).write_text(json.dumps(value,indent=2,ensure_ascii=False)+'\n')
rows=read('manual_clean_sample200.json')
ours_bad={20:'Quoted Aimee Lannou name/date line remains after Daren response.',82:'Spanish Mensaje original/De/Para/Fecha/Asunto header remains; angle-quoted prose removed.'}
erp_bad={0,3,9,14,16,17,20,21,24,27,28,29,31,33,34,37,38,41,44,45,46,53,56,57,58,64,66,68,70,72,73,75,77,80,83,84,90,91,95,99}
erp_prose={0,3,14,16,17,21,27,29,31,37,38,41,44,46,56,66,68,73,75,80,84,99}
first=[]; parser=[]
for r in rows[:100]:
    i=r['sample_id']
    evidence=ours_bad.get(i,'No retained quotation or deleted substantive current-author prose observed in full raw/authored review.')
    if i==49:evidence='Original Message at start causes both cleaners to remove Sara Shackleton inline answers, marked [Shackleton, Sara], including not yet and statement about engaging bankruptcy lawyers.'
    if i==43:evidence='Current top table repeats seven rows from quoted message and adds four rows; source authorship ambiguous, not counted as a definite cleaning failure.'
    base={'sample_id':i,'path':r['path'],'reviewed_full_raw_and_authored':True,'quoted_residue':i in ours_bad,'quoted_prose_residue':False,'genuine_authored_false_cut':i==49,'ambiguous':i==43,'evidence':evidence}
    first.append(base)
    p=base.copy();p.update(quoted_residue=i in erp_bad,quoted_prose_residue=i in erp_prose,signature_or_device_footer_removed=i in {10,69})
    if i in erp_bad:p['evidence']='Retained quoted header/prose identified by comparison with the full raw source; see sample JSON.'
    elif i not in {43,49}:p['evidence']='No retained quotation or substantive current-author prose deletion observed; signature/device-footer stripping classified separately.'
    parser.append(p)
save('manual_clean_labels0_99.json',first);save('manual_parser_labels0_99.json',parser)
second=json.loads((OTHER/'manual_clean_labels100_199.json').read_text())['labels']
secondp=json.loads((OTHER/'manual_parser_labels100_199.json').read_text())['labels']
def count(label): return {key:sum(bool(r.get(key)) for r in label) for key in ['quoted_residue','quoted_prose_residue','genuine_authored_false_cut','ambiguous','signature_or_device_footer_removed']}
combined={'review_type':'Manual Codex audit review; two non-overlapping partitions, not human gold or inter-rater agreement.','sample_seed':20260925,'denominator':200,'frame':'112277 has_quoted-positive deduplicated messages; detector-defined sampling frame, not global recall.','ours':count(first+second),'email_reply_parser':count(parser+secondp),'ours_labels':first+second,'parser_labels':parser+secondp}
save('manual_clean_combined.json',combined)

classes={
 'direct_reply':[0,1,3,7,9,10,12,15,17,18,22,23,26,27,28,30,31,35,37,38,43,45,47,50,53,57,58],
 'forward_or_relay_not_reply':[4,14,19,33,39,46,48,54,55,56],
 'wrong_immediate_parent':[5,6,11,13,25,36,40,41,42,51,52,59],
 'independent_broadcast_or_unrelated_topic':[2,24,29,44],
 'same_author_related_update_not_reply':[49],
 'uncertain_direct_parent':[8,16,20,21,32,34],
}
notes={
0:'Child quotes Jerry/Lon parent exact topic/time.',1:'Child quotes Conway/Ruscitti parent.',2:'Independent self-addressed Schedule Crawler hourly failures, hour19 linked to hour18.',3:'Quote of Williams/Kaminski parent.',4:'Explicit forward to third party, not a reply to Carlos.',5:'Child forwards own 07:48 response; selected parent is McCall 07:44, a grandparent.',6:'Child quotes clbywaters1@aep.com June7; selected parent is older Candace.enron May31 mineral-rights exchange.',7:'Quoted Fred parent.',8:'Julie status update about receiving accomplishments; selected Joe accomplishment message possibly relevant but immediate reply unknown.',9:'Quoted Roeline parent.',10:'Reply conveys requested planning answer to another participant, quoting selected Dennis request.',11:'Answers Jacqueline Kelly 14:03 via external Jeff alias; selects Kimberly Kupiecki 10:16 instead.',12:'Quoted Lamar/Steffes parent.',13:'Quotes Bryan Hull Dec21 14:01 response; selects Matthew Lenhart Dec20 instead under Happy Hour.',14:'Pure forward of Wendi parent.',15:'Price-lock question responds to selected supplier-price details.',16:'Child quotes original GE guarantee request at07:17/08:18; selected parent07:19 is a resend; conversation correct but exact parent ambiguous.',17:'Quoted Lucy cancellation parent.',18:'Quoted ONeal parent.',19:'Explicit forward of Robert to Valerie with current commentary; source matches but not a direct reply.',20:'Scheduling availability follows same-topic group email; no quoted parent, cannot establish immediate link.',21:'Short remark to Susan Mara linked to Ginger five-day-old conference notice; insufficient immediate-reply evidence.',22:'Quotes Jeff Jan18 parent.',23:'Quotes Nancy Herring parent.',24:'Independent self-addressed Enron Mentions daily news digests March28 and March23.',25:'Forwards Bob Joyce May15 update; selected parent is May7 update.',26:'Direct follow-up about briefing, quoting selected Jim parent.',27:'Direct reminder to Frank, quoting selected parent.',28:'Quotes selected Andy Katz December5 17:35 parent.',29:'Two self-addressed copies of travel-services broadcast minutes apart; not a conversational reply.',30:'Quotes Tracy international-number question.',31:'Quotes Kathleen invitation.',32:'Child addresses medschul@cvtv.net while selected parent is jwong@bcgas.com; no quote, likely generic-subject collision but conservatively uncertain.',33:'Pure forward of Tana parent.',34:'Group rescheduling announcement after Jeff response; same event but not established immediate reply.',35:'AGA and flying response answers parent questions.',36:'Selected parent already quotes the whole child; duplicate/date rendering inverts causal order.',37:'Quotes Gerald location question.',38:'Quotes Jim SCE meeting message.',39:'Forwards Kevin decision to Paula; same source, not reply to Kevin.',40:'Child quotes Dennis07:42 cake advice; selected Dennis00:13 different recipe advice.',41:'Answers Andrea13:25; selected parent Deborah11:57 seminar broadcast is a grandparent.',42:'Answers Carolyn April30; selected Carolyn April24 documents are six days earlier.',43:'Quotes selected Tana assignment question.',44:'Child asks about Carolina/Florida netting; selected parent asks about Dreyfuss/Richardson/Navajo/Unocal. Different counterparties, generic Netting Agreement.',45:'Quotes Kevin office-space response.',46:'Forwards Jim pipeline analysis to Steve.',47:'Quotes Diane response.',48:'FYI forward of Jeanette audit message.',49:'Kay self-authored QBR date revision; related update, not reply to another person.',50:'Thanks responds to Scott press-conference documents message.',51:'Quotes Chris10:11 as immediate source; selected Joan09:21 is grandparent.',52:'Selected Vince response already quotes the whole child; original message appears after reply by stored timestamp.',53:'Quotes Jacquelyn mistaken recipient message.',54:'FYI forward of Jim Delani response.',55:'Pure forward of Sean forwarded Dave message.',56:'Forwards David Harvin legal analysis.',57:'Quotes Phillip response.',58:'Quotes Pat request.',59:'Forwards Bob Shults request; selected parent is David Forster response, not quoted source.'}
by_id={i:k for k,ii in classes.items() for i in ii}
assert set(by_id)==set(range(60)) and sum(map(len,classes.values()))==60
tr=[]
for r in read('manual_thread_sample60.json'):
    i=r['sample_id'];tr.append({'sample_id':i,'path':r['path'],'parent_path':r['parent_path'],'classification':by_id[i],'evidence':notes[i]})
save('manual_thread_labels60.json',{'review_type':'Manual Codex audit; not human gold. Random linked-edge sample, no recall estimate.','sample_seed':20260925,'population_links':47130,'denominator':60,'class_counts':{k:len(v) for k,v in classes.items()},'direct_reply_fraction':27/60,'direct_reply_fraction_if_all_uncertain_valid':33/60,'labels':tr})

negative=[]
for r in read('unflagged_sample40.json'):
    i=r['sample_id'];negative.append({'sample_id':i,'path':r['path'],'reviewed_full_raw_and_authored':True,'quoted_email_prose_retained_both_cleaners':i==1,'copied_non_email_source_text':i in {4,24},'genuine_authored_false_cut':False,'note':'Single-line Lotus headers and multi-author chain entirely retained.' if i==1 else ('Explicit contract/third-party memorandum excerpts remain; distinguish copied source from email quoting.' if i in {4,24} else 'No quote residue or substantive cut observed.')})
save('manual_unflagged_labels40.json',{'review_type':'Manual Codex audit; not human gold.','sample_seed':20260927,'denominator':40,'population':88186,'frame':'Internal, nonautomated, nonroutine, nonempty authored analysis messages with has_quoted=False.','quoted_email_prose_retained_both_cleaners':1,'copied_non_email_source_text_messages':2,'genuine_authored_false_cuts':0,'labels':negative})
marker=read('marker_diagnostics.json');rng=random.Random(20260925);marker_review=[]
for k in ['3','8']:
    for r in rng.sample(marker['examples'][k],20):
        marker_review.append({'marker_index':int(k),'path':r['path'],'boundary_offset':r['cut'],'before':r['before'],'after':r['after'],'confirmed_natural_false_boundary':False,'review_scope':'Boundary context only; 20 random examples from first250 archive-order earliest-hit examples per pattern. Zero confirmed is not proof of correctness or a population error rate.'})
save('manual_marker_boundaries40.json',marker_review)
candidate_file=OUT/'unlinked_quoted_candidate_pairs.json'
if candidate_file.exists():
    candidates=read('unlinked_quoted_candidate_pairs.json')
    checked={14:('confirmed_missed_direct_reply_alias','Kevin Presto thanks Vince and quotes the immediate parent; presto@ differs from recorded recipient alias.'),42:('confirmed_missed_direct_reply_empty_subject','Mike Maggi directly responds to quoted Michelle Nelson10:17; normalized subject empty.'),60:('confirmed_missed_direct_reply_empty_subject','John Arnold asks a follow-up to quoted David Forster trading simulation design; normalized subject empty.'),71:('confirmed_missed_direct_reply_empty_subject','Rogers Herndon thanks Richard for summary and quotes it; normalized subject empty.'),63:('false_alias_equivalence','Mark E Taylor asks to remove Mark A Taylor and add himself, explicitly demonstrating different identities. Candidate points to broadcast sent to wrong Mark.'),33:('same_conversation_ancestor_changed_subject','Jeff forwards a chain containing older empty-subject Harry Kingerski message; direct parent is Mary Hain, not this ancestor.'),27:('same_conversation_ancestor_changed_subject','Jeff Brown proposes a new idea while quoting Cindy/Stan commentary and older GISB source; matched source is ancestor, not direct parent.'),51:('self_update_changed_subject','Joe Errigo repeats own vacation request with changed subject; valid topic continuity, not interpersonal reply.'),36:('forward_outside_window','Steve Kean forwards the exact Terry West source46days later; not a reply.'),67:('forward_outside_window','Elizabeth Sager forwards the exact Shari Stack source26days later; not a reply.')}
    save('manual_missed_link_examples.json',[{'pair_id':i,'path':candidates[i]['path'],'parent_path':candidates[i]['parent_path'],'classification':v[0],'evidence':v[1]} for i,v in checked.items()])
print(json.dumps({'clean':{k:v for k,v in combined.items() if not k.endswith('labels')},'thread':{k:len(v)for k,v in classes.items()}},indent=2))
