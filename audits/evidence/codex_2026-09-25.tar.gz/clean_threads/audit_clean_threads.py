from pathlib import Path
import json,re,hashlib,sys
from collections import Counter,defaultdict
import pandas as pd
import pyarrow.parquet as pq
from enron_importance.clean import authored_text,reply_start,_MARKERS
from enron_importance.validate_cleaning import compare,summary
from enron_importance.dedupe import normalize_subject

ROOT=Path('/Users/jebfarneth/projects/enron-knowledge-decay')
OUT=Path('/tmp/enron-audit-20260925.Xj3qoO/clean_threads')
SEED=20260925
def save(name,value):
    (OUT/name).write_text(json.dumps(value,indent=2,ensure_ascii=False,default=str)+'\n')

m=pd.read_parquet(ROOT/'data/processed/messages.parquet')
ids=pd.read_parquet(ROOT/'data/processed/identities.parquet')
rank=pd.read_parquet(ROOT/'data/processed/formal_rank.parquet')
amap=dict(zip(ids.address,ids.person_key))
m['person']=m.sender.map(amap).fillna(m.sender)
m['normalized_subject']=m.subject.map(normalize_subject)
analysis=m.sender_internal & ~m.sender_automated & ~m.routine & m.authored.ne('')
sample=m[m.has_quoted].sample(200,random_state=SEED)
threadsample=m[m.reply_to.notna()].sample(60,random_state=SEED)
paths=pq.read_table(ROOT/'data/interim/messages_raw.parquet',columns=['path']).to_pandas()
crosspaths=paths[paths.path.isin(set(m.path))].sample(5000,random_state=42)
want=set(sample.path)|set(threadsample.path)|set(m.loc[threadsample.reply_to.astype(int),'path'])|set(crosspaths.path)
by_path=m.set_index('path')
bodies={}
marker_counts=Counter();marker_examples=defaultdict(list);unique_marker_counts=Counter()
sender_title_examples=[]
title_regex=re.compile(r'(?i)\b(?:vice[- ]president|president|chief executive officer|CEO|managing director|director|manager|trader|in[- ]house lawyer)\b')
title_exact=Counter(); title_any=Counter(); title_tail=Counter(); title_people=defaultdict(set)
rank_titles=rank[rank.level.notna()].groupby('person_key').title.apply(list).to_dict()
for i,row in m.iterrows():
    if not analysis[i]:continue
    text=row.authored
    if title_regex.search(text):title_any['messages']+=1;title_people['any'].add(row.person)
    if title_regex.search('\n'.join(text.splitlines()[-8:])):title_tail['messages']+=1;title_people['tail'].add(row.person)
    for title in rank_titles.get(row.person,[]):
        if re.search(r'(?i)\b'+re.escape(title)+r'\b',text):
            title_exact['messages']+=1;title_people['exact'].add(row.person)
            if len(sender_title_examples)<100:sender_title_examples.append({'index':i,'path':row.path,'person':row.person,'title':title,'tail':text[-800:]})
            break
    
kept=set(m.path)
for batch in pq.ParquetFile(ROOT/'data/interim/messages_raw.parquet').iter_batches(batch_size=5000,columns=['path','body']):
    for path,body in zip(batch.column(0).to_pylist(),batch.column(1).to_pylist()):
        if path not in kept:continue
        if path in want:bodies[path]=body
        hits=[(j,pat.search(body)) for j,pat in enumerate(_MARKERS)]
        hits=[(j,x) for j,x in hits if x is not None]
        if hits:
            cut=min(x.start() for _,x in hits)
            for j,hit in hits:
                marker_counts[j]+=1
                if hit.start()==cut:
                    unique_marker_counts[j]+=1
                    if j in (3,8) and len(marker_examples[j])<250:
                        marker_examples[j].append({'path':path,'cut':cut,'before':body[max(0,cut-500):cut],'after':body[cut:cut+1700], 'authored':authored_text(body)})

cross=compare(pd.Series([bodies[p] for p in crosspaths.path]))
save('crosscheck.json',summary(cross))
cross2=compare(pd.Series([bodies[p] for p in crosspaths.path]))
save('crosscheck_repeat.json',summary(cross2))
cross.assign(path=crosspaths.path.to_numpy()).to_csv(OUT/'crosscheck_rows.csv',index=False)
records=[]
for ordinal,(i,row) in enumerate(sample.iterrows()):
    body=bodies[row.path];cut=reply_start(body)
    records.append({'sample_id':ordinal,'index':int(i),'path':row.path,'sender':row.sender,'subject':row.subject,'body':body,'authored':row.authored,'cut':cut,'ours':authored_text(body),'theirs':__import__('email_reply_parser').EmailReplyParser.parse_reply(body)})
save('manual_clean_sample200.json',records)
threads=[]
for ordinal,(i,row) in enumerate(threadsample.iterrows()):
    p=m.loc[int(row.reply_to)]
    threads.append({'sample_id':ordinal,'index':int(i),'parent_index':int(row.reply_to),'path':row.path,'parent_path':p.path,'sender':row.sender,'parent_sender':p.sender,'to':row.to.tolist(),'parent_to':p.to.tolist(),'subject':row.subject,'parent_subject':p.subject,'date':row.date,'parent_date':p.date,'body':bodies[row.path],'parent_body':bodies[p.path],'authored':row.authored,'parent_authored':p.authored})
save('manual_thread_sample60.json',threads)
save('marker_diagnostics.json',{'matches':dict(marker_counts),'earliest':dict(unique_marker_counts),'examples':dict(marker_examples)})
save('title_leakage_candidates.json',sender_title_examples)
groups=m.groupby('normalized_subject').agg(messages=('path','size'),links=('reply_to',lambda x:int(x.notna().sum())),quoted=('has_quoted','sum')).sort_values('messages',ascending=False)
groups.head(30).to_csv(OUT/'largest_subject_groups.csv')
save('overview.json',{'sample_seed':SEED,'quoted_messages':int(m.has_quoted.sum()),'analysis_messages':int(analysis.sum()),'analysis_people':int(m.loc[analysis,'person'].nunique()),'title_any_messages':title_any['messages'],'title_any_people':len(title_people['any']),'title_last8lines_messages':title_tail['messages'],'title_last8lines_people':len(title_people['tail']),'own_title_anywhere_messages':title_exact['messages'],'own_title_anywhere_people':len(title_people['exact']),'titled_analysis_messages':int((analysis&m.person.isin(rank_titles)).sum()),'titled_analysis_people':int(m.loc[analysis&m.person.isin(rank_titles),'person'].nunique()),'empty_subject_messages':int(m.normalized_subject.eq('').sum()),'empty_subject_quoted':int((m.normalized_subject.eq('')&m.has_quoted).sum()),'linked_total':int(m.reply_to.notna().sum()),'threads':int(m.thread_id.nunique())})
print((OUT/'overview.json').read_text());print((OUT/'crosscheck.json').read_text())
