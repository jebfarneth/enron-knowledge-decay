from pathlib import Path
import json, shutil, time, hashlib
from enron_importance.config import load_config
from enron_importance.prepare import prepare
S=Path('/tmp/enron-reaudit-20260925.WVW9gE')
c=load_config(); orig=c['paths'].copy()
for k in ['interim','processed','results','figures']:
    c['paths'][k]=S/'prepare_run'/k;c['paths'][k].mkdir(parents=True,exist_ok=True)
for name in ['messages_raw.parquet','messages_raw.json']:
    shutil.copy2(orig['interim']/name,c['paths']['interim']/name)
t=time.time();m=prepare(c)
original=json.loads((orig['processed']/'funnel.json').read_text())
result={'elapsed_seconds':time.time()-t,'funnel':m['funnel'],'original_funnel':original['funnel'],
        'funnel_equal':m['funnel']==original['funnel'],'outputs':m['outputs'],
        'output_hashes_equal':m['outputs']==original['outputs'],'manifest':m}
(S/'prepare_reproduction.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2),flush=True)
