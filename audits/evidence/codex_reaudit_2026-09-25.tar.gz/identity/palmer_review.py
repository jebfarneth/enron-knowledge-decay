from pathlib import Path
import json,re
rows=json.loads(Path('/tmp/enron-reaudit-20260925.WVW9gE/identity/target_bodies.json').read_text())
for r in rows:
    if r['sender']=='mark.palmer@enron.com':
        print('\n',r['path'],r['x_from'],repr(r['authored'][:2400]))
        for match in re.finditer(r'mark\s+[as][.\s]+palmer|palmer,?\s+mark\s+[as]\b',r['authored'],re.I):
            print('BODY_INITIAL',repr(r['authored'][max(0,match.start()-200):match.end()+200]))
