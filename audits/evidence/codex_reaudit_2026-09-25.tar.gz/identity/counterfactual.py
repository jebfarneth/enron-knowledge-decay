from pathlib import Path
from collections import defaultdict
import pandas as pd
from enron_importance.evaluate import label_table,pairwise_accuracy,different_level_pairs
P=Path('/Users/jebfarneth/projects/enron-knowledge-decay/data/processed')
edges=pd.read_parquet(P/'edges.parquet'); ranks=pd.read_parquet(P/'formal_rank.parquet')
labels=label_table(ranks)
def degrees(merges):
    adj=defaultdict(set)
    for s,t in edges[['source','target']].itertuples(index=False):
        s=merges.get(s,s);t=merges.get(t,t)
        if s!=t:adj[s].add(t);adj[t].add(s)
    return pd.Series({k:len(v) for k,v in adj.items()})
original=degrees({})
for merges in [{'mark davis':'dana davis'},{'global wasaff':'george wasaff'},{'director voice operations trading technology robert knight':'robert knight'}]:
    updated=degrees(merges)
    lab=labels.copy();lab.person_key=lab.person_key.map(lambda k:merges.get(k,k))
    before=original.reindex(labels.person_key,fill_value=0).to_numpy()
    after=updated.reindex(lab.person_key,fill_value=0).to_numpy()
    print('MERGE',merges)
    print('degrees', {k:original.get(k,0) for k in set(merges)|set(merges.values())},'new', {k:updated.get(k,0) for k in set(merges.values())})
    print('accuracy_before',pairwise_accuracy(labels.level.to_numpy(),before),'after',pairwise_accuracy(lab.level.to_numpy(),after),'pairs',different_level_pairs(lab.level.to_numpy()))
    print('labelled_changed',[(p,int(b),int(a)) for p,b,a in zip(labels.person_key,before,after) if b!=a])
