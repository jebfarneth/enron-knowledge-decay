# Bounded deduplication/recipient follow-up

Scope: reviewed the three selected disjoint-recipient split pairs and four selected residual recipient-loss groups against raw archive headers extracted by the root audit. This is a purposive diagnostic sample, not an estimated population error rate.

## Reproduce

From `/Users/jebfarneth/projects/enron-knowledge-decay`:

```sh
.venv/bin/python /tmp/enron-reaudit-20260925.WVW9gE/identity/dedupe_review.py > /tmp/enron-reaudit-20260925.WVW9gE/identity/dedupe_review.txt
```

The script reads current `data/processed/identities.parquet`, applies the committed `identity.resolve_recipient`, prints all residual candidate groups, and displays selected raw headers. Raw-header extraction is reproducible with `/tmp/enron-reaudit-20260925.WVW9gE/dedupe_followup.py`; its output is `dedupe_headers.json`. Root's full-corpus counting probe and output are `dedupe_probe.py` and `dedupe_probe.log` in the same scratch directory.

Relevant implementation: `dedupe.py:78–101` compares raw normalized To/Cc address sets without identity reconciliation; `dedupe.py:110–126` retains only the folder-priority copy's fields. `identity.py:226–236` resolves recipients from a sender-derived modal address table, falling back to restricted first.last guessing; it does not use the recipient's X-To name/CN on that message.

## 1. The 233 additional rows are not 233 verified distinct sends

Root reproduced 233 extra retained sends in 194 content groups. Its current-resolver comparison finds zero overlapping resolved sets among split pairs, but the resolver does not recognize several aliases/export renderings. Three inspected pairs demonstrate this limitation:

| Selected pair | Raw header evidence | Assessment |
|---|---|---|
| `kaminski-v/discussion_threads/8129.` / `kaminski-v/notes_inbox/55.` | Same `info@panalytix.com` sender, timestamp 2000-12-13 10:49:00 PST and Panalytix release subject; recipients `vince.j.kaminski@enron.com` / `vkamins@enron.com`. Current resolver leaves both as separate address nodes. Earlier signature probe `kaminski-v/all_documents/11199.` identifies Vincent Kaminski with the latter address. | Same actual recipient, not demonstrated disjoint people. A newsletter may genuinely have been sent to two subscriptions, so distinct physical sends cannot be ruled out. |
| `linder-e/all_documents/814.` / `linder-e/notes_inbox/131.` | Same Alexandra Cameron sender and 2001-04-26 08:11:00 PDT timestamp, subject differing only in capitalization; To/X-To `eric.linder@enron.com` / `eric_linder@enron.com`. Current resolver maps only the first to Eric Linder. | Alias/rendering alternative is plausible; sending separately to two guessed addresses is also possible. Not proof of two independent people or proof of duplicate physical delivery. |
| `skilling-j/deleted_items/426.` / `skilling-j/inbox/420.` | Same external sender, 2001-06-05 07:50:16 PDT timestamp and `YPO Navy Fly Away` subject. X-To is `Jeff Skilling <jskilli@enron.com>` in one and `skilli@enron.com <j>` in the other. Both remain unresolved separate address nodes. | Strong evidence of a malformed recipient rendering: the leading `j` appears displaced into angle brackets. These rows should not be presented as verified distinct sends. Generated JavaMail IDs do not prove physical delivery identity. |

These three senders are external, so these specific examples do not enter the internal-sender network/analysis. They affect the interpretation of the unique-message funnel and potentially reply context. Do not claim all 233 rows are false duplicates or all three pairs are proven same SMTP transactions. The response should call the result a heuristic split count, disclose ambiguity, and validate/address aliases before interpreting it as distinct sends.

## 2. A confirmed remaining loss of a distinct named recipient

Keeper `maildir/haedicke-m/california/3.` and discarded copy `maildir/williams-w3/bill_williams_iii/874.` share sender Ray Alvarez, timestamp 2001-06-21 13:34:18 PDT, and subject `Briefing Paper- FERC's June 19 West-Wide Price Mitigation Order`.

Both raw X-To headers explicitly contain these separate entries:

> Carla Hoffman/PDX/ECT@ECT, Calger, Christopher F. … CN=CCALGER

The keeper's To contains `f..carla@enron.com` but no Calger address. The discarded copy's To contains `f..calger@enron.com`. Current resolver outputs:

```text
f..carla@enron.com => f..carla@enron.com
f..calger@enron.com => christopher calger
carla.hoffman@enron.com => carla hoffman
```

Thus this is not just two aliases of one recipient counted twice: the source names Carla Hoffman and Christopher Calger separately, and the retained message loses Calger's attribution. This demonstrates message-level network information loss; it does not establish that the aggregate Ray Alvarez→Christopher Calger edge is absent, because other messages may contribute that edge.

The full probe has 82 residual groups, 141 raw address assignments absent from keepers (137 internal; 136 resolver outputs). Those are candidate counts, **not 137 lost distinct people or graph contacts**. The following inspections show why.

## 3. Other residual candidates are alias/degraded-rendering losses, not distinct-person counts

- `campbell-l/inbox/1027.` retains `ees <.brown@enron.com>`; X-To says `Brown, Michael (EES) … CN=MBROWN9`. Discarded `stepenovitch-j/inbox/work_mail/115.` has `michael.brown@enron.com` and `Brown, Michael <Michael.Brown@ENRON.com>`. The retained address remains unresolved; the discarded address resolves Michael Brown. This is lost person attribution for the same recipient, not an additional person missing from the mailing list.
- `forney-j/sent_items/96.` retains `phillips.george@enron.com` and `wong.isaac@enron.com`, despite X-To spelling out `George Phillips <george.phillips@enron.com>` and `Isaac Wong <iz.wong@enron.com>`. Discarded `saibi-e/inbox/630.` preserves the latter addresses. Current resolver identifies George Phillips only from the discarded form; both Wong-related addresses checked remain unresolved. Again the problem is degraded attribution, not two extra humans lost.
- `salisbury-h/inbox/811.` / `williams-w3/bill_williams_iii/396.` retain/lose `e..anderson@enron.com` / `e.anderson@enron.com`. The raw X-To identifies Robert E. Anderson in both, so these should not be counted as two distinct recipients.

Fix: preserve recipient evidence from all high-confidence copies and reconcile it with their X-To/CN entries before collapsing; do not blindly union unreconciled address strings, which would double-count aliases. Record uncertain mappings and perform network sensitivity analyses with and without them.

## 4. The Anderson pair confirms an incorrect recipient identity, not merely an unresolved alias

In keeper `salisbury-h/inbox/811.`, raw X-To explicitly says:

> Anderson, Robert E. <Robert.E.Anderson@ENRON.com>

Its retained normalized To address is `e..anderson@enron.com`. The current sender-derived modal table (10 sender messages) maps this address to **Gary Anderson**, and `resolve_recipient` returns `gary anderson`. The discarded copy confirms Robert E. Anderson via its Notes directory CN. This is a concrete misattributed recipient caused by using a global sender-address map despite contradictory per-message recipient evidence. At least one message is affected; no corpus-wide prevalence estimate is justified by this targeted probe.

## 5. Additional Mark Palmer corroboration

In the Calger pair, the keeper's X-To says `Palmer, Mark A. (PR) … CN=Mpalmer`; the discarded copy has uninitialled `Palmer, Mark … CN=3A5030B0-C53BCDB0-862566EF-7E3318` and To `mark.palmer@enron.com`. The current recipient resolver returns **mark s palmer** for that address. Together with the independently inspected 34738 telephone/signature evidence in `identity/findings.md`, this supplies another same-message bridge from an uninitialled name to Mark A, contradicting the dominant-address initial assignment. It supports the existing identity finding, not a new count of 66 confirmed errors.

## Status judgment

The disjoint-recipient change fixes a class of collapsed distinct sends but does not establish the claimed 233 true sends, and recipient-information loss remains. Treat the original dedupe/recipient finding as partly fixed. Preserve the distinction between verified misattribution (Calger, Anderson, identified aliases), heuristic candidate counts, and unobservable physical-send identity.
