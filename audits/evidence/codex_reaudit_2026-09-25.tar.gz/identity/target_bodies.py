from pathlib import Path
import pandas as pd
import pyarrow.parquet as pq
import json
P=Path('/Users/jebfarneth/projects/enron-knowledge-decay/data/processed')
O=Path('/tmp/enron-reaudit-20260925.WVW9gE/identity')
senders={'stan.horton@enron.com','executive.robert@enron.com','katherine.perry@enron.com','renee.perry@enron.com','binkley.oxley@enron.com','brian.oxley@enron.com','mark.palmer@enron.com','michael.miller@enron.com','a.taylor@enron.com','dana.davis@enron.com','mark.davis@enron.com','george.wasaff@enron.com','robert.knight@enron.com','elizabeth.hernandez@enron.com','abenaa.clay@enron.com','monica.clay@enron.com'}
paths={'maildir/taylor-m/sent_items/336.','maildir/buy-r/sent_items/208.','maildir/kaminski-v/all_documents/11199.','maildir/arora-h/inbox/saved_mail/53.','maildir/arnold-j/inbox/31.','maildir/arnold-j/inbox/41.','maildir/arora-h/inbox/67.'}
rows=[]
for batch in pq.ParquetFile(P/'messages.parquet').iter_batches(batch_size=5000,columns=['path','sender','x_from','authored','body','analysis','automated','structured','to','cc']):
    f=batch.to_pandas()
    f=f[f.sender.isin(senders)|f.path.isin(paths)]
    for r in f.to_dict('records'):
        for k in ['to','cc']:r[k]=list(r[k])
        rows.append(r)
(O/'target_bodies.json').write_text(json.dumps(rows,indent=2))
for r in rows:
    if r['sender'] not in {'mark.palmer@enron.com','michael.miller@enron.com','dana.davis@enron.com','mark.davis@enron.com','george.wasaff@enron.com','robert.knight@enron.com','elizabeth.hernandez@enron.com'}:
        print('\n',r['path'],r['sender'],r['x_from'],{k:r[k] for k in ['analysis','automated','structured']},'\n',r['authored'][:1800])
print('TOTAL',len(rows))
