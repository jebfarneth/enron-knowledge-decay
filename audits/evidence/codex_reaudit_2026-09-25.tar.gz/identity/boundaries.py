from pathlib import Path
import pandas as pd
from enron_importance.identity import normalize_name,entity_type,resolve_recipient,resolve_people
for text in ['Martha Center','Pat Group','Robert Knight, Director Voice Operations & Trading Technology','Conf. Room ECN2760','Conf. Room ECN38C2']:
    key=normalize_name(text)
    print('ROLE_BOUNDARY',repr(text),repr(key),entity_type(key))
for address in ['juan.canavati.@enron.com','martin..gonzalez@enron.com','berney.aucoin@enron.com']:
    print('RECIPIENT_BOUNDARY',address,resolve_recipient(address,{}, {'juan canavati','martin gonzalez','berney aucoin'}))
P=Path('/Users/jebfarneth/projects/enron-knowledge-decay/data/processed')
old=Path('/tmp/enron-audit-20260925.Xj3qoO/network_eval/run1/centrality.parquet')
if old.exists():
    c=pd.read_parquet(old)
    print('OLD_DON',c[c.person_key=='don miller'].to_dict('records'))
i=pd.read_parquet(P/'identities.parquet')
print('OLD_CASES_CURRENT',i[i.address.isin(['legal.1@enron.com','legal.2@enron.com','legal.3@enron.com','legal.4@enron.com','legal.5@enron.com','legal.7@enron.com','albert.meyers@enron.com','bert.meyers@enron.com','.taylor@enron.com','a.taylor@enron.com','mark.taylor@enron.com'])].to_dict('records'))
