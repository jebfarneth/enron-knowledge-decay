from pathlib import Path
import pandas as pd
from collections import Counter
from enron_importance.identity import entity_type,middle_initial,directory_id,normalize_name
P=Path('/Users/jebfarneth/projects/enron-knowledge-decay/data/processed');O=Path('/tmp/enron-reaudit-20260925.WVW9gE/identity')
m=pd.read_parquet(P/'messages.parquet',columns=['path','sender','x_from','analysis','automated','structured','probable_copy'])
m=m.merge(pd.read_parquet(P/'sender_people.parquet'),on='path');m['type']=m.sender_person.map(entity_type)
mbx=m[m.x_from.str.contains('CN=MBX_',na=False)&(m.type=='person')]
print('shared_MBX_as_person',len(mbx),'analysis',int(mbx.analysis.sum()),'keys',mbx.sender_person.nunique())
print(mbx.groupby(['sender','sender_person','x_from']).size().to_string())
print('examples',mbx[['path','sender_person','x_from','analysis']].drop_duplicates('sender_person').to_dict('records'))
pal=pd.read_pickle(O/'initial_selected.pkl');pal=pal[pal.person.str.contains('palmer')].copy()
print('PALMERPHONE')
for r in pal[pal.authored.str.contains('34738|4738|Mark A',case=False,regex=True)].to_dict('records'):
    print(r['path'],r['person'],r['x_from'],repr(r['authored'][-1100:]))
pal['norm']=pal.authored.map(lambda s:' '.join(s.lower().split()))
print('CROSSPERSONEXACTTEXT')
for text,g in pal[pal.norm.str.len()>100].groupby('norm'):
    if g.person.nunique()>1:
        print(g.drop(columns=['authored','norm']).to_dict('records'),'TEXT',repr(text[:250]))
print('recipient-only nonliteral dots')
r=pd.read_csv(O.parent/'network/recipient_only_matches.csv')
print(r[r.address.str.split('@').str[0].str.count(r'\.')!=1].to_dict('records'))
print('SELECTEDNEWIDENTITY')
i=pd.read_parquet(P/'identities.parquet')
print(i[i.person_key.isin(['hottap helpdesk','executive compensation','legal derrick','legal walls','assistant grant'])].to_dict('records'))
