import json
from pathlib import Path
import pandas as pd
import pyarrow.parquet as pq
from enron_importance.identity import resolve_people,normalize_name,middle_initial
P=Path('/Users/jebfarneth/projects/enron-knowledge-decay/data/processed');O=Path('/tmp/enron-reaudit-20260925.WVW9gE/identity')
sp=pd.read_parquet(P/'sender_people.parquet');sp=sp[sp.sender_person.isin(['michael j miller','michael l miller','mark a palmer','mark s palmer'])]
keys=sp.set_index('path').sender_person.to_dict();chunks=[]
for batch in pq.ParquetFile(P/'messages.parquet').iter_batches(batch_size=3000,columns=['path','sender','x_from','authored','subject','date','to','cc']):
    f=batch.to_pandas();f=f[f.path.isin(keys)]
    if len(f):chunks.append(f)
selected=pd.concat(chunks);selected['person']=selected.path.map(keys)
selected.to_pickle(O/'initial_selected.pkl')
print('middle initial cohorts')
for key,g in selected.groupby('person'):
    print('COHORT',key,len(g),'senders',g.sender.value_counts().to_dict())
    for r in g.head(5).to_dict('records'):print(r['path'],r['sender'],r['x_from'],repr(r['authored'][:1200]))
print('two thirds exact threshold counterexample')
synthetic=pd.DataFrame([('a@enron.com','Taylor, Mark A.')] * 6+[('a@enron.com','Taylor, Mark E.')] * 3+[('e@enron.com','Taylor, Mark E.')] * 5+[('a@enron.com','Mark Taylor')],columns=['sender','x_from'])
for share in [2/3,0.6667]:
    persons,_,_=resolve_people(synthetic,'enron.com',min_initial_support=5,initial_share=share)
    print(share,persons.iloc[-1])
