from pathlib import Path
import json
import pandas as pd
from enron_importance.identity import resolve_recipient
S=Path('/tmp/enron-reaudit-20260925.WVW9gE')
ids=pd.read_parquet('/Users/jebfarneth/projects/enron-knowledge-decay/data/processed/identities.parquet')
amap=ids.set_index('address').person_key.to_dict()
people=set(ids.person_key.dropna())
print('CURRENT RECIPIENT RESOLUTION')
for address in ['vince.j.kaminski@enron.com','vkamins@enron.com','eric.linder@enron.com','eric_linder@enron.com','jskilli@enron.com','skilli@enron.com','f..carla@enron.com','f..calger@enron.com','carla.hoffman@enron.com','.brown@enron.com','michael.brown@enron.com','phillips.george@enron.com','george.phillips@enron.com','wong.isaac@enron.com','iz.wong@enron.com','e..anderson@enron.com','e.anderson@enron.com','mark.palmer@enron.com']:
    print(address,'=>',resolve_recipient(address,amap,people),ids[ids.address==address][['x_from','person_key','entity_type']].to_dict('records') if 'x_from' in ids else ids[ids.address==address].to_dict('records'))
loss=json.loads((S/'dedupe_remaining_recipient_loss.json').read_text())
print('ALL REMAINING LOSS CANDIDATES')
for r in loss:
    print(r['keeper'],'retained=',r['retained'] if len(r['retained'])<30 else f'{len(r["retained"])} addresses','missing=',r['missing'])
if (S/'dedupe_headers.json').exists():
    data=json.loads((S/'dedupe_headers.json').read_text())
    print('\nRAW HEADER PAIRS')
    for pair in data['alias_pairs']:
        for path in pair:print(path,json.dumps(data['headers'][path]))
    print('\nSELECTED LOSSES')
    for r in data['loss_cases']:
        print('CASE',r['keeper'],'MISSING',r['missing'])
        for path in [r['keeper']]+r['copy_paths']:print(path,json.dumps(data['headers'][path]))
    print('\nSHORT X-TO EXCERPTS')
    import re
    for path,record in data['headers'].items():
        if any(key in path for key in ['haedicke-m','williams-w3','salisbury-h','forney-j','campbell-l']):
            for pattern in [r'.{0,50}Anderson.{0,120}',r'.{0,40}Calger.{0,110}',r'.{0,40}Palmer.{0,160}',r'.{0,40}Hoffman.{0,120}',r'.{0,40}Phillips.{0,100}',r'.{0,40}Wong.{0,100}',r'.{0,40}Brown.{0,120}']:
                for found in re.findall(pattern, record['X-To'] or '',flags=re.I):print(path,found)
