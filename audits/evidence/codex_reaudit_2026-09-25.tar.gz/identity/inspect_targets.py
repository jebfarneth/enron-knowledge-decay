import json
from pathlib import Path
from enron_importance.identity import normalize_name
O=Path('/tmp/enron-reaudit-20260925.WVW9gE/identity')
rows=json.loads((O/'target_bodies.json').read_text())
targets={'dana.davis@enron.com','mark.davis@enron.com','george.wasaff@enron.com','robert.knight@enron.com','elizabeth.hernandez@enron.com','abenaa.clay@enron.com','monica.clay@enron.com'}
from collections import Counter
print('patterns',Counter((r['sender'],r['x_from'],normalize_name(r['x_from'])) for r in rows if r['sender'] in targets))
counts=Counter()
for r in rows:
    k=(r['sender'],normalize_name(r['x_from']))
    if r['sender'] in targets and counts[k]<5:
        counts[k]+=1
        print('\n',r['path'],r['sender'],r['x_from'],'flags',r['analysis'],r['automated'],r['structured'],'\n',r['authored'][:2200])
