# Independent identity / rank re-audit evidence

Scope: current source at `1ab1b2bd714ee11dd4959132e97f0b9c95664cdb`. No repository writes. All scripts and derived evidence are in this directory. Commands below were run with the repository as working directory. Python was `.venv/bin/python` (not a different implementation). Source/data were not modified.

## Reproduction commands and outputs

```
.venv/bin/python /tmp/enron-reaudit-20260925.WVW9gE/identity/probe.py > /tmp/enron-reaudit-20260925.WVW9gE/identity/probe.txt
.venv/bin/python -u /tmp/enron-reaudit-20260925.WVW9gE/identity/target_bodies.py > /tmp/enron-reaudit-20260925.WVW9gE/identity/target_bodies.txt
.venv/bin/python /tmp/enron-reaudit-20260925.WVW9gE/identity/inspect_targets.py > /tmp/enron-reaudit-20260925.WVW9gE/identity/inspect_targets.txt
.venv/bin/python -u /tmp/enron-reaudit-20260925.WVW9gE/identity/quantify.py > /tmp/enron-reaudit-20260925.WVW9gE/identity/quantify.txt
.venv/bin/python -u /tmp/enron-reaudit-20260925.WVW9gE/identity/counterfactual.py > /tmp/enron-reaudit-20260925.WVW9gE/identity/counterfactual.txt
.venv/bin/python -u /tmp/enron-reaudit-20260925.WVW9gE/identity/initial_probe.py > /tmp/enron-reaudit-20260925.WVW9gE/identity/initial_probe.txt
.venv/bin/python /tmp/enron-reaudit-20260925.WVW9gE/identity/palmer_review.py > /tmp/enron-reaudit-20260925.WVW9gE/identity/palmer_review.txt
.venv/bin/python -u /tmp/enron-reaudit-20260925.WVW9gE/identity/more_probes.py > /tmp/enron-reaudit-20260925.WVW9gE/identity/more_probes.txt
.venv/bin/python -u /tmp/enron-reaudit-20260925.WVW9gE/identity/boundaries.py > /tmp/enron-reaudit-20260925.WVW9gE/identity/boundaries.txt
```

`probe.py` reruns `resolve_people` on all current message headers, not cached identities; compares every per-message attribution and full identity table; reruns `formal_ranks` on the Excel source and freshly recomputed identities. Output: **zero sender_people mismatches**, identity table exactly equal, rank table exactly equal, 12 aliases, 6,455 addresses / 5,869 nonnull address-map keys. Key types: 5,635 person, 96 role, 136 address, 2 list. Three placeholder address rows, not three additional keys. Full-name/initial cohorts and every conflicting header pattern are saved in CSVs.

`target_bodies.py` streams processed authored text for specified targets. The current processed parquet has no raw `body` column; the Arrow selection silently omitted this nonexistent column. Thus `target_bodies.json` contains **authored text, not raw bodies**. All body-based findings below are based on explicitly named authored excerpts. A first `palmer_review.py` attempt requesting `body` failed with KeyError, was corrected to `authored`, and rerun. Do not misdescribe those excerpts as raw email originals. The two rank-signature examples and direct self-identification examples remain visible in authored text.

## Response-row verification

| Finding / claimed status | Verified status | Evidence / reproduced result |
|---|---|---|
| M-ID1 no.address → Don Miller / fixed | **Original counterexamples fixed; broader per-message normalization still wrong** | Recomputed 778 messages: 98 Don Miller, 639 null. Remaining 41 attributed to other keys. `arnold-j/inbox/31.`, `/41.`, `arora-h/inbox/67.` all null rather than Don. Current Don degree346, old audit independently saved run1 degree491. `probe.txt`, `target_bodies.txt`, `quantify.txt`, `boundaries.txt`. Current authorship errors below are different examples, not evidence that those three original examples remain wrong. |
| M-ID2 numbered temp / fixed | **Numbered-temp defect fixed; general role classification only partial** | legal.1,.2,.3,.4,.5,.7 all separate legal temp keys, message counts22,16,4,5,1,30, each typedrole. 96rolekeys reproduced. General roles still misclassified below. |
| M-ID3 directory aliases / fixed | **Claimed 12 merges implemented; no false CN merge established** | Fresh aliases exactly12, including Albert/Bert. Albert44 and Bert60 current messages map albert meyers. Suspicious Brian/Binkley Oxley, Katherine/Renee Perry, Abenaa/Monica Clay inspected; their own signatures corroborate the merge (details below). Existing same-person Dana/Mark Dana Davis remains split because different CNs do not trigger rule. |
| M-ID4 Mark A/E Taylor / fixed | **Specific Taylor example fixed; initial-imputation rule partly fixed overall** | `.taylor`→mark e, `a.taylor`→mark a. Explicit Charles A Taylor message from a.taylor now Charles rather than Mark (per-message improvement). Actual supported split bases exactly Mark Palmer, Mark Taylor, Michael Miller. New Mark Palmer error below proves dominance can misassign uninitialled messages. |
| 21,047 “people” / partly fixed | **Partly fixed label is warranted** | Current graph20,757;5606person/91role/305list/14755address. These are heuristic types, not verified people. MBX conference rooms etc stillperson; unresolved Mark Palmer/Taylor bases incorrectlyperson. README's “14755…never sent” false:126 address nodes were seen as internal senders and119 have positive graph outstrength (network agent independently counted119; our full eligibility intersection124 includes senders with no surviving internal-target edge). |
| CMU placeholder corrupts named scores / fixed | **Original corruption fixed, wording inaccurate if read as dropping all placeholder-origin messages** | Recipient placeholders resolveNone, unknown sender evidence yieldsnull. But attributed placeholder-origin messages remain valid senders intentionally:98 Don messages survive network mask, plus other named/role messages. `quantify.txt` lists all. “Placeholder addresses are dropped” is defensible for address nodes; “placeholder messages dropped as senders” is not literal implementation. |
| M-RANK1 conflicting titles/notes / fixed | **Specified policy implemented; truth of titles remains open as acknowledged** | Recomputed161rows/160matched/129distinct titledpeople. Both VP rows dropped; corresponding Trader retained. Exactly Beck/Buy/Hayslett/Kaminski disputed andnotespreserved. All11 original correction targets have sender-header evidence; additionalMarkTaylor→MarkE also corroborated. Rank names MarkDavis/DanaDavis themselves introduce remaining label alignment defect below. |
| Population/custodian confounding / open | **Open** | No new identity correction establishes a representative workforce sample. This subaudit did not rerun custodian control accuracy; root/network agent owns that comparison. Do not call old43.9%/48.2% freshly reproduced here. |
| Address-modal mutation gap / fixed | **Original fixture weakness fixed; important new gaps survive** | Current dedicated test includes first message Mark then two Dana, unlike old same-first fixture. New initial-share mutation survives28 tests; cached corpus regressions survive all-None identity implementation (below). |
| Tests cannot establish corpus validity / partly fixed | **Partly fixed, not validation of current algorithms** | Nine corpus tests check static generated outputs, never invoke resolver. All-None mutation9/9pass. This does not imply the new ordinary identity unit tests fail to catch all-None—those were intentionally not included in the cached-artifact mutation. |

### Rank-source and correction checks

`shasum -a 256 data/raw/Enron_Employee_Status.xls /tmp/enron-audit-20260925.Xj3qoO/identity_rank/title_refetched.xls` returned identical `5f67ea06209a51a57c5b05608cc9f56c58c97e62892735eed4232313ff54c071`. This verifies the current file is byte-identical to the prior audit's independently retrieved Archive copy, **not a fresh external archival retrieval or independent verification of each undated title**.

`formal_rank.py:61–76` applies reviewed corrections, matches known keys, drops specified rows, and retains notes and flags. `config.yaml:99–126` contains 12 corrections (11 old plus Mark Taylor), two dropped rows, and four disputed keys. `quantify.txt` lists each target's current message count and up to three distinct supporting headers. Harpreet/Harry is explicitly self-explained in `arora-h/inbox/saved_mail/53.`: “It is a short form of my real name Harpreet.” The current surviving `taylor-m/sent_items/336.` says “delete Mark A Taylor and add me as Mark E Taylor”; it was independently read in `target_bodies.json`, and the current `.taylor` address has 465 headers specifying Mark E.

Current visible rank contradictions: `buy-r/sent_items/208.` authoredsignature “Executive Vice President / Chief Risk Officer” vs titleManager; `kaminski-v/all_documents/11199.` “Vincent Kaminski / Managing Director” vs Manager. Beck noteChiefOperatingOfficer versusEmployee; Hayslett noteCFOandTreasurer along withVP, which is a possible concurrent title, not proof the VP string itself is false. Ranking CFO automatically aboveVP would require a separate organization/date model. The policy flags this ambiguity rather than silently inventing levels.

Stored sensitivity CSV values are0.6507whenold conflictinghigher-title policy restored,0.6653without4disputedlabels. These are consistent with response65.1%/66.5%; full rerun is root/network agent's responsibility, not claimed as independently recomputed here.

## New Major findings

### I1. Same employee split across labels; this changes the formal-rank result

**Code:** `identity.py:80–111` nameword normalization; `166–178` same-CN-onlyalias merge; `199–222` per-message attribution; `formal_rank.py:64–71` normalized-name titlejoin.

**Data:** dana.davis@ has351 headers “Dana Davis” / “Davis,Dana” and10 “Davis,MarkDana”; the latter move to `mark davis`. Separate mark.davis@ has3 “MarkDanaDavis” messages. The current corpus explicitly supports the same person:

- `benson-r/deleted_items/89.` XFrom “Davis, Mark Dana …CN=MDAVIS”; message describes personal deskVAR allocations and signs “Dana”.
- `lavorato-j/all_documents/238.`, `/455.`, `/478.` sender mark.davis@, XFrom “Mark Dana Davis”, sign “Dana”.
- Bothkeys are retained separately. Title source assigns MarkDavis VicePresident3; DanaDavis row hasnotitle. Therefore the labelled score is the small fragment, not the combined person's network.

**Quantification:** danaDavis degree237; markDavis63. The10 current dana-address reassignments include8analysis messages. All13 markDavis node outgoingmessages remain separate from Dana. Independent adjacency-set calculation in `counterfactual.py` merges the confirmed same-person keys and carries the existingMarkDavis title onto that unified person. Uniondegree266. With that one merge, degreeorderingaccuracy is **0.6655974338412189**, versus **0.6549318364073777** on the same6235pairs. Nineother labelledpeople eachlose1duplicatecontact. This sensitivity assumes the existing sourceMarkDavis titlebelongs to this now unified identity; it does not establish the VP title independently.

**Impact:** 1.07percentage-point baseline change from one unresolved identity, direct contamination of employee NLP aggregation/identity-disjoint splits. Per-message attribution moved the ambiguity, did not solve it.

**Fix:** persistententityrecord with reviewed alias evidence acrossnames/CNs/addresses, confidence/ambiguity policy; validate all129 labeljoins and retain a labelledalias-evidence table. Add raw-header+signature regression for this case. Rebuild scores aftercorrection; do not merelyremap evaluation labels onto theold63score.

### I2. Initialled-only majority sends PR work to the wrong Mark Palmer

**Code:** `identity.py:180–197`; thresholdfrom`config.yaml:64–67`.

**Rule reproduced:** MarkPalmer base has38 explicitA,15explicitS. mark.palmer@ contains9explicitS but66uninitialled messages; all66 are assignedS because the denominator includesonlyinitialled messages. `.palmer`has38Aand4S;S'sCN isMPALMER3, A'sMPALMER. AlluninitialledhavebeenforcedtoS despite this sharedaddress ambiguity.

**Independent corpus corroboration of wrong assignments:**

- `kean-s/all_documents/708.` assignedMarkS: press-release coordination signs “Mark Palmer / Ext.34738”.
- `lay-k/notes_inbox/465.` assignedMarkS: press-release coordination says reply orcall “34738”.
- `lay-k/inbox/546.` explicitly XFrom “Palmer, Mark A. (PR)…CN=MPALMER”; signs “Mark Palmer / ext.34738”.
- `whalley-g/inbox/245.` explicitlyMarkA(PR) gives “713-853-4738” forfinancingreleasecomments.
- `kaminski-v/all_documents/1661.` explicitlyMarkS says “Intended for Mark A. Palmer…”, confirming these aredifferent people, not initialsonepersonusesinterchangeably.

The samepersonal extension and samePRworkflow corroborate **at least2 misassignments**. Manyother66messages concern media andPR, butthisauditdoesnotlabelall66wrong merelyfromtopic. Fullnamedcohort evidenceis in`initial_selected.pkl`,`palmer_review.txt`,`more_probes.txt`.

**Impact:** false attribution of oneemployee's functional responsibilities toanother. Particularly dangerous forforthcoming topicownership/text-rolemodels, where the newrule systematically moves themajority uninitialledPRcohort basedonthe minoritywithinitials.

**Fix:** do notassign an ambiguouscanonical addressbasedon the initialledsubset's proportion alone. UsepermessageconsistentdirectoryID, independentlyreviewedaddress/timemapping, explicitnameorothercorroboratingmetadata;otherwise preserve ambiguity andexclude frompersonevaluation. Add thispersonalphonecounterexample regression and an uninitialled-majority challengefixture.

### I3. Display-name grammar and node typing invent people and misclassify shared accounts

**Code:** `identity.py:80–111` treats anycomma aslast-first; `93–106` inconsistentdigitrecognition; `139–146` defaultsunrecognizedstrings toperson; `network.py:124–126` derivesambiguityonlyfrommodaladdressrows.

**Confirmed surname/title-suffix errors:**

- Two analysis messages `salisbury-h/read/297.`,`313.` fromgeorge.wasaff@ haveXFrom “George Wasaff, Global Strategic Sourcing…” andbecome invented`global wasaff` (degree3/out2). Sameaddress15othermessagesresolve`george wasaff` (degree143); hisordinarymessagesandsignature sayGeorgeWasaff. Uniondegree144; noformalrankaccuracychange fromthismergealone.
- One analysis message `salisbury-h/read/314.` fromrobert.knight@ hasXFrom “Robert Knight, Director Voice Operations & Trading Technology…” andbecomes arolekey`director voice operations trading technology robert knight`. The5otherheaderssayRobertKnight; `kaminski-v/all_documents/10153.` signaturesays “Robert Knight / Director Voice Communications”. Normalpersondegree20, separatedroledegree1; union21. Againnot aformalrankaccuracychange, butpersontopicmisattribution.

**Shared accounts presentedaspeople:** 154messages have `CN=MBX_*` XFromandperson-typedkey;118enteranalysis,32keys. Thiscohortincludesnamedannouncements aswellasclearroles, so154isnotclaimedas154individuallyadjudicatederrors. Clearcounterexamplesinclude `executive compensation`, `hottap helpdesk`, `conf room ecn2760`, `conf room ecn38c2`, `conf room ecn42c2`, `conf bachelor`, `conf hood`, `parking transportation`, `sap security`, `extra daemon`, `isc registrar`. Sourceheader andexamplepathforeachin`more_probes.txt`. E.g `may-l/calendar/1.` XFrom “Conf.Room ECN2760 …CN=MBX_CRECN2760” ispersonandanalysisTrue. `normalize_name` preserveswordsbecauseitdetectsanydigit; `is_role_key`onlyrecognizes whollynumericword, henceECN2760failsrolecheck. TestsuseTemp1,separatenumericalword, andmissthis case.

**Ambiguousbaseclassification:** noaddress-maprowhasentity_typeambiguous; two per-messagebasekeys `mark palmer` and `mark taylor` neverthelesssurvive. Networktypesbothperson, eachdegree1/out1. Networkagentconfirmedtheironlytargetsarecorp.officers@ andnymex.list@, so theydisappearfrompeople-onlygraph; donotclaimthesetwokeyschange67.2%variant.

**Analysisnotperson-only:** of167970analysisrows,165397person-typed,1087null,754role,551address-only,181list;2573nonpersonrows. Thisisnotnecessarilyaprepare-stagebugifPhase3addsavalidatedpersonfilter, butitmustnotbeuseddirectlyastheemployee-NLPdataset. Evenfilteringcurrenttypepersonisinsufficientbecauseofthefalsepersonkeysabove.

**Fix:** parsepersonalnameandsuffixseparately,returnexplicitentitytype/ambiguityfromresolutionratherthaninferitfromkeystrings;consistentalphanumericIDhandling;reviewshared-MBXandtitle-suffixednames;carryambiguityfrommessagelevel;defineaseparateperson-texteligibilitymaskwithreportedattrition. Unit-testactualheaders/records,notjustinventedcleanpersonnames.

## New Minor findings / validation limitations

### I4. Tests do not exercise the dominance threshold or fresh corpus attribution

Exact commands:

```
PYTHONDONTWRITEBYTECODE=1 .venv/bin/python -u /tmp/enron-reaudit-20260925.WVW9gE/identity/mutations.py ignore_dominance_threshold > /tmp/enron-reaudit-20260925.WVW9gE/identity/mutation_dominance.txt
PYTHONDONTWRITEBYTECODE=1 .venv/bin/python -u /tmp/enron-reaudit-20260925.WVW9gE/identity/mutations.py cached_corpus_all_sender_unknown > /tmp/enron-reaudit-20260925.WVW9gE/identity/mutation_cached.txt
```

Bothin-memoryonly; pytest`-p no:cacheprovider`.

- `_dominant` mutatedtoalwaysmodal, completelyignoringconfiguredshare: **28/28** identity/formal_rank/corpus tests pass.
- `resolve_people` mutatedtoalwaysreturnNone/emptytables: **9/9 corpusregressions** passbecause`tests/test_corpus_regressions.py:16–25` loadexistingparquetsratherthanexecuteit. Otheridentityunittestswerenotrununderthissecondmutation, andarenotclaimedtopassit.
- Severalcorpusassertionsareconditionalonpathpresence(`48–51`,`66–74`), thereforemissingkeycasescanquietlyskipassertions. Rootcanincludeasgeneraltestfinding; thissubauditdidnotmutatepathpresence.

Fixfreshminicorpusintegrationfixtureswithheader/bodyinputs, exactexpectedidentityandtype; thresholdboundaryfixturesatbelow/equal/aboveshare; regenerateinsidefixtureorassertoutputs/sourceprovenancebeforestaticartifacttests.

### I5. Small exact-description mismatches

- Config0.6667 isnotexact2/3. `initial_probe.py` constructs6A+3Eattheambiguousaddress,5Eelsewhere,thenoneuninitialled: with2/3itbecomesMarkA; withconfig0.6667itremainsMarkTaylor. **Noactualcurrentcorpusassignmentdifferencewasestablishedforthisboundary**; reportasspecification/testissue,notmeasuredcorpuserror.
- Recipientresolver`identity.py:231–235` drops emptydotcomponents beforeliteralfirst.lastmatching. Actual`juan.canavati.@`6networkmentionsand`martin..gonzalez@`3resolveperson. `boundaries.py` reproducesboth. Thisisnotproofeitheridentitymatchiswrong; the“literallyfirst.last”documentationisnarrowerthancode.
- README14755addresses“never sent” iswrong:126currentaddressnodesoccurasinternal senderaddresses,119havepositiveoutstrength. `quantify.txt`,networkagent`typing_check.log`/`recipient_checks.log`.

## Checked negative results and unverified claims

- Fresh12CNaliasesreproduced; suspiciousmergescheckedagainstsignatures: BrianOxley message`lay-k/inbox/1659.` signsB.K.Oxley(binkley)andprovidesBrian.Oxley@; KatherinePerrymessage`blair-l/training___2001/4.` signsReneePerry; AbenaaMonicaClay`keiser-k/calendar/9.` signsMonicaClayandsameextension57227asMonicaheaders. These arenotfalsemerges. Nofalsemergeamongthe12wasproven; relatives/reusedCNremainanunvalidatedrisk,notafinding.
- Inspectedall3initialsplitcohorts. MichaelJandMichaelLhaveconsistentdistinctinitialheaders, LsignsMLM; nofalseMichael splitestablished. MarkA/Eoriginalexplicitcorrectionwasalreadyindependentlysupported;newinferredMarkPalmercaseiswrongabove.
- Automaticplaceholderdetectoridentifiesonlyconfiguredno.address/40enronand40messageenron.announcement. Thelatterhasmultipleactualannouncementroles andnoevidencethatitisasinglepersonmisclassified. Noadditionalfalsepositiveautomaticplaceholderwasproven.
- SyntheticpersonalnamesMarthaCenterandPatGroupbecomerolesin`boundaries.txt`; noactualcorpuspersonwiththesesurnameswasidentified, so thisisboundaryrisknotobservederror. Actualtitle-suffixedRobertKnightisconfirmed.
- Networkagentexported275recipient-onlyaddress→personmatches/5659recipient-messageoccurrences. Ireviewedthemappinglistandthedotexceptions; noactualfalsefirst.lastpersonmatchwasproven. Thefunctionisheuristic,andnamecollisionriskdoesnotbyitselfestablishacorpuserror.
- Noindependenthumanlabels,completepersondirectory,time-indexedemploymentrosterorreportinglineswereavailable. Theexamplesestablishspecificerrors,notarepresentativeoverallidentityerrorrate.
- Thissubauditdidnotrerunexactbetweenness,theoldfullpipeline,orCIbootstrap;root/networkagentownsreproductionofthoseclaims.

## Phase3 conditions from this subaudit

Beforepersontopicownership/speech-actclaims: resolveconfirmedDavisandPalmererrors; auditall129labeljoins; persistevidence-backedentitytypeandambiguity; freezeamodelingeligibilitymaskratherthanreuseanalysisblindly; evaluateidentityerrorswithablations/removalofambiguous/sharedaccounts; constrainemployee/date-splitlogicsofalsealiasesdonotputthesameemployeeintrainandtest. Signature/contactredactioncanbeavaluableleakagecontrolbutmustnotdestroyidentity-evidenceauditing: retainprivateauditmetadata,excludeitfrommodelinputs. Noneoftheseexamplesjustifiesclaimingtheentirebaselineisinvalid;theyjustifywithholdingstrongPhase3person-levelclaimsuntillcorrectedandremeasured.
