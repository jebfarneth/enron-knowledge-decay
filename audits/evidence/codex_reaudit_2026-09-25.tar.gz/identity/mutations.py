import sys
import pandas as pd
import pytest
import enron_importance.identity as identity
mode=sys.argv[1]
if mode=='ignore_dominance_threshold':
    def dominant(values, share):
        counts=values.value_counts()
        return counts.index[0] if len(counts) else None
    identity._dominant=dominant
elif mode=='cached_corpus_all_sender_unknown':
    def wrong(messages,*args,**kwargs):
        return pd.Series([None]*len(messages)),pd.DataFrame(),{}
    identity.resolve_people=wrong
args=['-q','-p','no:cacheprovider']
args+=['tests/test_corpus_regressions.py'] if mode.startswith('cached_') else ['tests/test_identity.py','tests/test_formal_rank.py','tests/test_corpus_regressions.py']
sys.exit(pytest.main(args))
