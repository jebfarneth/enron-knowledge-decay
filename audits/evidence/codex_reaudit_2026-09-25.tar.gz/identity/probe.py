from pathlib import Path
import json
import pandas as pd
from enron_importance.config import load_config
from enron_importance.identity import *
from enron_importance.formal_rank import formal_ranks
ROOT=Path('/Users/jebfarneth/projects/enron-knowledge-decay')
OUT=Path('/tmp/enron-reaudit-20260925.WVW9gE/identity')
cfg=load_config(); spec=cfg['identity']; p=ROOT/'data/processed'
m=pd.read_parquet(p/'messages.parquet',columns=['path','sender','x_from','analysis','automated','structured'])
sp,ids,aliases=resolve_people(m,cfg['senders']['internal_domain'],spec['placeholder_addresses'],spec['min_initial_support'],spec['initial_share'])
oldsp=pd.read_parquet(p/'sender_people.parquet')['sender_person']; oldids=pd.read_parquet(p/'identities.parquet')
print('sender_people_mismatches',int((sp.fillna('NONE')!=oldsp.fillna('NONE')).sum()))
print('identities_equal',ids.equals(oldids),'aliases',len(aliases),aliases)
m['person']=sp
print('identities',len(ids),'keys',ids.person_key.nunique(),'types',ids.drop_duplicates('person_key').entity_type.value_counts().to_dict())
print('placeholder_rows',ids[ids.entity_type=='placeholder'].to_dict('records'))
print('no_address',m[m.sender=='no.address@enron.com'].person.value_counts(dropna=False).to_dict())
print('rolekeys',ids[ids.entity_type=='role'].person_key.nunique())
ids[ids.entity_type=='role'].to_csv(OUT/'roles.csv',index=False)
im=m[m.sender.str.endswith('@enron.com',na=False)].copy()
im['base']=im.x_from.map(normalize_name);im['initial']=im.x_from.map(middle_initial);im['cn']=im.x_from.map(directory_id)
im['base']=im.base.map(lambda x:aliases.get(x,x))
counts=im[im.initial.notna()].groupby(['base','initial']).size()
print('supported_initials',counts[counts>=5].to_dict())
splitkeys=[k for k,g in counts[counts>=5].groupby(level=0) if len(g)>=2]
print('split_keys',splitkeys)
print('split_people',im[im.base.isin(splitkeys)].groupby(['base','person'],dropna=False).size().to_dict())
im[im.base.isin(splitkeys)].to_csv(OUT/'split_rows.csv',index=False)
im[im.base.isin(splitkeys)].groupby(['base','sender','cn','initial','person'],dropna=False).size().to_csv(OUT/'split_patterns.csv')
alias_names=set(aliases)|set(aliases.values())
im[im.base.isin(alias_names)].groupby(['base','sender','x_from','person'],dropna=False).size().to_csv(OUT/'alias_patterns.csv')
amap=ids.set_index('address').person_key.to_dict();im['modal']=im.sender.map(amap)
conflict=im[im.person.notna() & im.modal.notna() & (im.person!=im.modal)]
print('message_vs_modal',len(conflict),'analysis',int(conflict.analysis.sum()),'senders',conflict.sender.nunique(),'keys',conflict.person.nunique())
conflict.groupby(['sender','modal','person','x_from'],dropna=False).size().sort_values(ascending=False).to_csv(OUT/'conflict_patterns.csv')
conflict.to_csv(OUT/'conflict_rows.csv',index=False)
s=cfg['formal_rank'];titles=pd.read_excel(ROOT/'data/raw'/s['filename'],header=None,names=['name','title','note'])
r=formal_ranks(titles,ids,s['levels'],s['corrections'],aliases,s['dropped_rows'],s['disputed'])
print('ranks_equals',r.equals(pd.read_parquet(p/'formal_rank.parquet')))
print('rank_counts',len(r),int(r.person_key.notna().sum()),r.dropna(subset=['person_key','level']).person_key.nunique())
print('dropped',r[r.match=='dropped conflicting row'].to_dict('records'))
print('disputed',r[r.disputed].to_dict('records'))
print('corrections',r[r['match']=='reviewed correction'][['name','person_key']].to_dict('records'))
r.to_csv(OUT/'ranks.csv',index=False)
