from pathlib import Path
import pandas as pd
import json
from enron_importance.identity import entity_type,normalize_name,resolve_people
from enron_importance.config import load_config
P=Path('/Users/jebfarneth/projects/enron-knowledge-decay/data/processed')
O=Path('/tmp/enron-reaudit-20260925.WVW9gE/identity')
m=pd.read_parquet(P/'messages.parquet',columns=['path','sender','x_from','analysis','automated','structured','probable_copy','sender_internal'])
m=m.merge(pd.read_parquet(P/'sender_people.parquet'),on='path')
i=pd.read_parquet(P/'identities.parquet'); c=pd.read_parquet(P/'centrality.parquet')
amb=set(i.loc[i.entity_type=='ambiguous','person_key']);m['type']=m.sender_person.map(lambda p:entity_type(p,amb))
print('analysis_type',m[m.analysis].type.value_counts().to_dict())
print('analysis_noaddress',m[m.analysis & (m.sender=='no.address@enron.com')].type.value_counts().to_dict())
print('node_types',c.entity_type.value_counts().to_dict())
address_nodes=set(c.loc[c.entity_type=='address','person_key'])
sender_address_only=address_nodes & set(i.address)
print('address_nodes_seen_sending',len(sender_address_only),'network_active',len(address_nodes & set(m.loc[m.sender_internal & ~m.automated & ~m.structured & ~m.probable_copy,'sender_person'].dropna())))
print('address_sender_examples',c[c.person_key.isin(sorted(sender_address_only)[:10])].to_dict('records'))
print('selected_nodes',c[c.person_key.isin(['mark palmer','mark taylor','mark a taylor','mark e taylor','dana davis','mark davis','george wasaff','global wasaff','robert knight','director voice operations trading technology robert knight','don miller'])].to_dict('records'))
print('false_split_counts',m[m.sender_person.isin(['mark davis','global wasaff','director voice operations trading technology robert knight','bertha hernandez'])].groupby(['sender','sender_person','analysis','type']).size().to_dict())
print('placeholder_network_rows',m[m.sender.isin(i.loc[i.entity_type=='placeholder','address']) & m.sender_person.notna() & m.sender_internal & ~m.automated & ~m.structured & ~m.probable_copy].groupby(['sender','sender_person']).size().to_dict())
print('correction_headers')
for source,key in load_config()['formal_rank']['corrections'].items():
    t=m[m.sender_person==key]
    print(source,key,len(t),t[['path','sender','x_from']].drop_duplicates('x_from').head(3).to_dict('records'))
print('all_role_types_in_analysis',m[m.analysis & (m.type!='person')].groupby(['type','sender_person'],dropna=False).size().sort_values(ascending=False).to_dict())
m[m.analysis & (m.type!='person')][['path','sender','sender_person','type']].to_csv(O/'analysis_nonperson.csv',index=False)
