from pathlib import Path
import hashlib, json, subprocess

root = Path('/Users/jebfarneth/projects/enron-knowledge-decay')
scratch = Path('/tmp/enron-reaudit-20260925.WVW9gE')
original = json.loads((scratch / 'original_hashes.json').read_text())

def digest(path):
    result = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            result.update(block)
    return result.hexdigest()

changed = {}
unchanged = []
for relative, expected in original.items():
    path = root / relative
    actual = digest(path) if path.is_file() else None
    if actual != expected:
        changed[relative] = {'before': expected, 'after': actual}
    else:
        unchanged.append(relative)
result = {
    'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip(),
    'initial_status': (scratch / 'original_git_status.txt').read_text(),
    'final_status': subprocess.check_output(['git', 'status', '--porcelain=v1', '--untracked-files=all'], cwd=root, text=True),
    'changed_original_files': changed,
    'unchanged_original_files': unchanged,
    'original_file_count': len(original),
    'report_exists': (root / 'audits/reaudit_codex_2026-09-25.md').exists(),
}
(scratch / 'final_integrity.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
