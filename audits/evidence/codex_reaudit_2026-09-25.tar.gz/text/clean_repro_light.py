"""Reproduce cleaning artifacts without materializing the whole raw-body corpus."""
import hashlib
import json
import pathlib
import sys

import pandas as pd
import pyarrow.parquet as pq

R = pathlib.Path('/Users/jebfarneth/projects/enron-knowledge-decay')
O = pathlib.Path('/tmp/enron-reaudit-20260925.WVW9gE/text') / sys.argv[1]
O.mkdir(exist_ok=True)
sys.path.insert(0, str(R / 'src'))
from enron_importance.config import load_config
from enron_importance.validate_cleaning import compare, summary

cfg = load_config()
raw_file = cfg['paths']['interim'] / 'messages_raw.parquet'
kept = pd.read_parquet(cfg['paths']['processed'] / 'messages.parquet', columns=['path'])
raw_paths = pd.read_parquet(raw_file, columns=['path'])
# Identical order/index/sample operation to validate_cleaning.main; bodies are deferred.
sample = raw_paths[raw_paths.path.isin(set(kept.path))].sample(
    cfg['validation']['sample_size'], random_state=cfg['validation']['seed'])
wanted = set(sample.path)
by_path = {}
for batch in pq.ParquetFile(raw_file).iter_batches(batch_size=2048, columns=['path', 'body']):
    paths = batch.column(0).to_pylist()
    chosen = [i for i, p in enumerate(paths) if p in wanted]
    for i in chosen:
        by_path[paths[i]] = batch.column(1)[i].as_py()
assert len(by_path) == len(wanted) == cfg['validation']['sample_size']
frame = compare(sample.path.map(by_path).reset_index(drop=True))
(O / 'cleaning_crosscheck.json').write_text(json.dumps(summary(frame), indent=2) + '\n')
frame.assign(path=sample.path.to_numpy())[~frame.agree].nsmallest(40, 'jaccard')[
    ['path', 'jaccard', 'ours', 'theirs']
].to_csv(O / 'cleaning_crosscheck_disagreements.csv', index=False)
report = {}
for filename in ['cleaning_crosscheck.json', 'cleaning_crosscheck_disagreements.csv']:
    ours = (O / filename).read_bytes()
    original = (cfg['paths']['results'] / filename).read_bytes()
    report[filename] = {'bytes': len(ours), 'sha256': hashlib.sha256(ours).hexdigest(),
                        'original_sha256': hashlib.sha256(original).hexdigest(),
                        'matches_original': ours == original}
(O / 'checksums.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report, indent=2))
