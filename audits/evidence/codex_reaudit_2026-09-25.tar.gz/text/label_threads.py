import json,pathlib,collections,math
P=pathlib.Path('/tmp/enron-reaudit-20260925.WVW9gE/text')
sample=json.loads((P/'fresh_reply60.json').read_text())
# Independent Codex reading of raw child and proposed parent's body; no human gold.
exceptions={
0:('same_author_related_update_not_reply','Same sender broadcasts revision of own presentation invitation; includes self among recipients.'),
1:('wrong_immediate_parent','Child quotes Kean September 1 08:27 request, not Kingerski rate reply.'),
4:('wrong_immediate_parent','Child quotes Canovas July 14 contact-details question first; selected parent is July 11 original request.'),
6:('forward_or_relay_not_reply','Kaminski forwards his own prior reply to assistant Shirley with new instruction; Re subject inherited.'),
17:('wrong_immediate_parent','Immediate quoted request is Trevor Woods November 15 asking Mike T; parent selected is Lucy King November 14.'),
20:('uncertain_direct_parent','Actually I forgot to take $40 out corrects an earlier amount absent from selected parent; may be additional answer to same question.'),
23:('wrong_immediate_parent','Child answers request for fax number dated November 5; selected parent is November 2 original multipoint inquiry.'),
25:('forward_or_relay_not_reply','Schneider forwards Dan Hyvl question to Tom Shelton asking Tom to respond to Dan; Dan only copied.'),
26:('wrong_immediate_parent','Child addresses and quotes Susan Mara May 11 12:28; selected parent is James Steffes May 11 12:48 response.'),
28:('wrong_immediate_parent','Child answers John Wack question quoted first; selected parent is Nieland attachment resend.'),
31:('wrong_immediate_parent','Child quotes Wollam 10:03 extension granted; parent selected is 09:56 offer of extension.'),
38:('uncertain_direct_parent','Followup on missing services agreement quotes own October16 request, whereas selected parent is Cindy October17 directors response.'),
42:('wrong_immediate_parent','Child quotes March16 missing Mike deal, selected parent March8 unrelated broker claims.'),
46:('uncertain_direct_parent','Unquoted child asks whether there is a band; selected parent asks about hot dogs and quotes child already planning dancing.'),
51:('wrong_immediate_parent','Child agrees to October11 room booking; selected parent is October10 original meeting request.'),
53:('wrong_immediate_parent','Child quotes December20 broker callback delay; parent selected December18 missing sale.'),
55:('uncertain_direct_parent','Unquoted where are you question could be response to immediately previous email, but no textual support for this parent.')}
labels=[]
for s in sample:
    c,e=exceptions.get(s['sample_id'],('direct_reply','Content answers selected parent; quotation or specific substantive continuity supports direct relation.'))
    labels.append({'sample_id':s['sample_id'],'path':s['child']['path'],'parent_path':s['parent']['path'],'classification':c,'evidence':e})
counts=collections.Counter(x['classification'] for x in labels)
n=len(labels);k=counts['direct_reply'];p=k/n;z=1.959963984540054
mid=(p+z*z/(2*n))/(1+z*z/n); half=z*math.sqrt(p*(1-p)/n+z*z/(4*n*n))/(1+z*z/n)
out={'seed':2026092507,'population':'current link_kind == reply','labeler':'Codex re-auditor, not human gold; labels from raw text, not source evidence flag','counts':counts,'supported_direct_precision':p,'wilson95':[mid-half,mid+half],'upper_bound_if_all_uncertain_direct':(k+counts['uncertain_direct_parent'])/n,'labels':labels}
(P/'fresh_reply60_labels.json').write_text(json.dumps(out,indent=2))
print({k:v for k,v in out.items() if k!='labels'})
