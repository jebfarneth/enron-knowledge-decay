import sys, json, pathlib, re
import pandas as pd
import pyarrow.dataset as ds
ROOT=pathlib.Path('/Users/jebfarneth/projects/enron-knowledge-decay')
OUT=pathlib.Path('/tmp/enron-reaudit-20260925.WVW9gE/text')
sys.path.insert(0,str(ROOT/'src'))
from enron_importance.validate_cleaning import compare, summary
from enron_importance.validate_threads import outcomes
from enron_importance.config import load_config
from enron_importance.clean import _MARKERS,reply_start,authored_text
from enron_importance.senders import template_of,structured_record
def emit(n,x): (OUT/n).write_text(json.dumps(x,indent=2,default=str))
m=pd.read_parquet(ROOT/'data/processed/messages.parquet')
raw=ds.dataset(ROOT/'data/interim/messages_raw.parquet')
def bodies(paths):
    f=raw.to_table(columns=['path','body'],filter=ds.field('path').isin(list(paths))).to_pandas()
    return dict(zip(f.path,f.body))
sample=m[m.link_kind=='reply'].sample(60,random_state=2026092507)
ids=set(sample.index)|set(sample.reply_to.astype(int))
b=bodies(m.loc[sorted(ids),'path'])
records=[]
for sid,(i,r) in enumerate(sample.iterrows()):
    p=m.loc[int(r.reply_to)]
    rec={'sample_id':sid,'index':int(i),'parent_index':int(r.reply_to),'evidence':r.link_evidence}
    for pre,x in [('child',r),('parent',p)]:
        rec[pre]={k:x[k] for k in ['path','sender','date','subject','authored','to','cc']}
        rec[pre]['body']=b[x.path]
    records.append(rec)
emit('fresh_reply60.json',records)
labels=pd.DataFrame(json.loads((ROOT/'audits/labels/thread_links_sample60.json').read_text())['labels'])
t=outcomes(labels,m)
t.to_json(OUT/'old_outcomes.json',orient='records',indent=2)
emit('old_outcome_counts.json',t.groupby(['classification','outcome','link_kind'],dropna=False).size().reset_index(name='count').to_dict('records'))
emit('counts.json',{'link_kinds':m.link_kind.value_counts(dropna=False).to_dict(),'structured':int(m.structured.sum()),'routine_short_kept':int((m.routine & ~m.routine_excluded).sum()),'analysis':int(m.analysis.sum())})
cfg=load_config()
paths=raw.to_table(columns=['path']).to_pandas()
paths=paths[paths.path.isin(set(m.path))].sample(cfg['validation']['sample_size'],random_state=cfg['validation']['seed'])
bb=bodies(paths.path)
frame=compare(paths.path.map(bb).reset_index(drop=True))
frame['path']=paths.path.to_numpy()
emit('cleaning_reproduced.json',summary(frame))
empty=frame[frame.ours_empty & ~frame.theirs_empty].copy()
empty['marker']=[next((j for j,p in enumerate(_MARKERS) if (z:=p.search(x)) and z.start()==reply_start(x)),None) for x in empty.raw]
emit('cleaning_empty_differences.json',empty.to_dict('records'))
emit('cleaning_empty_marker_counts.json',empty.marker.value_counts(dropna=False).to_dict())
emit('analysis_random100.json',m[m.analysis].sample(100,random_state=2026092508)[['path','sender','authored']].to_dict('records'))
emit('structured_random60.json',m[m.structured].sample(60,random_state=2026092509)[['path','sender','authored']].to_dict('records'))
profiles=pd.read_parquet(ROOT/'data/processed/senders.parquet').set_index('sender')
ff=m[m.sender.isin(profiles.index[profiles.feed]) & ~m.automated & m.analysis]
emit('feed_kept.json',ff[['path','sender','authored']].to_dict('records'))
emit('summary.json',{'all_kept_feed_analysis':len(ff),'empty_difference':len(empty),'ours_empty':int(frame.ours_empty.sum()),'theirs_empty':int(frame.theirs_empty.sum()),'both_empty':int((frame.ours_empty & frame.theirs_empty).sum()),'counts_empty_markers':empty.marker.value_counts(dropna=False).to_dict()})
print((OUT/'summary.json').read_text())
