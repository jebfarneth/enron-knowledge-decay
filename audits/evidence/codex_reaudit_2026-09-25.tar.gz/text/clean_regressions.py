import sys,json,pathlib,subprocess,types
P=pathlib.Path('/tmp/enron-reaudit-20260925.WVW9gE/text')
ROOT=pathlib.Path('/Users/jebfarneth/projects/enron-knowledge-decay')
sys.path.insert(0,str(ROOT/'src'))
from enron_importance.clean import authored_text
old=types.ModuleType('old_clean')
exec(subprocess.check_output(['git','show','8c595e7:src/enron_importance/clean.py'],cwd=ROOT,text=True),old.__dict__)
records={}
for x in json.loads((P/'fresh_reply60.json').read_text()):
    for k in ['child','parent']: records[x[k]['path']]=x[k]['body']
out=[]
for path,body in records.items():
    before=old.authored_text(body);after=authored_text(body)
    if before!=after:out.append({'path':path,'old_chars':len(before),'new_chars':len(after),'old':before,'new':after,'raw':body})
(P/'fresh_thread_clean_changes.json').write_text(json.dumps(out,indent=2))
older=json.loads(pathlib.Path('/tmp/enron-audit-20260925.Xj3qoO/clean_threads/manual_clean_sample200.json').read_text())
print(type(older),str(older)[:300])
out2=[]
for x in older:
    body=x.get('body',x.get('raw',''))
    before=old.authored_text(body);after=authored_text(body)
    if before!=after:out2.append({'path':x['path'],'old_chars':len(before),'new_chars':len(after),'old':before,'new':after,'raw':body})
(P/'old200_clean_changes.json').write_text(json.dumps(out2,indent=2))
print('Fresh thread sample unique',len(records),'changed',len(out),'longer',sum(x['new_chars']>x['old_chars'] for x in out))
print('Old200 changed',len(out2),'longer',sum(x['new_chars']>x['old_chars'] for x in out2))
