# Independent text, filtering, and thread re-audit evidence

Repository: `/Users/jebfarneth/projects/enron-knowledge-decay`, requested commit `1ab1b2bd714ee11dd4959132e97f0b9c95664cdb`. No repository files were changed by this sub-audit. Evidence directory: `/tmp/enron-reaudit-20260925.WVW9gE/text`. This supplements the root auditor's identity, graph, evaluation, provenance, and mutation checks.

## Commands and sampling

Commands below ran with the repository as working directory. Scripts and their outputs are preserved in this directory:

```sh
.venv/bin/python /tmp/enron-reaudit-20260925.WVW9gE/text/probe.py
.venv/bin/python /tmp/enron-reaudit-20260925.WVW9gE/text/label_threads.py
.venv/bin/python /tmp/enron-reaudit-20260925.WVW9gE/text/clean_regressions.py
.venv/bin/python /tmp/enron-reaudit-20260925.WVW9gE/text/targeted.py
.venv/bin/python /tmp/enron-reaudit-20260925.WVW9gE/text/label_analysis.py
.venv/bin/python /tmp/enron-reaudit-20260925.WVW9gE/text/routine_probe.py
.venv/bin/python /tmp/enron-reaudit-20260925.WVW9gE/text/clean_repro_light.py repro_a
.venv/bin/python /tmp/enron-reaudit-20260925.WVW9gE/text/clean_repro_light.py repro_b
```

`probe.py` reads current generated messages and independently selects raw bodies from `messages_raw.parquet`; its cleaning reproduction invokes current source functions on the selected raw records, not the committed cross-check JSON. It also reruns `validate_threads.outcomes` against the original 60 archived labels. Fresh samples: 60 current `link_kind == reply` links, seed **2026092507**; 100 current analysis messages, seed **2026092508**; 60 currently flagged structured records, seed **2026092509**. I inspected the raw child/parent pairs for the thread labels. Labels are independent **Codex judgments, not human gold**. Uncertain thread parents were explicitly retained as uncertain. Long analysis messages were inspected for visible provenance/automation/quote contamination, not exhaustively annotated at the character level.

Current reproduced flag counts (`counts.json`): **32,326 reply-kind links; 6,706 forward-kind links; 215,078 unlinked records; 3,113 structured records; 3,296 routine records not excluded; 167,970 analysis messages**.

## Relevant fix-verification table

| Response row | Claimed status/effect | Verified status and evidence |
|---|---|---|
| S1 account-level feed exclusion | Partly fixed; human feed messages kept; helpdesk/ipayit excluded whole | **Partly fixed, with an incorrect explanation.** All 11 feed-account messages retained in analysis were inspected: eight human messages and three machine alerts. The human material includes six Pete Davis messages and two ipayit replies, so ipayit is demonstrably not excluded whole. `feed_kept.json`; `senders.py:38–43,105–110`; response line 51. |
| S2 structured/personalized notices | Fixed; 3,113 flagged | **Count verified; only partly fixed as a coverage claim.** A fresh random 60 flagged records all appeared to be the intended structured records; I did not find a definite natural-corpus human false positive in that sample. Targeted inspection nevertheless found 16 machine/structured messages still in analysis, and the independent random 100 analysis sample found an explicitly automated message. See finding 3. |
| S3 repeated speech acts | Fixed; 3,296 short messages retained; only >4-word messages excluded | **Partly fixed; new length implementation bug.** The Boolean count is 3,296, but 503 contain more than four actual whitespace-separated words; 139 of those enter analysis. The function counts the truncated 80-character template, not the message. It also still excludes genuine requests, signed short replies, and distinct legal analyses sharing a boilerplate opening. See finding 1. |
| Inferred reply links | Partly fixed; 25/27 old direct replies retained as replies; 71% direct precision | **Both numerical claims reproduced for the old conditional sample.** Exactly 25/27 old direct replies retain the same parent and reply label. Of 35 old links retaining the same parent and current reply label, 25 are direct (71.43%). Fresh current sample: 43/60 supported direct (71.67%, Wilson 95% 59.23–81.49%); 13 definite non-direct, four uncertain. Partly fixed is appropriate; still unsuitable as unqualified response ground truth. |
| Quote truncation | Partly fixed; tighter Lotus/Received rules and new one-line rules | **Partly fixed, with new corpus regressions.** Original prose false-cut controls now survive; three original-sample cases improve. But two of the old 200 sampled messages now retain large quoted blocks, and two more such regressions occur in 120 raw messages from the fresh thread sample. Long wrapped recipient lists violate the tightened cc/Subject proximity rule. Inline/bottom-posted authored text still disappears. |
| Signature/copied-source leakage | Open | **Open verified.** All 41 previously confirmed sender-owned title-signature examples remain in analysis: 19 Kaminski Managing Director, one Beck Vice President, two Beck Chief Operating Officer, 19 Sue Nord Senior Director. `signature_retest.json`. |
| Cleaner agreement not gold | Fixed reporting; human span gold open | **Numerical/reporting change verified; accuracy not established.** The complete 5,000-sample JSON values reproduce: whitespace agreement 77.48%; empty 7.32% ours vs 3.54% ERP. The excess empty outputs mostly reflect forward stripping, but at least two inspected cases delete actual authored material. The residue metrics remain code-defined diagnostics, not independent span accuracy. |

## Major finding 1 — The short-speech-act exemption measures a truncated template; both long broadcasts survive and substantive repeated-prefix human work is discarded

**Code:** `senders.py:57–61` returns only the first 80 characters after salutation stripping, digit masking and whitespace normalization. `speech_act`, lines 119–121, counts words in that truncated template. `prepare.py:92–94` uses it to decide `routine_excluded`; lines 103–104 gate analysis. The response at line 53 and sender module description at lines 23–27 describe message length, not this prefix length.

**Reproduction:** `routine_probe.py:10–11` selects `routine & ~routine_excluded`, counts `authored.str.split().str.len()`, and archives every >4-word result in `speechact_truncation.json`. **503** purportedly short routine records contain >4 words; **139** enter analysis, **180** are internal, and the maximum analysis-record length is **1,739 words**. Some discrepancy can be due to salutations; the demonstrated separator/URL cases cannot. The 139 analysis records comprise 50 `no.address`, 45 `40enron`, 18 Avril Forster, 14 Tim Heizenrader, and 12 `enron.announcement` records.

Examples of long records exempted as short because the first 80 characters are a separator or long URL:

- `maildir/baughman-d/inbox/304.`: 1,067 words, beginning with a long divider then a weekend systems-availability bulletin.
- `maildir/baughman-d/inbox/356.`: 980 words; same mechanism.
- `maildir/beck-s/inbox/390.`: 434 words; same mechanism.
- `maildir/benson-r/inbox/116.`: 1,739 words; same mechanism.
- `maildir/causholli-m/deleted_items/106.`: 866-word external news digest relayed by Avril Forster, beginning with a long URL.

The converse failure remains: the template prefix does not distinguish routine boilerplate from substantive work. `routine_probe.py:6–9`, `routine_5to8words.json` finds **251 internal, non-automated, non-structured excluded records** with 5–8 template words, across **12 sender-template groups**. Examples independently read:

- **21 James Derrick requests**, e.g. `maildir/derrick-j/sent_items/112.`: “Please print the attachment. Thank you.”
- **27 Miyung Buster messages**, e.g. `maildir/dasovich-j/notes_inbox/1027.`: “Please see the attached articles:”.
- **24 Wendi LeBrocq messages**, e.g. `maildir/jones-t/inbox/1022.`: “Please see attached.” plus signature makes the template exceed four words.
- **16 Britt Davis substantive legal messages** share the opening “PRIVILEGED AND CONFIDENTIAL: ATTORNEY-CLIENT COMMUNICATION” and are removed. `maildir/sanders-r/all_documents/336.` contains a long, specific legal analysis after that boilerplate, not a repeated report body.

**Impact:** A proposed speech-act/topic model receives long institutional broadcasts as human speech while genuine requests and legal contributions are systematically censored by role-specific signatures and prefixes. The 3,296 “short repeated messages” claim is not an accurate description of the implemented population. This is a concrete bug plus a residual validity problem, not merely a threshold preference.

**Fix:** Calculate short-utterance length from the full cleaned body after separately defined signature handling, not a truncated template. Do not infer that all long messages with an identical prefix are routine: remove known boilerplate before template construction and compare sufficient body content. Add tests with an 80-character divider followed by a long bulletin, URL-plus-article, a signed short request, and two different legal bodies sharing a privilege notice. Recompute exclusions and report per-person/role retention before Phase 3.

## Major finding 2 — Tightened Lotus matching newly attributes quoted colleagues' text to the current sender

**Code:** `clean.py:33–36` now requires `cc:` or `Subject:` within at most two intervening lines after `To:`. Real Lotus recipient lists wrap across more lines. `authored_text:98–104` then fails to cut that entire quoted block.

**Reproduction:** `clean_regressions.py` loads the old cleaner with `git show 8c595e7:src/enron_importance/clean.py` and executes old and current functions on the same archived raw bodies. In the original 200-message quote sample, five outputs change: three improvements and **two new regressions** (`old200_clean_changes.json`):

- `maildir/hodge-j/all_documents/56.`: old **43** characters, current **1,359**. Julie Gomez's brief question is followed by retained John Hodge headers and corporate analysis.
- `maildir/jones-t/sent/6034.`: old **57**, current **1,090**. Tana Jones's own EZ-tag response is followed by a Parking and Transportation message and long recipient block.

Among the **120 raw messages** making up the fresh 60 child/parent pairs, two changes are both regressions (`fresh_thread_clean_changes.json`):

- `maildir/dasovich-j/notes_inbox/3435.`: **300 → 1,176** characters.
- `maildir/dasovich-j/notes_inbox/3440.`: **108 → 979** characters.

Both retain Susan Mara's quoted message because the `To:` header wraps over five lines before the `cc:`/`Subject:` header. The resulting colleague prose/signature is attributed to Tamara/James. The independent random 100 analysis sample additionally exposes retained quoted headers in `maildir/taylor-m/notes_inbox/1541.` and `maildir/lokay-m/sent/16.`; these were not counted as the historical-rule regression experiment.

**Impact:** This corrupts sender-authored text and topic/speech-act attribution, including potentially title/name leakage. The original literal “Received: from” and agenda false-cut controls do now survive (`clean_synthetic_retest.json`), so this is a tradeoff introduced by the tightening, not denial of that verified correction.

**Fix:** Parse folded header blocks with constrained, recognizable header fields instead of a two-line proximity heuristic. Preserve complete corpus regression fixtures with long To/Cc lists and corresponding prose negative controls. Require blinded span evaluation covering both false cuts and quote residue before claiming improved extraction.

## Major finding 3 — Structured/automation coverage remains incomplete; template uniqueness is not evidence of human authorship

**Code:** `senders.py:49–54` matches a small anchored list of exact openings; e.g. `CALENDAR ENTRY:` requires a colon, and the performance-review pattern requires “in the”. `automated_messages:105–110` treats a feed account's nonempty singleton template as non-automated. This is insufficient for unique error messages and personalized notices.

**Reproduction:** Exhaustively inspect `feed_kept.json` (11 analysis records retained from feed accounts). Three are machine alerts:

- `maildir/platter-p/deleted_items/13.`: Pete Davis, “No ancillary schedules…” followed by file-parsing logs.
- `maildir/williams-w3/bill_williams_iii/621.`: Pete Davis, response-file errors, ISO decline codes and CSV records.
- `maildir/skilling-j/inbox/1195.`: ipayit, inactive-employee invoice-routing notification.

Eight are human, including two ipayit Sally McAdams replies (`maildir/campbell-l/inbox/1057.`, `maildir/sturm-f/deleted_items/84.`), showing why restoring account-wide exclusion would lose genuine work. Response line 51's claim that ipayit is excluded whole is incorrect.

`targeted.py:19–20` extracts 65 candidate analysis messages using explicit automation/structured indicators; manual inspection confirms at least **16** (not all 65):

- **Seven performance-management system notices:** `hyvl-d/all_documents/2567.`, `kaminski-v/all_documents/11193.`, `may-l/inbox/471.`, `may-l/inbox/472.`, `may-l/inbox/670.`, `may-l/notes_inbox/5.`, `smith-m/inbox/171.` (all under `maildir/`). Wording varies to “Enron's”, reminder text, or other prefixes outside the regex.
- **Two colon-free calendar entries:** `maildir/nemec-g/notes_inbox/2242.`, `2435.`.
- **One automatically generated NEST account-creation notification:** `maildir/shapiro-r/all_documents/458.`.
- **Six daemon.extra leave approvals:** `maildir/zufferli-j/deleted_items/13.`, `14.`, `19.`, `20.`, `21.`, `89.`.

The independent random 100 analysis sample is not targeted to those regexes: it contains **one explicitly machine-generated** record, `maildir/bass-e/all_documents/701.`, sender Neal Winfree, whose body explicitly says “This in an automated e-mail” from a fantasy-sports service. It also contains two retained-quote cases, one copied news story (`dasovich-j/deleted_items/372.`), one contact/help boilerplate artifact (`williams-w3/contacts/2.`), two institutional announcements of uncertain automation, and one uncertain completion notice. The remaining 92 had no definite contamination identified by this inspection. Full labels: `analysis_random100_labels.json`. This is not a precise population contamination estimate or a claim that all 92 are clean.

Fresh random 60 currently flagged structured records showed no definite natural-corpus human false positive (`structured_random60_labels.json`). Synthetic controls in `structured_negative_controls.json` show broad prefixes can nevertheless flag human prose (“Task assignment: please call me…” etc.); these are boundary tests, not evidence of observed corpus prevalence.

**Impact:** Topic ownership and speech-act frequency can be driven by syndicated reports, system records, and role-mailbox activity. A 3,113 flag count establishes execution, not adequate precision/recall. This does not by itself establish that the low-volume residual alerts invalidate network centrality; it does require validation before person-text inference.

**Fix:** Build stratified human gold across flagged/unflagged messages, feed singleton/repeated templates, system aliases, high-volume unflagged senders, and pure human prose; evaluate both error directions. Expand structural detection to parse record formats and provenance markers rather than endless exact-prefix exceptions. Preserve human replies from mixed-use accounts, but do not use singleton status as evidence of authored content.

## Major finding 4 — Reply-kind links still have substantial parent and forward errors; fresh precision is about 72%, not response ground truth

**Code:** `threads.py:87–102` requires raw sender/recipient matching; it selects by quoted prefix location or latest addressed candidate. Addressing the prior sender or inheriting `Re:` suffices for `link_kind = reply`, even when the message is a forward/relay or a self-sent revision. Immediate quoted parents can remain missing/incorrectly selected. The 40-character causal-inversion guard compares the new authored prefix against the prior entire body (`89–90`), not exclusively its quoted portion.

**Fresh reproduction:** `fresh_reply60.json`, seed 2026092507; explicit labels/reasons in `fresh_reply60_labels.json`: **43 direct; 10 wrong immediate parent; two forwards/relays; one same-author update; four uncertain**. Supported direct fraction **43/60 = 71.67%**, Wilson 95% **59.23–81.49%**. Treating all four uncertain as direct gives **47/60 = 78.33%**, not certainty. This interval is a descriptive simple-binomial interval for a small AI-labelled message sample; person/thread clustering and annotation error are not included.

Examples:

- `maildir/campbell-l/inbox/995.` → `994.`: Jae Black revises his own invitation, self included among recipients; counted as a reply.
- `maildir/kaminski-v/sent/4441.` → `4442.`: Kaminski forwards his own prior reply to assistant Shirley with an instruction; inherited `Re:` makes it reply-kind.
- `maildir/hyvl-d/all_documents/7.` → `6.`: Schneider asks Tom Shelton to answer Dan Hyvl, copies Dan, and forwards Dan's message; this is a relay, not Schneider's direct answer.
- `maildir/dasovich-j/notes_inbox/3435.` → `3440.`: child addresses and first-quotes Susan Mara's 12:28 message; selected parent is James Steffes's 12:48 sibling response.
- `maildir/symes-k/sent/893.` → `all_documents/2351.`: child first-quotes a March 16 missing-trade question; parent selected is March 8 different broker claims.

**Old sample reproduction and losses:** `old_outcomes.json` confirms 25/27 old direct replies retain the same parent and reply label. The 71% response claim uses the **35 old same-parent links that still receive reply-kind**, of which 25 are direct (25/35 = 71.43%). It is conditional on the pre-fix sample and retained parent, not a fresh validation set. One formerly correct link becomes forward-kind: `maildir/watson-k/inbox/200.` → `maildir/mcconnell-m/tw_projects/misc_tie_ins/6.` (a technical answer to a delegated request, inherited FW). Another formerly correct immediate parent changes: `maildir/sager-e/notes_inbox/448.` formerly → `396.`, now → `391.`; the old 396 text is directly quoted. I did not retrieve/read the new 391 raw body after the memory-limited follow-up was stopped, so report the lost old-correct link without a stronger assertion about every aspect of the replacement.

**Synthetic boundary check:** `targeted.py:21–25`, `synthetic_causal_guard.json` constructs a genuine reply which begins with the same >40-character instruction as the parent. Both records are unlinked because the repeated sentence occurs in the parent's own body. This proves an overbroad guard can reject a valid case; corpus prevalence is unverified.

**Impact:** Reply latency, responsiveness, brokerage via replies, or speech-act supervision must not assume these edges identify actual direct responses. The response document's “partly fixed” status is fair, but reporting only an improvement on the original sample hides the practical remaining error rate.

**Fix:** Resolve identities/aliases before recipient matching; separate forwarding/relay semantics from inherited subject prefixes; compare causal inversions to quoted content rather than any prior body; keep unresolvable immediate parent cases explicitly uncertain. Human-adjudicate a new blinded set and estimate precision plus recall before using response-based outcome variables.

## Minor finding 5 — Timestamp-shifted probable copies remain eligible for thread reconstruction

**Code:** `prepare.py:99` supplies `~automated & ~structured` eligibility to threading, while the analysis mask at 103–104 additionally excludes probable copies. Thread logic consequently operates on messages that the new dedupe rule removes from text/network analyses.

**Evidence:** `targeted.py:8–10`, `copies_linked.json`: **45 links have a probable-copy child; 56 a probable-copy parent; 91 involve either; 67 are reply-kind**. Example `maildir/beck-s/sent_items/155.` links to probable copy `maildir/beck-s/europe/5.`; `maildir/brawner-s/sent_items/2.` links to probable copy `maildir/williams-w3/inbox/56.`.

**Impact:** Artificial shifted records can alter parent selection, delay estimates, and thread grouping despite being excluded elsewhere. The count does not establish that all 67 response links are wrong, because some flags may be real resends.

**Fix:** Thread canonical dedupe families or explicitly report uncertainty; test invariance when a flagged whole-hour copy is added. Keep family assignment consistent across data splits.

## Cleaning cross-check reproduction and empty-output explanation

`cleaning_reproduced.json` exactly reproduces every numerical field of the current committed JSON on the 5,000-message configured sample: agreement **0.7748**, median token Jaccard **1**, Jaccard >=.9 **0.805**, ours empty **0.0732**, ERP empty **0.0354**, median fraction kept **1** for both. Residue: Original Message **.0008 vs .0200**; Forwarded marker **.0004 vs .0598**; quoted headers **.0170 vs .0782**; angle quotes **0 vs .0006**.

Empty-output totals: **366 ours**, **177 ERP**, **155 both**, hence **211 ours-only empty** and **22 ERP-only empty**. Among the 211 ours-only cases, the first-cut marker is **189 Lotus-forward banners; 12 Outlook separators; five Lotus headers; four transport headers; one On…wrote** (`cleaning_empty_marker_counts.json`). The excess is thus largely expected removal of forwarded source material, not proof that 7.32% of all sample messages lost original authored prose. I inspected the 22 non-Lotus-forward cases and a fresh random 20 of the 189 Lotus-forward cases (seed 2026092510).

At least two confirmed genuine-author losses remain:

- `maildir/beck-s/sent_items/87.`: Sally Beck fills out a quoted Outlook-migration questionnaire with personal work details and delegation preferences. Current cleaner returns empty, because answers occur inside the forwarded form.
- `maildir/richey-c/deleted_items/23.`: a technical answer after an `On … wrote` quote is discarded, including “The answer is summary(g)$coef[,3:4]”. This is an external mailing-list example, not an internal analysis message; it demonstrates the extraction limitation, not its analysis-population prevalence.

The new report avoids treating agreement as gold, but comparisons against the same header-marker families used to design the cleaner cannot establish independent accuracy. A fairer study would blind human annotators to system outputs, mark authored/quoted spans including inline answers, score span precision/recall, and stratify by formatting system, thread depth and message type. The existing empty-cleaner negative control exposes one degeneracy but does not substitute for that study.

### Separate-process byte reproducibility

`clean_repro_light.py` independently selects the same 5,000 raw paths in the same order, streams raw bodies in batches of 2,048, invokes current `compare`/`summary`, and writes the exact JSON and 40-lowest-Jaccard disagreement CSV formats to scratch. **Two separate processes both match each other and the committed artifacts byte-for-byte** (`repro_a/checksums.json`, `repro_b/checksums.json`):

- `cleaning_crosscheck.json`: 828 bytes; SHA-256 `4122f35a2dd476bb5dc3394ab97cd1f8898f825fe99dba3d976718c8a02e2c2a`.
- `cleaning_crosscheck_disagreements.csv`: 20,743 bytes; SHA-256 `cfca71c3c8a46409411188750314edc2971ba1d6369c10df8b673f48c1973ae4`.

This verifies determinism on the present environment and source, not independent accuracy of either cleaner.

## Phase 3 gates supported by this sub-audit

1. Correct the 80-character speech-act bug and assess retained/excluded fractions by sender and title before fitting any speech-act model.
2. Repair folded-header quote extraction and obtain independent span labels; ablate quoted-content removal uncertainty.
3. Mask names/signatures/contact details and compare title-only/identity-only models. All 41 old title-signature cases remain, and new retained quote blocks add other people's identities/titles.
4. Keep copied news, system bulletins and mixed-use mailbox records out of person-level ownership claims unless their provenance is modeled. Test sensitivity with all suspected machine/document records removed.
5. Do not train/evaluate on heuristic reply links as verified response labels. Obtain human linkage labels and report uncertainty; keep threads and probable-copy families within splits.

## Verification limits

- These are independent AI annotations, not a blinded human gold standard. Fresh samples are small; low apparent error in 60 flagged structured records does not establish complete precision.
- The cleaning JSON and disagreement CSV were reproduced byte-for-byte in two separate processes. The root auditor handles other reproducibility artifacts and environment reproducibility.
- A follow-up script, `thread_failure_reasons.py`, was deliberately terminated to relieve memory pressure before producing output. Its intended alias/date diagnosis and new parent 391 content are not evidence here.
- No corpus-wide false-cut or true-reply recall estimate was established; the known counterexamples and reported denominators should not be generalized beyond the inspected samples.
- Other root/sub-agent audits cover identity, formal ranks, network/evaluation, reproducibility and mutation tests; those results are not inferred from these text checks.
