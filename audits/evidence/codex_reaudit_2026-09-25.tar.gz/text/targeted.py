import sys,pathlib,json,re
import pandas as pd
P=pathlib.Path('/tmp/enron-reaudit-20260925.WVW9gE/text');R=pathlib.Path('/Users/jebfarneth/projects/enron-knowledge-decay');sys.path.insert(0,str(R/'src'))
from enron_importance.clean import authored_text
from enron_importance.threads import link_replies
from enron_importance.senders import template_of,speech_act,structured_record
def emit(n,x):(P/n).write_text(json.dumps(x,indent=2,default=str))
m=pd.read_parquet(R/'data/processed/messages.parquet',columns=['path','sender','subject','date','authored','analysis','automated','structured','routine','routine_excluded','probable_copy','probable_copy_of','reply_to','link_kind','to','cc'])
links=m[m.reply_to.notna()].copy();links['parent_copy']=m.loc[links.reply_to.astype(int),'probable_copy'].to_numpy();links['parent_path']=m.loc[links.reply_to.astype(int),'path'].to_numpy()
emit('copies_linked.json',{'child_copy':int(links.probable_copy.sum()),'parent_copy':int(links.parent_copy.sum()),'either':int((links.probable_copy|links.parent_copy).sum()),'reply_either':int(((links.probable_copy|links.parent_copy)&(links.link_kind=='reply')).sum()),'examples':links[links.probable_copy|links.parent_copy].head(30).to_dict('records')})
emit('analysis_random100.json',m[m.analysis].sample(100,random_state=2026092508)[['path','sender','authored']].to_dict('records'))
emit('structured_random60.json',m[m.structured].sample(60,random_state=2026092509)[['path','sender','authored']].to_dict('records'))
profiles=pd.read_parquet(R/'data/processed/senders.parquet').set_index('sender');ff=m[m.sender.isin(profiles.index[profiles.feed])&~m.automated&m.analysis]
emit('feed_kept.json',ff[['path','sender','authored']].to_dict('records'))
old=json.loads(pathlib.Path('/tmp/enron-audit-20260925.Xj3qoO/clean_threads/literal_signature_counts.json').read_text())
emit('signature_retest.json',{k:m[m.path.isin(v['paths'])][['path','sender','analysis','authored']].to_dict('records') for k,v in old.items()})
oldsynt=json.loads(pathlib.Path('/tmp/enron-audit-20260925.Xj3qoO/clean_threads/negative_controls.json').read_text())['synthetic_counterexamples']
emit('clean_synthetic_retest.json',{k:{'input':v['input'],'old':v['cleaned'],'current':authored_text(v['input'])} for k,v in oldsynt.items()})
candidate=m[m.analysis & m.authored.str.contains(r'(?i)(calendar entry|synchronizing|employee id:|performance management process|start date:|system generated|automated message|auto.generated)',regex=True)]
emit('machine_candidates.json',candidate[['path','sender','subject','authored']].to_dict('records'))
# A genuine repeated opening is not proof the prior message quotes the later message.
same='Please review the attached revised contract and send comments.'
rows=pd.DataFrame([{'sender':'a@enron.com','to':['b@enron.com'],'cc':[],'subject':'Contract','date':pd.Timestamp('2001-01-01',tz='UTC'),'body':same,'authored':same},
 {'sender':'b@enron.com','to':['a@enron.com'],'cc':[],'subject':'Re: Contract','date':pd.Timestamp('2001-01-02',tz='UTC'),'body':same+'\n\n-----Original Message-----\nFrom: A\nSent: yesterday\n'+same,'authored':same}])
emit('synthetic_causal_guard.json',link_replies(rows,14)[['reply_to','link_kind']].to_dict('records'))
print('targeted ready; feed kept',len(ff),'machine candidate',len(candidate))
