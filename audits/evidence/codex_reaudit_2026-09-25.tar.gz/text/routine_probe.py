import sys,pathlib,json,re
import pandas as pd
R=pathlib.Path('/Users/jebfarneth/projects/enron-knowledge-decay');P=pathlib.Path('/tmp/enron-reaudit-20260925.WVW9gE/text');sys.path.insert(0,str(R/'src'))
from enron_importance.senders import template_of,speech_act,structured_record,_SALUTATION
m=pd.read_parquet(R/'data/processed/messages.parquet',columns=['path','sender','authored','analysis','sender_internal','automated','structured','routine','routine_excluded'])
r=m[m.sender_internal & m.routine_excluded & ~m.structured & ~m.automated].copy();r['template']=r.authored.map(template_of);r['wordcount']=r['template'].str.split().str.len()
s=r[r.wordcount<=8]
groups=s.groupby(['sender','template']).agg(n=('path','size'),path=('path','first'),text=('authored','first')).reset_index().sort_values('n',ascending=False)
(P/'routine_5to8words.json').write_text(json.dumps({'messages':len(s),'groups':groups.to_dict('records')},indent=2))
oversize=m[m.routine & ~m.routine_excluded].copy();oversize['truewords']=oversize.authored.str.split().str.len();oversize=oversize[oversize.truewords>4]
(P/'speechact_truncation.json').write_text(json.dumps({'kept_short_but_actual_words_over4':len(oversize),'examples':oversize.to_dict('records')},indent=2))
# Corpus-independent boundary controls, not claims of natural corpus frequency.
controls=['Task assignment: please call me before accepting this project.','The report named: Q4 explains why I disagree with your valuation.','Thank you for changing lives. Your mentoring meant a great deal to me.']
(P/'structured_negative_controls.json').write_text(json.dumps([{'text':x,'structured':structured_record(x)} for x in controls],indent=2))
print('excluded5to8words',len(s),'groups',len(groups),'keptmislength',len(oversize))
