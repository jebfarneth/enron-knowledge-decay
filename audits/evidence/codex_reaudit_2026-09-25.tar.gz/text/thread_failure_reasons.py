import pathlib,sys,json
import pandas as pd
R=pathlib.Path('/Users/jebfarneth/projects/enron-knowledge-decay');P=pathlib.Path('/tmp/enron-reaudit-20260925.WVW9gE/text');sys.path.insert(0,str(R/'src'))
from enron_importance.dedupe import normalize_subject
m=pd.read_parquet(R/'data/processed/messages.parquet',columns=['path','sender','date','subject','to','cc','authored','reply_to','link_kind','probable_copy','automated','structured'])
s=json.loads((P/'fresh_reply60.json').read_text());sub={normalize_subject(s[i]['child']['subject']) for i in [1,4,17,23,26,31,42,51,53]}; f=m[m.subject.map(normalize_subject).isin(sub)]
(P/'wrong_parent_subject_groups.json').write_text(json.dumps(f.to_dict('records'),indent=2,default=lambda x:x.tolist() if hasattr(x,'tolist') else str(x)))
old=m[m.path.isin(['maildir/sager-e/notes_inbox/391.','maildir/sager-e/notes_inbox/396.','maildir/sager-e/notes_inbox/448.'])]
(P/'old_correct_link_lost.json').write_text(json.dumps(old.to_dict('records'),indent=2,default=lambda x:x.tolist() if hasattr(x,'tolist') else str(x)))
print('groups',len(f))
