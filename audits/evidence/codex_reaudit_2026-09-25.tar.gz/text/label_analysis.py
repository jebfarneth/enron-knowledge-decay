import json,pathlib,collections
P=pathlib.Path('/tmp/enron-reaudit-20260925.WVW9gE/text')
s=json.loads((P/'analysis_random100.json').read_text())
special={
2:('copied_third_party_text','News digest includes Times of India/Bloomberg bylines and copyright; not established as sender authored.'),
18:('contact_record_or_pasted_boilerplate','contacts folder and Customer Care activation/billing/coverage description, not ordinary interpersonal email.'),
21:('quoted_text_left_in','Craig Young dated To/cc/Subject block and preceding message remain after Alan Aronowitz own response.'),
27:('quoted_text_left_in','Shelley Corman dated To/cc/Subject block and huge recipient list remain after Count me in.'),
44:('institutional_notice_not_proven_automated','Leadership reception / United Way fundraising announcement jointly signed Mark and Greg; cannot infer machine generation.'),
45:('uncertain_machine_notification','Book request completion notice with number and fixed support phrasing; machine generation not independently established.'),
58:('explicit_machine_generated','Opening explicitly says automated e-mail from Commissioner.COM; fantasy football transaction notification under human sender address.'),
82:('institutional_notice_not_proven_automated','Enron in Action newsletter-format notice from40enron; collective source, machine generation not independently established.')}
labels=[]
for i,r in enumerate(s):
    c,e=special.get(i,('authored_prose_or_short_message','No definite machine or quotation contamination identified on this review.'))
    labels.append({'sample_id':i,'path':r['path'],'sender':r['sender'],'classification':c,'evidence':e})
out={'seed':2026092508,'n':100,'population':'analysis==True, 167970 messages','labeler':'Codex, not human gold; uncertain notifications not counted as confirmed automated','counts':collections.Counter(r['classification'] for r in labels),'labels':labels}
(P/'analysis_random100_labels.json').write_text(json.dumps(out,indent=2))
# All60 sampled structured records had report/calendar/task/sync schemas in their opening and record fields.
ss=json.loads((P/'structured_random60.json').read_text())
(P/'structured_random60_labels.json').write_text(json.dumps({'seed':2026092509,'n':60,'confirmed_structured':60,'observed_unambiguous_authored_prose_false_positive':0,'limitation':'Single AI review, not human gold; descriptive precision only, no recall estimate','paths':[r['path'] for r in ss]},indent=2))
print(out['counts'])
