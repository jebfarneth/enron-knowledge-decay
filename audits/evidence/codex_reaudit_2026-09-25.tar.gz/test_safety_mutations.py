from pathlib import Path
import json, pytest, importlib.util
import enron_importance.identity as identity
import enron_importance.dedupe as dedupe
import enron_importance.threads as threads
import enron_importance.senders as senders
R=Path('/Users/jebfarneth/projects/enron-knowledge-decay');S=Path('/tmp/enron-reaudit-20260925.WVW9gE')
def forbidden(*args,**kwargs):raise RuntimeError('DELIBERATELY BROKEN IMPLEMENTATION')
for m,names in [(identity,['resolve_people','resolve_recipient']), (dedupe,['deduplicate']),
                (threads,['link_replies']), (senders,['automated_messages','structured_record','speech_act'])]:
    for name in names:setattr(m,name,forbidden)
result=pytest.main([str(R/'tests/test_corpus_regressions.py'),'-q','-p','no:cacheprovider'])
(S/'corpus_mutation.json').write_text(json.dumps({'broken_functions':['resolve_people','resolve_recipient','deduplicate','link_replies','automated_messages','structured_record','speech_act'],
                                               'corpus_regression_pytest_exit':int(result)},indent=2)+'\n')
