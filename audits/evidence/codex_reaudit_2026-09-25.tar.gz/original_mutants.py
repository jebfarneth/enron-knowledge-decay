from pathlib import Path
import importlib.util,json
R=Path('/Users/jebfarneth/projects/enron-knowledge-decay');S=Path('/tmp/enron-reaudit-20260925.WVW9gE')
def load(name):
    spec=importlib.util.spec_from_file_location(name,R/'tests'/f'{name}.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
out={}
ev=load('test_evaluate');ev.bootstrap_interval=lambda *a,**k:(0.,1.)
try:ev.test_bootstrap_interval_is_computed_not_fixed();out['constant_interval_detected']=False
except AssertionError:out['constant_interval_detected']=True
im=load('test_identity');original=im.resolve_people
def first_mode(messages,*args,**kwargs):
    people,table,aliases=original(messages,*args,**kwargs)
    from enron_importance.identity import normalize_name
    first=messages.drop_duplicates('sender').set_index('sender').x_from.map(normalize_name)
    table['person_key']=table.address.map(first)
    return people,table,aliases
im.resolve_people=first_mode
try:im.test_address_takes_its_most_common_name_not_its_first();out['first_instead_of_mode_detected']=False
except AssertionError:out['first_instead_of_mode_detected']=True
(S/'original_mutants.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
