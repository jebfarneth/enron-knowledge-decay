# Network / evaluation re-audit evidence

Repository: `/Users/jebfarneth/projects/enron-knowledge-decay`, requested commit `1ab1b2bd714ee11dd4959132e97f0b9c95664cdb`. All outputs below live outside the repository. Production inputs were read-only. No source changes were made.

## Exact commands

Working directory for commands: `/Users/jebfarneth/projects/enron-knowledge-decay`.

```sh
PYTHONDONTWRITEBYTECODE=1 PYTHONHASHSEED=101 .venv/bin/python /tmp/enron-reaudit-20260925.WVW9gE/network/reproduce.py run1 > /tmp/enron-reaudit-20260925.WVW9gE/network/run1.log 2>&1
PYTHONDONTWRITEBYTECODE=1 PYTHONHASHSEED=202 .venv/bin/python /tmp/enron-reaudit-20260925.WVW9gE/network/reproduce.py run2 > /tmp/enron-reaudit-20260925.WVW9gE/network/run2.log 2>&1
PYTHONDONTWRITEBYTECODE=1 .venv/bin/python /tmp/enron-reaudit-20260925.WVW9gE/network/probes.py > /tmp/enron-reaudit-20260925.WVW9gE/network/probes.log 2>&1
PYTHONDONTWRITEBYTECODE=1 .venv/bin/python /tmp/enron-audit-20260925.Xj3qoO/network_eval/numeric_oracles.py > /tmp/enron-reaudit-20260925.WVW9gE/network/numeric_oracles.log 2>&1
PYTHONDONTWRITEBYTECODE=1 .venv/bin/python /tmp/enron-reaudit-20260925.WVW9gE/network/mutate_bootstrap.py > /tmp/enron-reaudit-20260925.WVW9gE/network/mutate_bootstrap.log 2>&1
PYTHONDONTWRITEBYTECODE=1 .venv/bin/python /tmp/enron-reaudit-20260925.WVW9gE/network/recipient_checks.py > /tmp/enron-reaudit-20260925.WVW9gE/network/recipient_checks.log 2>&1
PYTHONDONTWRITEBYTECODE=1 /tmp/enron-reaudit-20260925.WVW9gE/environment_project/.venv/bin/python /tmp/enron-reaudit-20260925.WVW9gE/network/all_metric_oracle.py
```

`reproduce.py` invokes unmodified `network.main`, `evaluate.main`, and both figure modules after redirecting their configuration paths to scratch. Existing input artifacts are read through symlinks; edges, centrality, three results CSVs, and four figure files are independently generated per run. Separate processes use different `PYTHONHASHSEED` values. Matplotlib uses the existing font cache from the first audit, avoiding stalled macOS font enumeration. Two initial processes that stalled in font discovery were terminated and replaced before any graph output existed; the successful reruns are the ones above.

### Protection against concurrent external edits

During the long exact-betweenness jobs, another process edited the live checkout (including `evaluate.py` and `config.yaml`) and began another evaluation. The two audit runners had already imported their network/evaluation/figure functions and loaded configuration at approximately 13:16, before those edits, so their function objects and config stayed pinned. Before their evaluation stage could read inputs again, `freeze_inputs.py` copied `formal_rank.parquet`, `identities.parquet`, `sender_people.parquet`, `funnel.json` and `messages.parquet` to `network/frozen_inputs/`, checked each against the audit-start `original_hashes.json`, and atomically redirected both scratch runs' links. **All five hashes match the initial snapshot.** See `freeze_inputs.log` and `frozen_inputs/verification.json`.

The runner script was then hardened **for future re-execution** to import the preserved `environment_project/src` and pinned configuration, and link only frozen inputs; this did not change the already compiled/in-flight runners. No later invocation of mutable live pipeline code is used to assess the requested commit. `compare_runs.py` compares output hashes to the initial inventory, not live files that the other process may overwrite. Earlier completed probe logs predate the external edits; their source references refer to the requested commit preserved in `environment_project/`.

## Fix / numerical verification

| Claim | Independent result | Assessment |
|---|---|---|
| Graph has 20,757 nodes; 5,606 people, 91 roles, 305 lists, 14,755 unresolved address nodes | Exact counts reproduced from the generated graph, with 219,398 edges | Numerical counts correct; entity semantics still heuristic, with the minor issues below |
| Don Miller degree becomes 346 | Degree 346, out-strength 258, weighted in-strength 162.39808535544893 | Confirmed current value; identity agent separately verifies which messages should belong to him |
| Full graph edge construction and exact outgoing counts | Independent loop produces all 219,398 edge keys, identical floating weights and integer multiplicities; zero degree / outgoing-count differences | Confirmed; 188,126 eligible message rows, 157,527 contributing messages, total weight 157,527 |
| Self-loops, external addresses, placeholders excluded | Zero source==target edges; zero external address nodes; zero configured/automatically detected placeholder addresses as nodes | Confirmed syntactically; this does not validate every identity merge |
| Degree accuracy 65.5%, CI 57.8–72.8%, 6,235 pairs | 0.6549318364073777, [0.5774760451697613, 0.7279151857661923], 129 people / 6,235 pairs | Confirmed by independent scalar pair oracle and multiplicity-weight bootstrap |
| Paired degree–PageRank difference 3.7 points, interval −0.6 to 7.8 | 0.03744987971130714, [−0.005591058442839949, 0.07819664861097912] | Confirmed using the same independently reconstructed person draws |
| Recipient-limit degree 62.9% / 65.5% | At most 10: 0.628869286287089; at most 50: 0.6546912590216519 | Independently recomputed adjacency sets; 141,043 / 153,975 contributing messages respectively |
| People-only graph degree 67.2% | 0.6716118684843625, CI [0.5952094743891327, 0.7431714055951107] | Confirmed as an induced subgraph; 5,548 nodes with retained edges |
| Person bootstrap correctly handles repeated sampled people | All 1,000 degree draws equal a distinct-original-pair oracle weighted by `c_i*c_j`; max difference 0 | Confirmed. Repeated people in the bootstrap are not a bug |
| Pairwise ordering / ties | All 729 three-person integer level/score combinations match independent scalar enumeration; all actual five score matrices are antisymmetric after tolerance | Confirmed on these cases. Initial synthetic threshold probes found no disagreement |
| PageRank implementation | Independent NumPy full-graph power iteration converges in 113 iterations; maximum absolute difference 4.09279814900243e-14, total probability 0.9999999999999999 | Confirmed numerically |
| Exact inverse-weight undirected betweenness | Re-ran the original independent exhaustive-path probe: 30 five-node graphs, max error 0 | The unmodified code uses `undirected.betweenness(weights=1/weight, directed=False)` without cutoff or sampling. Full-size separate-process reproduction is reported below; there was no second independent full-size Brandes implementation |

Relevant source: `network.py:45–73` edge construction; `network.py:76–92` centrality; `network.py:95–115` message filter / resolver; `evaluate.py:34–85` scoring / bootstrap; `evaluate.py:89–98` paired differences; `evaluate.py:123–150` sensitivity graphs.

The final lightweight `all_metric_oracle.py` imports no pipeline modules. It reconstructs the title table from frozen inputs, enumerates scalar pair credits for all five reproduced score vectors, and independently weights each pair by bootstrap multiplicities. All five accuracies and 95% intervals match the reproduced CSV to its stored precision; raw values are in `all_metric_oracle.json`. In-strength accuracy is **0.6125100240577386**, outgoing count **0.522373696872494**, and betweenness **0.5738572574178027**. This verifies evaluation arithmetic conditional on reproduced scores; the graph calculations have their separate checks above.

### Byte reproducibility

Both separate-process runs completed the full graph, exact betweenness, all evaluations and both figures, with `PYTHONHASHSEED=101` and `202`. **All nine outputs are byte-identical between runs and to the audit-start artifacts**: edges, centrality, the three baseline CSVs, and both figures in PDF and PNG. Parquet tables are also elementwise equal, with maximum numeric differences zero. Evidence: `comparison.json`, `comparison.log`, both run directories' `hashes.json`, and `run1.log`/`run2.log`. Run 1's network finished after 1,437.0 seconds wall and evaluation after 1,586.9; run 2's network finished after 2,121.6 and evaluation after 2,222.2, including its deliberate pause. These are audit execution durations under contention, not performance benchmarks.

Exact comparison command (pinned environment, no live pipeline imports):

```sh
PYTHONDONTWRITEBYTECODE=1 /tmp/enron-reaudit-20260925.WVW9gE/environment_project/.venv/bin/python /tmp/enron-reaudit-20260925.WVW9gE/network/compare_runs.py > /tmp/enron-reaudit-20260925.WVW9gE/network/comparison.log
```

The main reproduced evaluation CSV contains degree **0.6549 [0.5775,0.7279]**; PageRank **0.6175 [0.5391,0.6884]**; in-strength **0.6125 [0.5337,0.6844]**; betweenness **0.5739 [0.4880,0.6476]**; outgoing messages **0.5224 [0.4399,0.6001]**. Every row has 129 people and 6,235 different-level pairs. Sensitivity degree ranges from **0.6034** (CEO and President removed) to **0.6716** (people-only induced graph); disputed labels removed **0.6653**, old conflicting higher-title policy **0.6507**.

## Findings

### Minor: the people-only sensitivity silently changes "messages sent" into retained fractional weight

**Source:** `evaluate.py:143–148` constructs the induced people-only graph by filtering already weighted edges, passes `sent=None`, and `network.py:83–84` then computes weighted out-strength. This differs from `network.py:19–21` and the main figure's "Email sent (messages)" definition.

**Reproduction:** `probes.py`, sections `PEOPLE_ONLY_DEFINITION` / `PEOPLE_ONLY_FRACTIONAL_OUT` in `probes.log`. The people-only induced graph has 3,085 nodes with noninteger outgoing values and total outgoing weight **146,071.46716686606**, although **150,797 distinct messages** from person-typed sources reach at least one person-typed recipient. Its reported outgoing accuracy is **0.5272654370489174**. Counting those messages gives **0.5269446672012831**, CI **[0.4448883668777607, 0.6057619892551313]**. If weights are instead renormalized among retained people per message, in-strength accuracy is **0.6123496391339214** rather than **0.6139534883720931**, and PageRank is **0.6147554129911789** rather than **0.6142742582197274**. Degree is **unchanged** at **0.6716118684843625**.

**Impact:** This is an undisclosed estimand/normalization difference, not a failure of the 67.2% degree claim. The existing result is a valid weighted induced-subgraph statistic, but cannot simultaneously be described as a count of sent messages. Differences in weighted-measure sensitivity mix graph-node exclusion and fractional-weight retention.

**Fix:** Explicitly name the variant an induced weighted subgraph and label its outgoing measure retained weighted mass; or rebuild from messages with only person targets, re-normalize weights and pass exact message counts. Preserve and report both definitions if useful. Add a test where a message has one person and one non-person recipient.

### Minor: ambiguous sender-only identities are incorrectly typed as people

**Source:** `network.py:123–126` builds `ambiguous` only from the address-level table. `identity.py:189–197` can retain an ambiguous first/last key at message level without that key winning the modal address table.

**Evidence:** `recipient_checks.py` / `recipient_checks.log`, plus `typing_check.log` and `ambiguous_edges.log`. The address table has **zero ambiguous rows**, but sender-level assignments contain one **mark palmer** and one **mark taylor** without resolved middle initial. Both graph rows have `entity_type="person"`, degree 1 and out-strength 1. The only edges are `mark palmer → corp.officers@enron.com` and `mark taylor → nymex.list@enron.com`, each weight 1 / one message. The identity auditor separately confirmed that these are unresolved message-level homonyms.

**Impact:** The claimed person count includes these two ambiguous keys. They do **not** change the people-only degree score because neither has a person-typed neighbor. Nevertheless, treating them as resolved people is unsafe for subsequent person-level text features or splits.

**Fix:** Persist the complete ambiguous-key set or message-level resolution/type/provenance, and use it to type every graph vertex—not just keys that won an address-level mode.

### Minor: README's unresolved-address description is false

**Source:** `README.md:87–89` describes all 14,755 unresolved internal addresses as having "never sent mail". `network.py:95–101` permits unresolved internal senders, as designed.

**Evidence:** `recipient_checks.py` / `recipient_checks.log`: **119** address-typed nodes have positive outgoing message counts; **126** occur in the internal-sender identity table. Examples include `mona.l.petrochko@enron.com` (30 sent messages), `sap_security@enron.com` (62), `eserver@enron.com` (84), and `bodyshop@enron.com` (5). This is not merely an abstract possibility.

**Impact / fix:** Counts are right, description is not. Describe them as unresolved addresses, some recipient-only and some unresolved senders; report the two categories separately. Do not imply that missing outgoing messages is their common defining property.

### Test gap: the new bootstrap fixtures still permit a non-bootstrap implementation

**Source:** `tests/test_evaluate.py:26–33` only checks determinism and bracketing for a mixed sample. `tests/test_evaluate.py:43–46` checks exact endpoints only for perfect and reversed scores.

**Reproduction:** `mutate_bootstrap.py` replaces `evaluate.bootstrap_interval` in memory with:

```python
p = evaluate.pairwise_accuracy(levels, scores)
return (p, p) if p in (0.0, 1.0) else (0.0, 1.0)
```

All **9 tests in `tests/test_evaluate.py` pass**. For their actual mixed fixture, the correct interval is **(0.7165548823353078, 0.8563473352050488)**; the mutant returns **(0,1)** without resampling. Log: `mutate_bootstrap.log`. No production file was modified.

**Impact:** The old unconditional `(0,1)` mutant is now caught, so the narrow regression is fixed. The broader assertion that confidence-interval computation is tested remains overstated. This is a coverage defect, **not** evidence that the current production bootstrap is incorrect: the independent oracle above confirms its 1,000 draws.

**Fix:** Assert a predetermined nontrivial interval and/or compare draws to an independent multiplicity-weight oracle; test seed/repetition changes on a nondegenerate dataset. Similar tests should check nontrivial paired differences rather than only identical and perfectly reversed score vectors.

### Minor: the new relative-tie rule can change accuracy when rows are permuted

**Source:** `evaluate.py:34–37` applies `np.isclose(a,b,rtol=1e-9,atol=0)` and then `pairwise_accuracy` uses only the upper triangle. NumPy's relative tolerance uses the second argument's magnitude, so closeness need not be symmetric.

**Exact command:**

```sh
PYTHONDONTWRITEBYTECODE=1 .venv/bin/python /tmp/enron-reaudit-20260925.WVW9gE/network/tolerance_checks.py > /tmp/enron-reaudit-20260925.WVW9gE/network/tolerance_checks.log 2>&1
```

**Evidence:** For `levels=np.array([0,1])` and `scores=np.array([17.80489355345007,17.804893571254965])`, production accuracy is **0.5**. Reversing both arrays (the exact same two people) yields **1.0**. A broader vectorized search with seed **214650**, 100,000 uniform bases on [0.1,100], and the second score constructed as `base*(1+1e-9)` finds **220** such boundary cases. These are constructed boundary tests, **not** a 0.22% corpus-error estimate.

**Impact:** The metric is not generally permutation invariant, and could theoretically count a pair differently depending on bootstrap order. There is **no demonstrated effect on the current results**: among the 6,235 different-level pairs in each of the five actual score vectors, **zero** nonexact pairs are classified as ties, and all actual tolerance sign matrices are antisymmetric.

**Fix:** Use a symmetric definition, e.g. `abs(a-b) <= rtol*max(abs(a),abs(b))`, and test the metric on both permutations of an exact threshold-boundary fixture. This residual issue does not undo the verified fix to integer outgoing counts or the ordinary floating-point tie example.

## Recomputed custodian controls (original concern remains open)

Same proxy definition as the prior audit: map raw `sent`, `sent_items`, `_sent_mail`, `_sent` folder messages through the current address table, choose each custodian's modal sender, and add named Kenneth Lay / Jeffrey Skilling alongside dominant delegated senders. This is a proxy for mailbox availability, not independently verified ownership for every mailbox.

Evidence: `probes.py`, `probes.log`, `custodian_owners.csv`, `custodian_ranked_dominant_plus_named_executives.csv`, `custodian_baselines_dominant_plus_named_executives.csv`.

- **149** identified access-proxy people; **104/129** labelled people overlap.
- Degree: **0.6549318364073777**, CI **[0.5774760451697613, 0.7279151857661923]**.
- Custodian indicator: **0.4331194867682438**, CI **[0.3844300475613099, 0.4787386091432197]**.
- Raw mailbox-file count: **0.49045709703287893**, CI **[0.40391266805074033, 0.5685758874332347]**.
- Median degree is **197** among proxy owners and **3** elsewhere; labelled-person Spearman correlation between degree and mailbox size is **0.5916677038495535**.
- In the 104 labelled access-proxy people: degree accuracy **0.7044270833333334** on **3,840** pairs; in the other 25: **0.6406926406926406** on **231** pairs.
- Without adding the two named executives: 147 proxy people, 102 labelled overlaps; indicator **0.4130713712910986**, mailbox size **0.4600641539695269**.

Thus these two trivial availability predictors do **not** reproduce degree's accuracy. Mailbox selection still produces severe visibility imbalance; the correlation / medians are not proof that all rank recovery is an artifact. Keep the issue **open**, implement mailbox-aware and leave-mailbox-out sensitivity, and do not generalize the 129-person title evaluation to all employees.

## Other checked limits / additional evidence

- Small reporting inconsistency: actual PageRank accuracy is **0.6174819566960705**, correctly **61.7%** in `README.md:94`; the rounded CSV stores **0.6175**, so `figures/baselines.py:36` formats the plotted point as **61.8%**. Evidence `rounding_check.log`, obtained by calling `pairwise_accuracy` on the current ranked table and extracting `[t.get_text() for t in draw(pd.read_csv("results/baselines_formal_rank.csv")).axes[0].texts]`. Plot text is `['chance','52.2%','57.4%','61.3%','61.8%','65.5%']`. This is double rounding, not a substantive result difference. Preserve sufficient precision in the CSV and round only for display.

- `recipient_only_matches.csv` contains **275 recipient-only addresses**, representing **5,659 address/message mentions**, that the fallback maps to known people in eligible network rows. These were supplied to the identity auditor for semantic checks; syntax alone does not validate them.
- `semantic_self_edges.json` contains **22** cases where the same raw sender address appears as recipient but resolves to a different key (20 Mark A/E Taylor, 2 Mark/Dana Davis). These are **candidates, not established false edges**: a shared/export-normalized address may genuinely represent two people; recipient display headers must be checked before calling them self-copies.
- Source sorting and byte reproducibility address fixed-input reproducibility, not robustness to alternative identity/filtering decisions.
- The person bootstrap samples this selected labelled population; it does not correct mailbox-availability bias, shared-message network dependence, uncertain titles, or identity errors.
