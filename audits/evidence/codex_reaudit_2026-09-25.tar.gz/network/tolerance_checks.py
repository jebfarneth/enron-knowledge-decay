from pathlib import Path
import os,json,itertools
os.environ['MPLCONFIGDIR']='/tmp/enron-audit-20260925.Xj3qoO/network_eval/mpl'
import numpy as np,pandas as pd
from enron_importance.evaluate import label_table,attach,pairwise_accuracy,BASELINES
p=Path('/Users/jebfarneth/projects/enron-knowledge-decay/data/processed')
r=attach(label_table(pd.read_parquet(p/'formal_rank.parquet')),pd.read_parquet(p/'centrality.parquet'))
for m in BASELINES:
    x=r[m].to_numpy();lev=r.level.to_numpy();mask=np.triu(lev[:,None]!=lev[None,:],1)
    close=np.isclose(x[:,None],x[None,:],rtol=1e-9,atol=0)&(x[:,None]!=x[None,:])&mask
    ii,jj=np.where(close)
    print(m,{'nonexact_tied_pairs':len(ii),'examples':[{'a':r.iloc[i].person_key,'b':r.iloc[j].person_key,'a_score':float(x[i]),'b_score':float(x[j]),'abs_gap':float(abs(x[i]-x[j]))} for i,j in zip(ii[:15],jj[:15])]},flush=True)
# Vectorized numerical search for comparator-asymmetry boundary cases.
rng=np.random.default_rng(214650);a=rng.uniform(.1,100.,100000);b=a*(1+1e-9)
ab=np.isclose(a,b,rtol=1e-9,atol=0);ba=np.isclose(b,a,rtol=1e-9,atol=0);indices=np.where(ab!=ba)[0]
print('ASYMMETRIC_SYNTHETIC_BOUNDARIES',len(indices),flush=True)
for i in indices[:3]:
    x=np.array([a[i],b[i]]);lev=np.array([0,1])
    print({'scores':x.tolist(),'accuracy':pairwise_accuracy(lev,x),'permuted':pairwise_accuracy(lev[::-1],x[::-1])},flush=True)
