import os,sys
os.environ['MPLCONFIGDIR']='/tmp/enron-audit-20260925.Xj3qoO/network_eval/mpl'
import numpy as np,pytest
from enron_importance import evaluate
real=evaluate.bootstrap_interval
def bogus(levels,scores,reps,seed):
    p=evaluate.pairwise_accuracy(levels,scores)
    return (p,p) if p in (0.,1.) else (0.,1.)
rng=np.random.default_rng(0);levels=rng.integers(0,5,60).astype(float);scores=levels+rng.normal(0,1.5,60)
print('REAL',real(levels,scores,200,42),'MUTANT',bogus(levels,scores,200,42),flush=True)
evaluate.bootstrap_interval=bogus
sys.exit(pytest.main(['-q','-p','no:cacheprovider','tests/test_evaluate.py']))
