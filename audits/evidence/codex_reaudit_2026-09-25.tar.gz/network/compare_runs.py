from pathlib import Path
import hashlib,json,pandas as pd,numpy as np
base=Path('/tmp/enron-reaudit-20260925.WVW9gE/network');repo=Path('/Users/jebfarneth/projects/enron-knowledge-decay')
original=json.loads((base.parent/'original_hashes.json').read_text())
paths=['processed/edges.parquet','processed/centrality.parquet','results/baselines_formal_rank.csv','results/baselines_paired_differences.csv','results/baselines_sensitivity.csv','figures/fig01_data_funnel.pdf','figures/fig01_data_funnel.png','figures/fig06_baselines_formal_rank.pdf','figures/fig06_baselines_formal_rank.png']
rows=[]
for rel in paths:
    a=base/'run1'/rel;b=base/'run2'/rel;c=repo/(('data/'+rel) if rel.startswith('processed/') else rel)
    source_rel=('data/'+rel) if rel.startswith('processed/') else rel
    row={'file':rel,'run1_sha256':hashlib.sha256(a.read_bytes()).hexdigest(),'run2_sha256':hashlib.sha256(b.read_bytes()).hexdigest(),'initial_snapshot_sha256':original[source_rel]}
    row['two_runs_equal']=row['run1_sha256']==row['run2_sha256'];row['initial_snapshot_equal']=row['run1_sha256']==row['initial_snapshot_sha256']
    if rel.endswith('.parquet'):
        af=pd.read_parquet(a);bf=pd.read_parquet(b)
        row['dataframe_run_equal']=af.equals(bf)
        row['numeric_max_diffs']={col:float(np.abs(af[col].to_numpy()-bf[col].to_numpy()).max()) for col in af.select_dtypes('number')}
    rows.append(row)
(base/'comparison.json').write_text(json.dumps(rows,indent=2));print(json.dumps(rows,indent=2))
