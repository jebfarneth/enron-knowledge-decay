import os,itertools,json,hashlib
from pathlib import Path
from collections import defaultdict,Counter
os.environ['MPLCONFIGDIR']='/tmp/enron-audit-20260925.Xj3qoO/network_eval/mpl'
import numpy as np,pandas as pd
from enron_importance import network,evaluate
from enron_importance.config import load_config

root=Path('/Users/jebfarneth/projects/enron-knowledge-decay');out=Path('/tmp/enron-reaudit-20260925.WVW9gE/network')
cfg=load_config(); p=cfg['paths']['processed']
messages=network.network_messages(cfg); resolver=network.recipient_resolver(cfg)
edges=pd.read_parquet(p/'edges.parquet');measures=pd.read_parquet(p/'centrality.parquet')
ids=pd.read_parquet(p/'identities.parquet'); ranks=pd.read_parquet(p/'formal_rank.parquet')
ranked=evaluate.attach(evaluate.label_table(ranks),measures)
print('MAIN',{'messages':len(messages),'nodes':len(measures),'edges':len(edges),'node_types':measures.entity_type.value_counts().to_dict(),'ranked':len(ranked),'pairs':evaluate.different_level_pairs(ranked.level.to_numpy()),'zero_degree_labels':ranked.loc[ranked.degree==0,'person_key'].tolist()},flush=True)
print('ADDRESS_NODES_WITH_SENT',measures[(measures.entity_type=='address')&(measures.out_strength>0)].to_dict('records'),flush=True)
print('AMBIGUOUS_TYPES',ids[ids.entity_type=='ambiguous'].to_dict('records'),flush=True)
print('DON_MILLER',measures[measures.person_key=='don miller'].to_dict('records'),flush=True)
print('BAD_EDGES',{'selfloops':int((edges.source==edges.target).sum()),'external_address_nodes':[k for k in measures.person_key if '@' in k and not k.endswith('@enron.com')],'placeholder_nodes':list(set(ids[ids.entity_type=='placeholder'].address)&set(measures.person_key))},flush=True)

# Independent membership/weight/degree calculations; use the production resolver
# because identity resolution itself is under a separate independent audit.
all_weights=defaultdict(float);all_counts=Counter();sent=Counter();adj=defaultdict(set)
variant_adj={10:defaultdict(set),50:defaultdict(set),'people':defaultdict(set)}
variant_sent={10:Counter(),50:Counter(),'people':Counter()};people=set(measures.loc[measures.entity_type=='person','person_key'])
people_weights=defaultdict(float);renorm_weights=defaultdict(float);contributions=Counter()
for source,to,cc in messages[['sender_person','to','cc']].itertuples(index=False,name=None):
    if not isinstance(source,str):continue
    targets=set()
    for address in itertools.chain(to,cc):
        if not isinstance(address,str) or not address.endswith('@enron.com'):continue
        t=resolver(address)
        if isinstance(t,str) and t!=source:targets.add(t)
    if not targets:continue
    sent[source]+=1; contributions['all']+=1
    for target in sorted(targets):
        all_weights[(source,target)]+=1/len(targets);all_counts[(source,target)]+=1
        adj[source].add(target);adj[target].add(source)
    for lim in [10,50]:
        if len(targets)<=lim:
            variant_sent[lim][source]+=1;contributions[lim]+=1
            for target in targets:variant_adj[lim][source].add(target);variant_adj[lim][target].add(source)
    if source in people:
        kept=targets&people
        if kept:variant_sent['people'][source]+=1;contributions['people']+=1
        for target in kept:
            variant_adj['people'][source].add(target);variant_adj['people'][target].add(source)
            people_weights[(source,target)]+=1/len(targets)
            renorm_weights[(source,target)]+=1/len(kept)
observed={(s,t):(w,n) for s,t,w,n in edges.itertuples(index=False,name=None)}
print('INDEPENDENT_EDGES',{'same_keys':set(observed)==set(all_weights),'max_weight_diff':max(abs(w-observed[k][0]) for k,w in all_weights.items()),'count_mismatches':sum(n!=observed[k][1] for k,n in all_counts.items()),'degree_mismatches':sum(row.degree!=len(adj[row.person_key]) for row in measures.itertuples()),'out_count_mismatches':sum(row.out_strength!=sent[row.person_key] for row in measures.itertuples()),'contributing_messages':dict(contributions),'total_weight':edges.weight.sum()},flush=True)
for name,va in variant_adj.items():
    scores=ranked.person_key.map(lambda x:len(va[x])).to_numpy()
    counts=ranked.person_key.map(variant_sent[name]).fillna(0).to_numpy()
    print('VARIANT_ORACLE',name,{'nodes':len(va),'degree':evaluate.pairwise_accuracy(ranked.level.to_numpy(),scores),'outgoing_message_accuracy':evaluate.pairwise_accuracy(ranked.level.to_numpy(),counts)},flush=True)

# The people-only implementation is an induced weighted graph, not per-message
# reweighting among remaining people. Quantify the consequence without claiming
# one definition is uniquely correct.
keep=edges.source.isin(people)&edges.target.isin(people)
induced=network.centrality(edges[keep],betweenness=False)
renorm=pd.DataFrame([(s,t,w,1) for (s,t),w in sorted(renorm_weights.items())],columns=['source','target','weight','messages'])
renorm=network.centrality(renorm,pd.Series(variant_sent['people']),betweenness=False)
for name,variant in [('induced',induced),('renormalized',renorm)]:
    table=evaluate.attach(evaluate.label_table(ranks),variant)
    print('PEOPLE_ONLY_DEFINITION',name,evaluate.evaluation_table(table,['degree','in_strength','out_strength','pagerank'],1000,42).to_dict('records'),flush=True)
print('PEOPLE_ONLY_FRACTIONAL_OUT',{'nodes_noninteger':int((np.abs(induced.out_strength-induced.out_strength.round())>1e-9).sum()),'sum_weight':float(induced.out_strength.sum()),'true_contributing_messages':contributions['people']},flush=True)

# Scalar all-pairs oracle for all small integer cases, then bootstrap counted
# multiplicities c_i*c_j (no duplicated-person matrix).
def scalar(levels,scores):
    points=[]
    for i,j in itertools.combinations(range(len(levels)),2):
        if levels[i]==levels[j]:continue
        if abs(scores[i]-scores[j])<=1e-9*max(abs(scores[i]),abs(scores[j])):points.append(.5)
        else:points.append(float((levels[i]>levels[j])==(scores[i]>scores[j])))
    return float(np.mean(points)) if points else np.nan
checks=0
for lev in itertools.product([0,1,2],repeat=3):
    for scr in itertools.product([0,1,2],repeat=3):
        a=evaluate.pairwise_accuracy(np.array(lev),np.array(scr));b=scalar(lev,scr)
        assert (np.isnan(a) and np.isnan(b)) or a==b
        checks+=1
levels=ranked.level.to_numpy();scores=ranked.degree.to_numpy();pr=ranked.pagerank.to_numpy()
pairs=[(i,j) for i,j in itertools.combinations(range(len(levels)),2) if levels[i]!=levels[j]]
ii=np.array([i for i,j in pairs]);jj=np.array([j for i,j in pairs])
def correctness(x):return np.array([.5 if abs(x[i]-x[j])<=1e-9*max(abs(x[i]),abs(x[j])) else float((levels[i]>levels[j])==(x[i]>x[j])) for i,j in pairs])
degc=correctness(scores);prc=correctness(pr);rng=np.random.default_rng(42);draws=[];diffs=[];maxerr=0
for _ in range(1000):
    idx=rng.integers(0,len(levels),len(levels));counts=np.bincount(idx,minlength=len(levels));weights=counts[ii]*counts[jj]
    oracle=float(np.average(degc,weights=weights));diff=float(np.average(degc-prc,weights=weights))
    draws.append(oracle);diffs.append(diff)
    maxerr=max(maxerr,abs(oracle-evaluate.pairwise_accuracy(levels[idx],scores[idx])))
print('PAIR_BOOTSTRAP_ORACLE',{'small_cases':checks,'draws':1000,'max_bootstrap_difference':maxerr,'degree_accuracy':scalar(levels,scores),'degree_ci':np.percentile(draws,[2.5,97.5]).tolist(),'degree_minus_pagerank':float(np.mean(degc-prc)),'paired_ci':np.percentile(diffs,[2.5,97.5]).tolist()},flush=True)

# Assess asymmetric relative-tie comparator with an exact representable boundary.
found=[]
for base in [1e-12,1e-8,.001,1.,10.,100.,1e6,1e9]:
    target=base*(1+1e-9)
    for x in [target,np.nextafter(target,-np.inf),np.nextafter(target,np.inf)]:
        v=np.array([base,x]);a=evaluate.pairwise_accuracy(np.array([0,1]),v);b=evaluate.pairwise_accuracy(np.array([1,0]),v[::-1])
        if a!=b:found.append({'scores':v.tolist(),'ordered':a,'permuted':b,'isclose':np.isclose(v[:,None],v[None,:],rtol=1e-9,atol=0).tolist()})
print('TIE_ORDER_SYNTHETIC',found,flush=True)
print('TIE_ORDER_ACTUAL', {m:int((evaluate._sign_gap(ranked[m].to_numpy(),1e-9)!=-evaluate._sign_gap(ranked[m].to_numpy(),1e-9).T).sum()) for m in evaluate.BASELINES},flush=True)

# Same custodian control as prior audit, recomputed from current address map.
raw=pd.read_parquet(cfg['paths']['interim']/'messages_raw.parquet',columns=['custodian','folder','sender'])
mapping=dict(zip(ids.address,ids.person_key));raw['person_key']=raw.sender.map(mapping)
sentrows=raw[raw.folder.isin(['sent','sent_items','_sent_mail','_sent'])].dropna(subset=['person_key'])
c=sentrows.groupby(['custodian','person_key']).size().rename('n').reset_index()
owners=c.sort_values(['custodian','n','person_key'],ascending=[True,False,True]).drop_duplicates('custodian')
owners['mailbox_files']=owners.custodian.map(raw.custodian.value_counts())
owners.to_csv(out/'custodian_owners.csv',index=False)
for definition in ['dominant_sender','dominant_plus_named_executives']:
    o=owners.copy()
    if definition=='dominant_plus_named_executives':
        for cust,key in [('lay-k','kenneth lay'),('skilling-j','jeffrey skilling')]:
            o=pd.concat([o,pd.DataFrame([{'custodian':cust,'person_key':key,'mailbox_files':int(raw.custodian.value_counts()[cust])}])],ignore_index=True)
    sizes=o.groupby('person_key').mailbox_files.sum();r=ranked.copy()
    r['is_custodian']=r.person_key.isin(set(o.person_key)).astype(int);r['mailbox_files']=r.person_key.map(sizes).fillna(0)
    table=evaluate.evaluation_table(r,['degree','is_custodian','mailbox_files'],1000,42)
    table.to_csv(out/f'custodian_baselines_{definition}.csv',index=False)
    r.to_csv(out/f'custodian_ranked_{definition}.csv',index=False)
    print('CUSTODIAN_CONTROL',definition,{'identified':o.person_key.nunique(),'ranked_in_proxy':int(r.is_custodian.sum()),'baseline':table.to_dict('records'),'spearman':r[['degree','mailbox_files','level']].corr(method='spearman').to_dict(),'degree_by_access':measures.assign(has_access=measures.person_key.isin(set(o.person_key))).groupby('has_access').degree.agg(['count','median','mean']).to_dict()},flush=True)
    for value in [0,1]:
        sub=r[r.is_custodian==value]
        print('CUSTODIAN_SUBSET',definition,value,{'n':len(sub),'pairs':evaluate.different_level_pairs(sub.level.to_numpy()),'degree_accuracy':evaluate.pairwise_accuracy(sub.level.to_numpy(),sub.degree.to_numpy())},flush=True)
