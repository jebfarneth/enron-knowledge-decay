from pathlib import Path
from collections import Counter
import json,pandas as pd,pyarrow.parquet as pq
from enron_importance.identity import resolve_recipient
root=Path('/Users/jebfarneth/projects/enron-knowledge-decay');out=Path('/tmp/enron-reaudit-20260925.WVW9gE/network');p=root/'data/processed'
ids=pd.read_parquet(p/'identities.parquet');address_person=dict(zip(ids.address,ids.person_key));people=set(ids.loc[ids.entity_type=='person','person_key'])
authors=pd.read_parquet(p/'sender_people.parquet');author=dict(zip(authors.path,authors.sender_person));cache={}
def resolve(a):
    if a not in cache:cache[a]=resolve_recipient(a,address_person,people)
    return cache[a]
guessed=Counter();examples={};selflinks=[]
columns=['path','sender','x_from','to','cc','sender_internal','automated','structured','probable_copy']
for batch in pq.ParquetFile(p/'messages.parquet').iter_batches(batch_size=8192,columns=columns):
    for row in batch.to_pylist():
        if not row['sender_internal'] or row['automated'] or row['structured'] or row['probable_copy']:continue
        source=author.get(row['path'])
        if not isinstance(source,str):continue
        addresses=set(row['to']+row['cc'])
        for address in addresses:
            if not isinstance(address,str) or not address.endswith('@enron.com'):continue
            t=resolve(address)
            if address not in address_person and t != address and t is not None:
                guessed[(address,t)]+=1;examples.setdefault((address,t),row['path'])
        if row['sender'] in addresses and isinstance(resolve(row['sender']),str) and resolve(row['sender'])!=source:
            selflinks.append({'path':row['path'],'sender':row['sender'],'x_from':row['x_from'],'sender_person':source,'mapped_self_recipient':resolve(row['sender'])})
pd.DataFrame([{'address':a,'person_key':k,'messages':n,'example':examples[(a,k)]} for (a,k),n in guessed.most_common()]).to_csv(out/'recipient_only_matches.csv',index=False)
(out/'semantic_self_edges.json').write_text(json.dumps(selflinks,indent=2))
print('RECIPIENT_ONLY_MATCHES',len(guessed),'MENTIONS',sum(guessed.values()),flush=True)
print('SELF_ADDRESS_RECLASSIFIED_AS_OTHER',len(selflinks),selflinks[:25],flush=True)
c=pd.read_parquet(p/'centrality.parquet');a=c[c.entity_type=='address']
print('ADDRESS_COUNT',len(a),'POSITIVE_OUT',int((a.out_strength>0).sum()),'KNOWN_SENDER_ADDRESS',int(a.person_key.isin(ids.address).sum()),flush=True)
print('AMBIGUOUS_BASE_GRAPH',c[c.person_key.isin(['mark taylor','mark palmer','michael miller'])].to_dict('records'),flush=True)
