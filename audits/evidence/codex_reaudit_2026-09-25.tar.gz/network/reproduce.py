import os,sys,time,json,hashlib
from pathlib import Path
os.environ['MPLCONFIGDIR']='/tmp/enron-audit-20260925.Xj3qoO/network_eval/mpl'
# The first two executions imported the live checkout before outside edits.
# Re-execution now uses the preserved requested-commit source and frozen data.
sys.path.insert(0,'/tmp/enron-reaudit-20260925.WVW9gE/environment_project/src')
from enron_importance.config import load_config
from enron_importance import network,evaluate
from enron_importance.figures import funnel,baselines

root=Path('/Users/jebfarneth/projects/enron-knowledge-decay')
out=Path('/tmp/enron-reaudit-20260925.WVW9gE/network')/sys.argv[1]
out.mkdir(parents=True,exist_ok=True)
processed=out/'processed';processed.mkdir(exist_ok=True)
for source in Path('/tmp/enron-reaudit-20260925.WVW9gE/network/frozen_inputs').iterdir():
    if source.name not in ['edges.parquet','centrality.parquet']:
        target=processed/source.name
        if not target.exists():target.symlink_to(source)
config=load_config(Path('/tmp/enron-reaudit-20260925.WVW9gE/environment_project/config.yaml'));config['paths']['processed']=processed
config['paths']['results']=out/'results';config['paths']['figures']=out/'figures'
for module in [network,evaluate,funnel,baselines]:module.load_config=lambda:config
start=time.time()
network.main();print('NETWORK_DONE_SECONDS',time.time()-start,flush=True)
evaluate.main();print('EVALUATION_DONE_SECONDS',time.time()-start,flush=True)
funnel.main();baselines.main()
hashes={str(p.relative_to(out)):hashlib.sha256(p.read_bytes()).hexdigest() for p in out.rglob('*') if p.is_file() and not p.is_symlink()}
(out/'hashes.json').write_text(json.dumps(hashes,indent=2))
print(json.dumps(hashes,indent=2),flush=True)
