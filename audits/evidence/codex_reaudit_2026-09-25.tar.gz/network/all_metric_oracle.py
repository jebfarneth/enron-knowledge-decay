"""Independent scalar-pair / multiplicity-bootstrap check, without pipeline imports."""
from pathlib import Path
from itertools import combinations
import json
import numpy as np
import pandas as pd
import yaml

base = Path('/tmp/enron-reaudit-20260925.WVW9gE/network')
config = yaml.safe_load((base.parent / 'environment_project/config.yaml').read_text())
ranks = pd.read_parquet(base / 'frozen_inputs/formal_rank.parquet')
graph = pd.read_parquet(base / 'run1/processed/centrality.parquet').set_index('person_key')
labels = {}
for row in ranks.itertuples():
    if isinstance(row.person_key, str) and pd.notna(row.level):
        labels[row.person_key] = max(labels.get(row.person_key, -np.inf), row.level)
people = sorted(labels)
levels = [labels[p] for p in people]
pairs = [(i, j) for i, j in combinations(range(len(people)), 2) if levels[i] != levels[j]]
left, right = np.array(pairs).T
metrics = ['degree', 'in_strength', 'out_strength', 'pagerank', 'betweenness']
credits = []
for metric in metrics:
    scores = [float(graph.loc[p, metric]) if p in graph.index else 0.0 for p in people]
    credit = []
    for i, j in pairs:
        if abs(scores[i] - scores[j]) <= 1e-9 * max(abs(scores[i]), abs(scores[j])):
            credit.append(0.5)
        else:
            credit.append(float((levels[i] > levels[j]) == (scores[i] > scores[j])))
    credits.append(credit)
credits = np.array(credits)
rng = np.random.default_rng(config['random_seed'])
draws = []
for _ in range(config['evaluation']['bootstrap_reps']):
    counts = np.bincount(rng.integers(0, len(people), len(people)), minlength=len(people))
    weights = counts[left] * counts[right]
    draws.append((credits * weights).sum(axis=1) / weights.sum())
intervals = np.percentile(np.array(draws), [2.5, 97.5], axis=0)
actual = pd.read_csv(base / 'run1/results/baselines_formal_rank.csv').set_index('measure')
output = []
for k, metric in enumerate(metrics):
    values = {'accuracy': float(credits[k].mean()), 'ci_low': float(intervals[0, k]), 'ci_high': float(intervals[1, k])}
    output.append({'measure': metric, 'people': len(people), 'pairs': len(pairs), **values,
                   'all_fields_match_csv_precision': all(float(f'{v:.4f}') == actual.loc[metric, name] for name, v in values.items())})
(base / 'all_metric_oracle.json').write_text(json.dumps(output, indent=2))
print(json.dumps(output, indent=2))
