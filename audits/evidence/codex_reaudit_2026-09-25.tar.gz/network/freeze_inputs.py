from pathlib import Path
import hashlib,json,shutil,os
base=Path('/tmp/enron-reaudit-20260925.WVW9gE');root=Path('/Users/jebfarneth/projects/enron-knowledge-decay');out=base/'network/frozen_inputs';out.mkdir(exist_ok=True)
expected=json.loads((base/'original_hashes.json').read_text());records=[]
def digest(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        while b:=f.read(8*1024*1024):h.update(b)
    return h.hexdigest()
for name in ['formal_rank.parquet','identities.parquet','sender_people.parquet','funnel.json','messages.parquet']:
    source=root/'data/processed'/name;target=out/name
    shutil.copy2(source,target)
    actual=digest(target);pinned=expected['data/processed/'+name]
    assert actual==pinned,(name,actual,pinned)
    for run in ['run1','run2']:
        old=base/'network'/run/'processed'/name
        assert old.is_symlink(),old
        temporary=old.with_name(old.name+'.frozen-link')
        temporary.symlink_to(target)
        temporary.replace(old)
    records.append({'file':name,'sha256':actual,'matches_initial_snapshot':True})
    print(records[-1],flush=True)
(out/'verification.json').write_text(json.dumps(records,indent=2))
