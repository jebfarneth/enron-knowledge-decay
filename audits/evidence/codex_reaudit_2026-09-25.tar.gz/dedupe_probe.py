from pathlib import Path
import pandas as pd, pyarrow.parquet as pq, json, itertools, collections
from enron_importance.identity import resolve_recipient
R=Path('/Users/jebfarneth/projects/enron-knowledge-decay');S=Path('/tmp/enron-reaudit-20260925.WVW9gE')
p=R/'data/processed'
m=pd.read_parquet(p/'messages.parquet',columns=['path','content_key','sender','date','to','cc','probable_copy','probable_copy_of','analysis'])
ids=pd.read_parquet(p/'identities.parquet');mp=dict(zip(ids.address,ids.person_key));people=set(ids.person_key.dropna())
def rawrec(row):return set(row['to'])|set(row['cc'])
def resolved(rec):return {resolve_recipient(x,mp,people) if x.endswith('@enron.com') else x for x in rec}-{None}
multi=m[m.content_key.duplicated(False)]
groups=[]
for k,g in multi.groupby('content_key'):
    pairs=[]
    for (_,a),(_,b) in itertools.combinations(g.iterrows(),2):
        ra,rb=rawrec(a),rawrec(b);pa,pb=resolved(ra),resolved(rb)
        pairs.append({'a':a.path,'b':b.path,'raw_overlap':sorted(ra&rb),'raw_a':sorted(ra),'raw_b':sorted(rb),
                      'resolved_a':sorted(pa),'resolved_b':sorted(pb),'resolved_overlap':sorted(pa&pb),
                      'same_nonempty_resolved_set':bool(pa) and pa==pb})
    groups.append({'key':k,'paths':g.path.tolist(),'pairs':pairs})
copies=pd.read_parquet(p/'copies.parquet')
raw=pd.read_parquet(R/'data/interim/messages_raw.parquet',columns=['path','to','cc'])
rawmap=dict(zip(raw.path.tolist(),(set(a)|set(b) for a,b in zip(raw.to.tolist(),raw.cc.tolist()))))
copygroups=collections.defaultdict(list)
for path,keeper in zip(copies.path.tolist(),copies.kept_path.tolist()):copygroups[keeper].append(path)
loss=[]
for keeper,paths in copygroups.items():
    have=rawmap[keeper];other=set().union(*(rawmap[x] for x in paths));missing=other-have
    if missing:
        missing_internal={x for x in missing if x.endswith('@enron.com')}
        person_missing=resolved(other)-resolved(have)
        loss.append({'keeper':keeper,'copy_paths':paths,'retained':sorted(have),'missing':sorted(missing),
                     'missing_internal':sorted(missing_internal),'resolved_missing':sorted(person_missing)})
shift=m[m.probable_copy]
sample=shift.sample(n=60,random_state=2026092509)
wanted=set(sample.path)|set(sample.probable_copy_of)
# Inspect actual bodies only for the sampled flagged pairs, no full raw-body load.
body={}
for batch in pq.ParquetFile(R/'data/interim/messages_raw.parquet').iter_batches(batch_size=20000,columns=['path','body','x_from','subject','date','custodian','folder']):
    for r in batch.to_pylist():
        if r['path'] in wanted:
            r['date']=str(r['date']);body[r['path']]=r
samplepairs=[{'flagged':body[r.path],'earlier':body[r.probable_copy_of]} for r in sample.itertuples()]
summary={'kept_messages':len(m),'extra_separate_sends':len(multi)-multi.content_key.nunique(),
         'separate_send_groups':multi.content_key.nunique(),'separate_pair_count':sum(len(g['pairs']) for g in groups),
         'separate_pairs_with_resolved_overlap':sum(bool(x['resolved_overlap']) for g in groups for x in g['pairs']),
         'separate_pairs_same_resolved_recipient_set':sum(x['same_nonempty_resolved_set'] for g in groups for x in g['pairs']),
         'discarded_copies':len(copies),'keeper_missing':int((~copies.kept_path.isin(m.path)).sum()),
         'discarded_kept_overlap':len(set(copies.path)&set(m.path)),
         'remaining_recipient_loss_groups':len(loss),'remaining_raw_recipient_assignments_lost':sum(len(x['missing']) for x in loss),
         'remaining_internal_recipient_assignments_lost':sum(len(x['missing_internal']) for x in loss),
         'remaining_resolved_recipient_assignments_lost':sum(len(x['resolved_missing']) for x in loss),
         'remaining_resolved_loss_groups':sum(bool(x['resolved_missing']) for x in loss),
         'shifted_count':len(shift),'shifted_in_analysis':int(shift.analysis.sum()),
         'sample_seed':2026092509,'sample_size':60}
(S/'dedupe_summary.json').write_text(json.dumps(summary,indent=2)+'\n')
(S/'dedupe_separate_groups.json').write_text(json.dumps(groups,indent=2)+'\n')
(S/'dedupe_remaining_recipient_loss.json').write_text(json.dumps(loss,indent=2)+'\n')
(S/'shifted_sample60.json').write_text(json.dumps(samplepairs,indent=2)+'\n')
print(json.dumps(summary,indent=2),flush=True)
