from pathlib import Path
import sys, importlib.util, json, tempfile, pandas as pd, hashlib
from enron_importance.prepare import parsed_messages
R=Path('/Users/jebfarneth/projects/enron-knowledge-decay');S=Path('/tmp/enron-reaudit-20260925.WVW9gE')
spec=importlib.util.spec_from_file_location('test_prepare',R/'tests/test_prepare.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
T=Path(tempfile.mkdtemp(prefix='cache-probe-',dir=S));c=mod.build(T)
first=parsed_messages(c);cache=c['paths']['interim']/'messages_raw.parquet';stamp=cache.with_suffix('.json')
before=stamp.read_text();bad=first.iloc[:1].copy();bad['body']='POISONED CACHE TEXT';bad.to_parquet(cache,index=False)
second=parsed_messages(c)
out={'original_rows':len(first),'cached_after_edit_rows':len(second),'cached_body':second.iloc[0]['body'],
     'stamp_unchanged':before==stamp.read_text(),'stamp_fields':json.loads(before),'scratch_case':str(T)}
# Bypass the table with an unchanged archive/parser stamp but changed parser dependency behavior.
# The runtime patch simulates changed stdlib/dependency parsing without changing ingest.py.
import enron_importance.ingest as ingest
old=ingest.getaddresses
ingest.getaddresses=lambda values:[('','changed-parser-dependency@enron.com')]
third=parsed_messages(c)
uncached=list(ingest.iter_archive(c['paths']['raw']/c['corpus']['filename']))
out['dependency_patch_cached_sender']=third.iloc[0]['sender'];out['dependency_patch_uncached_sender']=uncached[0]['sender']
ingest.getaddresses=old
(S/'provenance_probe.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
