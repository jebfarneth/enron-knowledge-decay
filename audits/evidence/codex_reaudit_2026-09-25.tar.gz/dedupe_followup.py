from pathlib import Path
import pandas as pd, json,tarfile,re
from email import message_from_bytes
from enron_importance.dedupe import normalize_body
R=Path('/Users/jebfarneth/projects/enron-knowledge-decay');S=Path('/tmp/enron-reaudit-20260925.WVW9gE')
m=pd.read_parquet(R/'data/processed/messages.parquet',columns=['path','sender','date','to','cc','analysis','automated','structured','probable_copy','probable_copy_of']).set_index('path')
copy=pd.read_parquet(R/'data/processed/copies.parquet');lookup=dict(zip(copy.path,copy.kept_path))
sh=m[m.probable_copy];gaps=[(r.date-m.loc[r.probable_copy_of,'date']).total_seconds()/3600 for r in sh.itertuples()]
old=json.loads((S/'original_evidence/timezone_header_evidence.json').read_text());original=[]
for p in old:
    paths=[lookup.get(r['path'],r['path']) for r in p['rows']]
    original.append({'paths':paths,'rows':[{'path':x,'flagged':bool(m.loc[x,'probable_copy']),'copy_of':m.loc[x,'probable_copy_of']} for x in paths]})
sample=json.loads((S/'shifted_sample60.json').read_text());labels=[]
for i,r in enumerate(sample):
    a,b=r['flagged'],r['earlier']
    assert normalize_body(a['body'])==normalize_body(b['body'])
    labels.append({'id':i,'later':a['path'],'earlier':b['path'],'classification':'probable_export_copy',
                   'reason':'identical normalized full body and recipients; exact whole-hour shift; cross-mailbox/folder copy pattern',
                   'not_proven':'no server delivery record or stable original Message-ID; genuine resend cannot be excluded'})
summary={'flagged':len(sh),'flagged_automated':int(sh.automated.sum()),'flagged_structured':int(sh.structured.sum()),
         'flagged_analysis':int(sh.analysis.sum()),'gap_to_referenced_copy_hours':pd.Series(gaps).value_counts().sort_index().to_dict(),
         'reference_gap_over8':sum(g>8 for g in gaps),'old_seven_pairs':original,
         'sample_seed':2026092509,'sample_count':60,'probable_export_copies':60,'confirmed_genuine_resends':0,
         'caution':'observational classification, not a validated false-positive estimate'}
(S/'shifted_sample60_labels.json').write_text(json.dumps(labels,indent=2)+'\n')
(S/'dedupe_followup_summary.json').write_text(json.dumps(summary,indent=2)+'\n')
loss=json.loads((S/'dedupe_remaining_recipient_loss.json').read_text())
chosen=[x for x in loss if x['keeper'] in ['maildir/haedicke-m/california/3.','maildir/salisbury-h/inbox/811.','maildir/forney-j/sent_items/96.','maildir/campbell-l/inbox/1027.']]
wanted={x for r in chosen for x in [r['keeper']]+r['copy_paths']}
aliaspairs=[['maildir/kaminski-v/discussion_threads/8129.','maildir/kaminski-v/notes_inbox/55.'],
            ['maildir/linder-e/all_documents/814.','maildir/linder-e/notes_inbox/131.'],
            ['maildir/skilling-j/deleted_items/426.','maildir/skilling-j/inbox/420.']]
wanted|={x for pair in aliaspairs for x in pair}
records={}
with tarfile.open(R/'data/raw/enron_mail_20150507.tar.gz','r|gz') as t:
    for member in t:
        if member.name not in wanted:continue
        data=t.extractfile(member).read();mail=message_from_bytes(data)
        records[member.name]={k:mail.get(k) for k in ['From','To','Cc','X-From','X-To','X-cc','Date','Message-ID','Subject']}
        if len(records)==len(wanted):break
(S/'dedupe_headers.json').write_text(json.dumps({'alias_pairs':aliaspairs,'loss_cases':chosen,'headers':records},indent=2)+'\n')
print(json.dumps(summary,indent=2))
for pair in aliaspairs:
    for x in pair:print(x,json.dumps(records[x]))
for r in chosen:print('LOSS',r['keeper'],'TO',r['retained'],'MISSING',r['missing'])
