from pathlib import Path
import hashlib, json, subprocess, tarfile, shutil
R=Path('/Users/jebfarneth/projects/enron-knowledge-decay')
S=Path('/tmp/enron-reaudit-20260925.WVW9gE')
def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1048576),b''): h.update(b)
    return h.hexdigest()
tracked=subprocess.check_output(['git','ls-files','-z'],cwd=R).decode().split('\0')
paths={R/x for x in tracked if x and not x.startswith('legacy/')}
for d in ['data','results','figures']:
    paths.update(p for p in (R/d).rglob('*') if p.is_file())
snap={str(p.relative_to(R)):sha(p) for p in sorted(paths) if p.is_file()}
(S/'original_hashes.json').write_text(json.dumps(snap,indent=2)+'\n')
(S/'original_git_status.txt').write_bytes(subprocess.check_output(['git','status','--porcelain=v1','--untracked-files=all'],cwd=R))
out=S/'original_evidence';out.mkdir(exist_ok=True)
with tarfile.open(R/'audits/evidence/codex_2026-09-25.tar.gz') as t:
    for m in t.getmembers():
        dest=(out/m.name).resolve()
        assert dest.is_relative_to(out.resolve()),m.name
        assert m.isdir() or m.isfile(),(m.name,m.type)
    t.extractall(out,filter='data')
env=S/'environment_project';env.mkdir(exist_ok=True)
for name in ['pyproject.toml','uv.lock','config.yaml','Makefile']:
    shutil.copy2(R/name,env/name)
for name in ['src','tests']:
    shutil.copytree(R/name,env/name,dirs_exist_ok=True,ignore=shutil.ignore_patterns('__pycache__','*.egg-info'))
print(json.dumps({'hashed_files':len(snap),'evidence':str(out),'environment':str(env)}))
